import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage-database";
import { securityMiddleware } from "./security";
import { insertStaffSchema, insertClientSchema, insertDogSchema, insertJobSchema, insertBookingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Temporarily disable strict auth for demo - will re-enable after login flow is complete
  // app.use("/api/admin", securityMiddleware.validateAuth(["admin"]));
  // app.use("/api/staff", securityMiddleware.validateAuth(["staff"])); 
  // app.use("/api/client", securityMiddleware.validateAuth(["client"]));

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Create role-based token
      const userData = { id: user.id, username: user.username, role: user.role };
      const token = Buffer.from(JSON.stringify(userData)).toString('base64');
      
      res.json({ 
        user: userData,
        token,
        redirectTo: "/admin"
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/staff-login", async (req, res) => {
    try {
      const { pin } = req.body;
      const staff = await storage.getStaffByPin(pin);
      
      if (!staff) {
        return res.status(401).json({ message: "Invalid PIN" });
      }
      
      const now = new Date();
      const today = new Date().toISOString().split('T')[0];
      
      // Create a new time entry for this clock-in
      const timeEntry = await storage.createTimeEntry({
        staffId: staff.id,
        clockInTime: now,
        date: new Date(today),
        notes: "Clocked in via PIN login"
      });
      
      // Update staff status
      const updatedStaff = await storage.updateStaff(staff.id, {
        status: "clocked_in",
        clockInTime: now,
        breakStartTime: null // Clear any previous break time
      });
      
      res.json({ 
        staff: updatedStaff,
        timeEntry,
        message: "Successfully clocked in"
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Staff routes (temporarily accessible for dashboard demo)
  app.get("/api/staff", async (req, res) => {
    // Bypass auth check for demo
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
      const staff = await storage.getAllStaff();
      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/staff", async (req, res) => {
    try {
      const validatedData = insertStaffSchema.parse(req.body);
      const staff = await storage.createStaff(validatedData);
      res.json(staff);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/staff/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status, notes } = req.body;
      const staffId = parseInt(id);
      const now = new Date();
      
      // Get current staff to check their current status
      const currentStaff = await storage.getStaff(staffId);
      if (!currentStaff) {
        return res.status(404).json({ message: "Staff member not found" });
      }

      const updates: any = { status };
      let timeEntryUpdate = null;

      if (status === "on_break") {
        // Starting a break
        updates.breakStartTime = now;
        
        // Find current open time entry and update it
        const today = new Date().toISOString().split('T')[0];
        const todayEntries = await storage.getTimeEntriesByStaff(staffId);
        const currentEntry = todayEntries.find(entry => 
          entry.date.toISOString().split('T')[0] === today && !entry.clockOutTime
        );
        
        if (currentEntry) {
          timeEntryUpdate = await storage.updateTimeEntry(currentEntry.id, {
            breakStartTime: now
          });
        }
        
      } else if (status === "clocked_in") {
        // Returning from break or clocking in
        if (currentStaff.status === "on_break" && currentStaff.breakStartTime) {
          // Calculate break duration
          const breakDuration = Math.floor((now.getTime() - currentStaff.breakStartTime.getTime()) / (1000 * 60));
          
          // Update time entry with break end
          const today = new Date().toISOString().split('T')[0];
          const todayEntries = await storage.getTimeEntriesByStaff(staffId);
          const currentEntry = todayEntries.find(entry => 
            entry.date.toISOString().split('T')[0] === today && !entry.clockOutTime
          );
          
          if (currentEntry) {
            const totalBreakTime = (currentEntry.totalBreakTime || 0) + breakDuration;
            timeEntryUpdate = await storage.updateTimeEntry(currentEntry.id, {
              breakEndTime: now,
              totalBreakTime
            });
          }
        }
        
        updates.clockInTime = currentStaff.clockInTime || now;
        updates.breakStartTime = null;
        
      } else if (status === "clocked_out") {
        // Clocking out
        updates.lastClockOut = now;
        updates.clockInTime = null;
        updates.breakStartTime = null;
        
        // Complete the current time entry
        const today = new Date().toISOString().split('T')[0];
        const todayEntries = await storage.getTimeEntriesByStaff(staffId);
        const currentEntry = todayEntries.find(entry => 
          entry.date.toISOString().split('T')[0] === today && !entry.clockOutTime
        );
        
        if (currentEntry) {
          let totalBreakTime = currentEntry.totalBreakTime || 0;
          
          // If they're on break when clocking out, add current break time
          if (currentStaff.status === "on_break" && currentStaff.breakStartTime) {
            const currentBreakDuration = Math.floor((now.getTime() - currentStaff.breakStartTime.getTime()) / (1000 * 60));
            totalBreakTime += currentBreakDuration;
          }
          
          timeEntryUpdate = await storage.updateTimeEntry(currentEntry.id, {
            clockOutTime: now,
            totalBreakTime,
            notes: notes || "Clocked out"
          });
        }
      }
      
      const staff = await storage.updateStaff(staffId, updates);
      
      res.json({ 
        staff, 
        timeEntry: timeEntryUpdate,
        message: `Successfully ${status.replace('_', ' ')}`
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client authentication routes
  app.post("/api/auth/client-login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const client = await storage.getClientByEmail(email);
      
      if (!client || client.password !== password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      res.json({ 
        client: {
          id: client.id,
          name: client.name,
          email: client.email,
          phone: client.phone,
          address: client.address
        },
        message: "Login successful"
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client routes
  app.get("/api/clients", async (req, res) => {
    try {
      console.log("🚀 API: Fetching clients...");
      const clients = await storage.getAllClients();
      console.log("🎯 API: Got clients:", clients.length, clients.map(c => c.name));
      res.json(clients);
    } catch (error) {
      console.error("❌ API Error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/clients", async (req, res) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(validatedData);
      res.json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/clients/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log("Updating client", id, "with data:", req.body);
      
      // Filter out all problematic fields and only keep the ones we want to update
      const { id: _, createdAt, updatedAt, password, ...cleanData } = req.body;
      
      const updated = await storage.updateClient(id, cleanData);
      if (updated) {
        res.json(updated);
      } else {
        res.status(404).json({ message: "Client not found" });
      }
    } catch (error) {
      console.error("Error updating client:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dog routes
  app.get("/api/dogs", async (req, res) => {
    try {
      const dogs = await storage.getAllDogs();
      res.json(dogs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/dogs/client/:clientId", async (req, res) => {
    try {
      const { clientId } = req.params;
      const dogs = await storage.getDogsByClient(parseInt(clientId));
      res.json(dogs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/dogs", async (req, res) => {
    try {
      const validatedData = insertDogSchema.parse(req.body);
      const dog = await storage.createDog(validatedData);
      res.json(dog);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Delete client route
  app.delete("/api/clients/:id", async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      
      // First delete all dogs belonging to this client
      const clientDogs = await storage.getDogsByClient(clientId);
      for (const dog of clientDogs) {
        await storage.deleteDog(dog.id);
      }
      
      // Then delete the client
      const success = await storage.deleteClient(clientId);
      if (success) {
        res.json({ message: "Client and associated dogs deleted successfully" });
      } else {
        res.status(404).json({ message: "Client not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update dog route
  app.patch("/api/dogs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      console.log("Updating dog", id, "with data:", req.body);
      
      // Filter out problematic fields like we did for clients
      const { id: _, createdAt, updatedAt, ...cleanData } = req.body;
      
      const updated = await storage.updateDog(id, cleanData);
      if (updated) {
        res.json(updated);
      } else {
        res.status(404).json({ message: "Dog not found" });
      }
    } catch (error) {
      console.error("Error updating dog:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Delete dog route
  app.delete("/api/dogs/:id", async (req, res) => {
    try {
      const dogId = parseInt(req.params.id);
      const success = await storage.deleteDog(dogId);
      if (success) {
        res.json({ message: "Dog deleted successfully" });
      } else {
        res.status(404).json({ message: "Dog not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Kennel routes
  app.get("/api/kennels", async (req, res) => {
    try {
      const kennels = await storage.getAllKennels();
      res.json(kennels);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/kennels/assign", async (req, res) => {
    console.log("🚀 ENHANCED KENNEL ASSIGNMENT STARTED");
    try {
      const { kennelIds, dogIds, checkInDate, checkOutDate } = req.body;
      
      console.log("📝 Request data:", { kennelIds, dogIds, checkInDate, checkOutDate });

      if (!Array.isArray(kennelIds) || !Array.isArray(dogIds)) {
        return res.status(400).json({ message: "Invalid kennel or dog selection" });
      }

      if (kennelIds.length !== 1) {
        return res.status(400).json({ message: "Can only assign to one kennel at a time" });
      }

      if (dogIds.length > 2) {
        return res.status(400).json({ message: "Maximum 2 dogs per kennel allowed" });
      }

      const kennelId = kennelIds[0];
      const kennel = await storage.getKennel(kennelId);
      
      if (!kennel) {
        return res.status(404).json({ message: "Kennel not found" });
      }

      // Smart validation: check dates and household rules first
      const currentDogIds = kennel.dogIds || [];

      if (currentDogIds.length > 0 && dogIds.length > 0) {
        const existingDog = await storage.getDog(currentDogIds[0]);
        const newDog = await storage.getDog(dogIds[0]);
        
        if (existingDog && newDog) {
          const newCheckIn = new Date(checkInDate);
          const newCheckOut = new Date(checkOutDate);
          const existingCheckIn = kennel.checkInDate ? new Date(kennel.checkInDate) : new Date();
          const existingCheckOut = kennel.checkOutDate ? new Date(kennel.checkOutDate) : new Date();

          // Check for date overlap
          const hasOverlap = newCheckIn < existingCheckOut && newCheckOut > existingCheckIn;

          if (!hasOverlap) {
            // Dates don't overlap — skip validation
            console.log("✅ No date overlap detected, skipping conflict validation");
          } else {
            // Overlapping dates - validate household rules
            if (existingDog.clientId !== newDog.clientId) {
              return res.status(400).json({ 
                message: `Booking conflict: Kennel occupied by ${existingDog.name} until ${existingCheckOut.toLocaleDateString()}` 
              });
            }

            // Only now check the 2 dog limit
            const overlappingDogsCount = currentDogIds.length + dogIds.length;
            if (overlappingDogsCount > 2) {
              return res.status(400).json({ message: "Cannot exceed 2 dogs per kennel for overlapping dates" });
            }
          }
        }
      }

      // Clear any existing boarding bookings for these dogs and create new ones
      console.log("🔍 Creating bookings for dogs:", dogIds);
      for (const dogId of dogIds) {
        const dog = await storage.getDog(dogId);
        console.log("🐕 Found dog:", dog);
        if (dog) {
          // First, get existing bookings for this dog
          const existingBookings = await storage.getAllBookings();
          const dogBookings = existingBookings.filter(b => b.dogId === dogId && b.serviceType === "boarding");
          
          // Cancel existing boarding bookings for this dog
          for (const existingBooking of dogBookings) {
            console.log("🗑️ Canceling existing booking:", existingBooking.id);
            await storage.updateBooking(existingBooking.id, { status: "cancelled" });
          }
          
          // Create new booking
          const booking = await storage.createBooking({
            clientId: dog.clientId,
            dogId: dogId,
            serviceType: "boarding",
            startDate: new Date(checkInDate),
            endDate: new Date(checkOutDate),
            notes: `Kennel #${kennel.number} assignment`,
          });
          console.log("📅 NEW BOOKING CREATED:", booking);
          console.log("📅 Booking dates:", { start: booking.startDate, end: booking.endDate });
        } else {
          console.log("❌ Dog not found for ID:", dogId);
        }
      }

      // Create individual bookings in the system - don't modify kennel directly
      // The kennel will show the queue count, but individual bookings track the actual dates
      console.log("🎯 Creating separate booking entries for queue system");
      
      // Don't update kennel dogIds - let the booking system handle the queue
      // Just mark kennel as occupied so it shows in the grid
      const updated = await storage.updateKennel(kennelId, {
        status: "occupied",
        // Don't set dogIds here - the display logic will get them from bookings
      });

      // AUTO-ESTIMATE: Create automatic estimate for boarding service
      if (dogIds.length > 0) {
        try {
          console.log("🎯 AUTO-ESTIMATE: Starting auto-estimate creation...");
          const firstDog = await storage.getDog(dogIds[0]);
          console.log("🐕 AUTO-ESTIMATE: Found dog:", firstDog?.name);
          
          if (firstDog) {
            const nights = Math.ceil((new Date(checkOutDate).getTime() - new Date(checkInDate).getTime()) / (1000 * 60 * 60 * 24));
            console.log("🌙 AUTO-ESTIMATE: Calculated nights:", nights);
            
            const servicePricing = await storage.getAllServicePricing();
            const boardingPricing = servicePricing.find(p => p.serviceType.toLowerCase() === 'boarding');
            console.log("💰 AUTO-ESTIMATE: Found boarding pricing:", boardingPricing);
            
            if (boardingPricing) {
              const totalCost = boardingPricing.pricePerUnit * 100 * nights * dogIds.length; // Convert to pence
              console.log("💵 AUTO-ESTIMATE: Calculated cost:", totalCost, "pence (£" + (totalCost / 100).toFixed(2) + ")");
              
              const autoEstimate = await storage.createInvoice({
                clientId: firstDog.clientId,
                amount: totalCost,
                status: "estimate",
                issueDate: new Date(),
                dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
                description: `Auto-generated estimate for Kennel #${kennel.number} boarding (${nights} nights, ${dogIds.length} dog${dogIds.length === 1 ? '' : 's'})`,
                bookingId: null
              });
              
              console.log("✅ AUTO-ESTIMATE CREATED:", autoEstimate.id, "for £" + (totalCost / 100).toFixed(2));
            } else {
              console.log("❌ AUTO-ESTIMATE: No boarding pricing found");
            }
          }
        } catch (estimateError) {
          console.log("⚠️ Auto-estimate failed (kennel assignment still successful):", estimateError);
        }
      }

      console.log("✅ Enhanced assignment complete:", updated);
      console.log("🔍 Updated dogIds:", updated?.dogIds);
      console.log("🔍 dogIds type:", typeof updated?.dogIds, Array.isArray(updated?.dogIds));
      res.json({ message: "Dogs assigned successfully", kennel: updated });
    } catch (error) {
      console.error("💥 Error in enhanced assignment:", error);
      res.status(500).json({ message: "Failed to assign kennels" });
    }
  });

  // Unassign dogs from kennel
  app.patch("/api/kennels/:id/unassign", async (req, res) => {
    try {
      const kennelId = parseInt(req.params.id);
      
      const updated = await storage.updateKennel(kennelId, {
        dogId: null,
        dogIds: [],
        status: "available",
        checkInDate: null,
        checkOutDate: null,
      });

      if (!updated) {
        return res.status(404).json({ message: "Kennel not found" });
      }

      res.json({ message: "Kennel unassigned successfully", kennel: updated });
    } catch (error) {
      console.error("Error unassigning kennel:", error);
      res.status(500).json({ message: "Failed to unassign kennel" });
    }
  });

  app.get("/api/kennels/availability", async (req, res) => {
    try {
      const { start, end } = req.query;

      if (!start || !end) {
        return res.status(400).json({ message: "Missing date range" });
      }

      const startDate = new Date(start as string);
      const endDate = new Date(end as string);

      const kennels = await storage.getAllKennels();

      const availability: Record<string, Record<number, boolean>> = {};

      for (
        let d = new Date(startDate);
        d <= endDate;
        d.setDate(d.getDate() + 1)
      ) {
        const dateKey = d.toISOString().split("T")[0];
        availability[dateKey] = {};

        kennels.forEach((k) => {
          if (
            k.checkInDate &&
            k.checkOutDate &&
            d >= new Date(k.checkInDate) &&
            d <= new Date(k.checkOutDate)
          ) {
            availability[dateKey][k.number] = false;
          } else {
            availability[dateKey][k.number] = true;
          }
        });
      }

      res.json(availability);
    } catch (error) {
      console.error("Error generating availability:", error);
      res.status(500).json({ message: "Failed to fetch availability" });
    }
  });

  // Kennel routes
  app.get("/api/kennels", async (req, res) => {
    try {
      const kennels = await storage.getAllKennels();
      
      // Get dog information for occupied kennels
      const kennelsWithDogs = await Promise.all(
        kennels.map(async (kennel) => {
          if (kennel.dogId) {
            const dog = await storage.getDog(kennel.dogId);
            return { ...kennel, dog };
          }
          return kennel;
        })
      );
      
      res.json(kennelsWithDogs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/kennels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const kennel = await storage.updateKennel(parseInt(id), updates);
      if (!kennel) {
        return res.status(404).json({ message: "Kennel not found" });
      }
      
      res.json(kennel);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Booking routes
  app.get("/api/bookings", async (req, res) => {
    try {
      const allBookings = await storage.getAllBookings();
      // Filter out cancelled bookings for the calendar
      const activeBookings = allBookings.filter(booking => booking.status !== 'cancelled');
      console.log("📋 Returning", activeBookings.length, "active bookings out of", allBookings.length, "total");
      res.json(activeBookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to load bookings" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      // Fix date formatting for database
      const bookingData = {
        ...req.body,
        startDate: new Date(req.body.startDate),
        endDate: req.body.endDate ? new Date(req.body.endDate) : null
      };
      
      const booking = await storage.createBooking(bookingData);

      // AUTO-GENERATE ESTIMATE: Create estimate automatically when booking is created
      console.log("🔍 AUTO-ESTIMATE: Checking booking for estimate generation:", {
        id: booking.id,
        serviceType: booking.serviceType,
        startDate: booking.startDate,
        endDate: booking.endDate
      });
      
      if (booking.serviceType === 'boarding' && booking.startDate && booking.endDate) {
        try {
          console.log("🎯 AUTO-ESTIMATE: Creating estimate for booking:", booking.id);
          
          // Calculate nights and pricing
          const checkIn = new Date(booking.startDate);
          const checkOut = new Date(booking.endDate);
          const nights = Math.max(1, Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)));
          
          // Get pricing from service pricing table
          const servicePricing = await storage.getAllServicePricing();
          const boardingPrice = servicePricing.find(p => p.serviceType?.toLowerCase() === 'boarding');
          const pricePerNight = boardingPrice ? boardingPrice.pricePerUnit * 100 : 4000; // Convert to pence
          
          const totalAmount = nights * pricePerNight;
          
          const estimateData = {
            clientId: booking.clientId,
            bookingId: booking.id,
            kennelNumber: req.body.kennelNumber || 1,
            dogIds: [booking.dogId], // Single dog booking
            serviceType: booking.serviceType,
            checkInDate: checkIn,
            checkOutDate: checkOut,
            nights: nights,
            pricePerNight: pricePerNight,
            totalAmount: totalAmount,
            status: "pending" as const,
            notes: `Auto-generated estimate for booking #${booking.id}`
          };

          const estimate = await storage.createEstimate(estimateData);
          console.log("✅ AUTO-ESTIMATE: Created estimate:", estimate.id, "for £" + (totalAmount / 100));
          
          // Return booking with estimate info
          res.json({ 
            ...booking, 
            estimateId: estimate.id,
            estimateTotal: totalAmount / 100,
            message: "Booking created with automatic estimate"
          });
        } catch (estimateError) {
          console.error("❌ AUTO-ESTIMATE: Failed to create estimate:", estimateError);
          // Return booking even if estimate creation fails
          res.json({ ...booking, message: "Booking created but estimate generation failed" });
        }
      } else {
        res.json(booking);
      }
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      const bookingId = parseInt(req.params.id);
      console.log(`🗑️ Canceling booking ${bookingId} and cleaning up financial records...`);
      
      // Find and remove associated estimates (search by booking ID)
      const estimates = await storage.getAllEstimates();
      const relatedEstimates = estimates.filter((est: any) => est.bookingId === bookingId);
      
      for (const estimate of relatedEstimates) {
        console.log(`🧾 Removing estimate #${estimate.id} for canceled booking`);
        await storage.deleteEstimate(estimate.id);
      }
      
      // Find and remove associated invoices
      const invoices = await storage.getAllInvoices();
      const relatedInvoices = invoices.filter((inv: any) => inv.bookingId === bookingId);
      
      for (const invoice of relatedInvoices) {
        console.log(`💰 Removing invoice #${invoice.id} for canceled booking`);
        await storage.deleteInvoice(invoice.id);
      }
      
      // Delete the booking itself
      const success = await storage.deleteBooking(bookingId);
      
      console.log(`✅ Cleaned up: ${relatedEstimates.length} estimates, ${relatedInvoices.length} invoices, booking deleted: ${success}`);
      res.json({ 
        message: "Booking canceled successfully", 
        removedEstimates: relatedEstimates.length,
        removedInvoices: relatedInvoices.length,
        bookingDeleted: success
      });
    } catch (error) {
      console.error("❌ Error canceling booking:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Job routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const { staffId, date } = req.query;
      
      let jobs;
      if (staffId) {
        jobs = await storage.getJobsByStaff(parseInt(staffId as string));
      } else if (date) {
        jobs = await storage.getJobsByDate(date as string);
      } else {
        jobs = await storage.getAllJobs();
      }
      
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const validatedData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(validatedData);
      res.json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/jobs/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      if (updates.status === "completed" && !updates.completedAt) {
        updates.completedAt = new Date();
      }
      
      const job = await storage.updateJob(parseInt(id), updates);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Booking routes
  app.get("/api/bookings", async (req, res) => {
    try {
      const { clientId } = req.query;
      
      let bookings;
      if (clientId) {
        bookings = await storage.getBookingsByClient(parseInt(clientId as string));
      } else {
        bookings = await storage.getAllBookings();
      }
      
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      res.json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Service Pricing Routes
  app.get("/api/service-pricing", async (req, res) => {
    try {
      const pricing = await storage.getAllServicePricing();
      res.json(pricing);
    } catch (error) {
      console.error("Error fetching service pricing:", error);
      res.status(500).json({ message: "Failed to fetch service pricing" });
    }
  });

  app.post("/api/service-pricing", async (req, res) => {
    try {
      const pricing = await storage.createServicePricing(req.body);
      res.status(201).json(pricing);
    } catch (error) {
      console.error("Error creating service pricing:", error);
      res.status(500).json({ message: "Failed to create service pricing" });
    }
  });

  app.put("/api/service-pricing/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pricing = await storage.updateServicePricing(id, req.body);
      if (!pricing) {
        return res.status(404).json({ message: "Service pricing not found" });
      }
      res.json(pricing);
    } catch (error) {
      console.error("Error updating service pricing:", error);
      res.status(500).json({ message: "Failed to update service pricing" });
    }
  });

  app.delete("/api/service-pricing/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteServicePricing(id);
      if (!success) {
        return res.status(404).json({ message: "Service pricing not found" });
      }
      res.json({ message: "Service pricing deleted successfully" });
    } catch (error) {
      console.error("Error deleting service pricing:", error);
      res.status(500).json({ message: "Failed to delete service pricing" });
    }
  });

  // Import the new financial manager
  const { financialManager } = await import("./financial-manager");
  
  // WORKING AROUND ROUTING ISSUE - Using POST instead of DELETE
  console.log("🚨 Registering cancellation routes using POST method");
  
  app.post("/api/cancel-estimate", async (req, res) => {
    console.log("🎯 POST /api/cancel-estimate called!");
    try {
      const { estimateId } = req.body;
      console.log(`🗑️ Using FinancialManager to delete estimate ${estimateId}...`);
      
      const success = await financialManager.deleteEstimate(estimateId);
      
      if (success) {
        console.log(`✅ FinancialManager successfully deleted estimate ${estimateId}`);
        res.json({ message: "Estimate and booking cancelled successfully", success: true });
      } else {
        console.log(`❌ FinancialManager failed to delete estimate ${estimateId}`);
        res.status(500).json({ message: "Failed to cancel estimate", success: false });
      }
    } catch (error) {
      console.error("❌ Error in cancel-estimate route:", error);
      res.status(500).json({ message: "Internal server error", success: false });
    }
  });

  app.post("/api/cancel-booking", async (req, res) => {
    console.log("🎯 POST /api/cancel-booking called!");
    try {
      const { bookingId } = req.body;
      console.log(`🗑️ Using FinancialManager to cancel booking ${bookingId}...`);
      
      const success = await financialManager.cancelBookingCompletely(bookingId);
      
      if (success) {
        console.log(`✅ FinancialManager successfully cancelled booking ${bookingId}`);
        res.json({ message: "Booking completely cancelled", success: true });
      } else {
        console.log(`❌ FinancialManager failed to cancel booking ${bookingId}`);
        res.status(500).json({ message: "Failed to cancel booking", success: false });
      }
    } catch (error) {
      console.error("❌ Error in cancel-booking route:", error);
      res.status(500).json({ message: "Internal server error", success: false });
    }
  });

  app.post("/api/estimates", async (req, res) => {
    try {
      const { clientId, dogIds, services, checkInDate, checkOutDate, notes } = req.body;
      
      // Calculate total cost based on booking duration and service pricing
      const checkIn = new Date(checkInDate);
      const checkOut = new Date(checkOutDate);
      const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
      
      let totalCost = 0;
      const servicePricing = await storage.getAllServicePricing();
      
      for (const serviceType of services) {
        const pricing = servicePricing.find(p => p.serviceType.toLowerCase() === serviceType.toLowerCase());
        if (pricing) {
          if (serviceType.toLowerCase() === 'boarding') {
            // Boarding is per night per dog - convert to pence (£40 = 4000 pence)
            totalCost += pricing.pricePerUnit * 100 * nights * dogIds.length;
          } else {
            // Other services are per session per dog - convert to pence
            totalCost += pricing.pricePerUnit * 100 * dogIds.length;
          }
        }
      }
      
      // Create invoice/estimate record
      const invoice = await storage.createInvoice({
        clientId: clientId,
        amount: totalCost, // amount is stored in pence
        status: "estimate",
        issueDate: new Date(),
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        services: services.join(', '),
        notes: notes || "",
        bookingId: null // No booking ID for estimates
      });
      
      console.log("💰 Created estimate:", invoice.id, "for £" + (totalCost / 100).toFixed(2));
      res.json(invoice);
    } catch (error) {
      console.error("Error creating estimate:", error);
      res.status(500).json({ message: "Failed to create estimate" });
    }
  });

  // Convert estimate to invoice
  app.patch("/api/invoices/:id/convert", async (req, res) => {
    try {
      const { id } = req.params;
      
      const invoice = await storage.updateInvoice(parseInt(id), {
        status: "unpaid",
        issueDate: new Date(),
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      });
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      console.log("📋 Converted estimate to invoice:", invoice.id);
      res.json(invoice);
    } catch (error) {
      console.error("Error converting estimate:", error);
      res.status(500).json({ message: "Failed to convert estimate" });
    }
  });

  // Invoice routes
  app.get("/api/invoices", async (req, res) => {
    try {
      const invoices = await storage.getAllInvoices();
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Estimates API routes
  app.get("/api/estimates", async (req, res) => {
    try {
      const estimates = await storage.getAllEstimates();
      console.log(`📊 ESTIMATES: Returning ${estimates.length} estimates`);
      res.json(estimates);
    } catch (error) {
      console.error("Error fetching estimates:", error);
      res.status(500).json({ message: "Failed to fetch estimates" });
    }
  });

  app.get("/api/estimates/:id", async (req, res) => {
    try {
      const estimate = await storage.getEstimate(parseInt(req.params.id));
      if (!estimate) {
        return res.status(404).json({ message: "Estimate not found" });
      }
      res.json(estimate);
    } catch (error) {
      console.error("Error fetching estimate:", error);
      res.status(500).json({ message: "Failed to fetch estimate" });
    }
  });

  app.post("/api/estimates/:id/convert-to-invoice", async (req, res) => {
    try {
      const estimateId = parseInt(req.params.id);
      const { depositAmount } = req.body;
      
      const invoice = await storage.convertEstimateToInvoice(estimateId, depositAmount || 0);
      
      res.json({
        ...invoice,
        message: "Estimate converted to invoice successfully"
      });
    } catch (error) {
      console.error("Error converting estimate to invoice:", error);
      res.status(500).json({ message: "Failed to convert estimate to invoice" });
    }
  });

  app.patch("/api/estimates/:id", async (req, res) => {
    try {
      const estimate = await storage.updateEstimate(parseInt(req.params.id), req.body);
      if (!estimate) {
        return res.status(404).json({ message: "Estimate not found" });
      }
      res.json(estimate);
    } catch (error) {
      console.error("Error updating estimate:", error);
      res.status(500).json({ message: "Failed to update estimate" });
    }
  });

  app.patch("/api/invoices/:id/payment", async (req, res) => {
    try {
      const { depositPaid, status, paymentStatus } = req.body;
      const invoiceId = parseInt(req.params.id);
      
      // Get current invoice
      const invoice = await storage.getInvoice(invoiceId);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // Calculate new balance
      const newDepositPaid = depositPaid || invoice.depositPaid;
      const balanceRemaining = invoice.amount - newDepositPaid;
      
      const updatedInvoice = await storage.updateInvoice(invoiceId, {
        depositPaid: newDepositPaid,
        balanceRemaining: balanceRemaining,
        status: status || (balanceRemaining <= 0 ? "paid" : "partially_paid"),
        paymentStatus: paymentStatus || (balanceRemaining <= 0 ? "full_payment" : "deposit_paid"),
        paidDate: balanceRemaining <= 0 ? new Date() : invoice.paidDate
      });
      
      res.json({
        ...updatedInvoice,
        message: "Payment updated successfully"
      });
    } catch (error) {
      console.error("Error updating payment:", error);
      res.status(500).json({ message: "Failed to update payment" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const staff = await storage.getAllStaff();
      const kennels = await storage.getAllKennels();
      const today = new Date().toISOString().split('T')[0];
      const todaysJobs = await storage.getJobsByDate(today);
      
      const staffOnDuty = staff.filter(s => s.status === "clocked_in" || s.status === "on_break").length;
      const dogsBoarding = kennels.filter(k => k.status === "occupied").length;
      const todaysJobCount = todaysJobs.length;
      
      // Revenue calculation based on actual pricing
      const revenue = todaysJobCount * 20; // £20 per job average
      
      res.json({
        staffOnDuty,
        dogsBoarding,
        todaysJobs: todaysJobCount,
        revenue: `£${revenue}`
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dev-only database reset endpoint
  if (process.env.NODE_ENV === "development") {
    app.post("/api/dev/reset-database", async (req, res) => {
      try {
        if (storage.resetDatabase) {
          await storage.resetDatabase();
          res.json({ message: "Database reset successfully" });
        } else {
          res.status(501).json({ message: "Reset not implemented" });
        }
      } catch (error) {
        console.error("Error resetting database:", error);
        res.status(500).json({ message: "Failed to reset database" });
      }
    });
  }

  // Service Pricing routes
  app.get("/api/service-pricing", async (req, res) => {
    try {
      const pricing = await storage.getAllServicePricing();
      res.json(pricing);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service pricing" });
    }
  });

  app.get("/api/service-pricing/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pricing = await storage.getServicePricing(id);
      if (!pricing) {
        return res.status(404).json({ message: "Service pricing not found" });
      }
      res.json(pricing);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service pricing" });
    }
  });

  app.post("/api/service-pricing", async (req, res) => {
    try {
      const pricing = await storage.createServicePricing(req.body);
      res.status(201).json(pricing);
    } catch (error) {
      res.status(500).json({ message: "Failed to create service pricing" });
    }
  });

  app.put("/api/service-pricing/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pricing = await storage.updateServicePricing(id, req.body);
      if (!pricing) {
        return res.status(404).json({ message: "Service pricing not found" });
      }
      res.json(pricing);
    } catch (error) {
      res.status(500).json({ message: "Failed to update service pricing" });
    }
  });

  app.delete("/api/service-pricing/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteServicePricing(id);
      if (!success) {
        return res.status(404).json({ message: "Service pricing not found" });
      }
      res.json({ message: "Service pricing deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete service pricing" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

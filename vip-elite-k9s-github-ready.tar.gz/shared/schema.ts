import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for admin authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("admin"), // admin, staff, client
});

// Staff table
export const staff = pgTable("staff", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(), // Head Trainer, Boarding Specialist, Dog Walker, etc.
  pin: text("pin").notNull(), // 4-digit PIN
  profilePhoto: text("profile_photo"),
  status: text("status").notNull().default("clocked_out"), // clocked_in, on_break, clocked_out
  clockInTime: timestamp("clock_in_time"),
  breakStartTime: timestamp("break_start_time"),
  lastClockOut: timestamp("last_clock_out"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Clients table
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  address: text("address"),
  password: text("password").notNull(),
  // Emergency Contact Information
  emergencyContactName: text("emergency_contact_name"),
  emergencyContactPhone: text("emergency_contact_phone"),
  emergencyContactRelationship: text("emergency_contact_relationship"),
  // Veterinarian Information  
  vetName: text("vet_name"),
  vetPhone: text("vet_phone"),
  vetAddress: text("vet_address"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Pets/Dogs table
export const dogs = pgTable("dogs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  breed: text("breed").notNull(),
  age: integer("age"),
  weight: text("weight"),
  clientId: integer("client_id").notNull(),
  photo: text("photo"),
  feedingInstructions: text("feeding_instructions"),
  feedingTimes: json("feeding_times"), // Array of feeding schedule
  medication: text("medication"),
  medicationSchedule: json("medication_schedule"), // Medication timing details
  specialNotes: text("special_notes"),
  behaviorNotes: text("behavior_notes"),
  emergencyContact: text("emergency_contact"),
  vetInfo: text("vet_info"),
  itemsBrought: json("items_brought"), // Toys, beds, etc. brought by owner
  allergies: text("allergies"),
  exerciseRequirements: text("exercise_requirements"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Kennels table
export const kennels = pgTable("kennels", {
  id: serial("id").primaryKey(),
  number: integer("number").notNull().unique(),
  status: text("status").notNull().default("available"), // occupied, available, cleaning
  dogId: integer("dog_id"), // Keep for backward compatibility
  dogIds: json("dog_ids").$type<number[]>().default([]), // Support multiple dogs
  checkInDate: timestamp("check_in_date"),
  checkOutDate: timestamp("check_out_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Jobs table
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // walk, training, cleaning, feeding, grooming
  description: text("description").notNull(),
  assignedStaffId: integer("assigned_staff_id"),
  dogId: integer("dog_id"),
  kennelId: integer("kennel_id"),
  scheduledDate: timestamp("scheduled_date").notNull(),
  scheduledTime: text("scheduled_time"),
  status: text("status").notNull().default("pending"), // pending, in_progress, completed
  notes: text("notes"),
  completedAt: timestamp("completed_at"),
});

// Bookings table
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  dogId: integer("dog_id").notNull(),
  serviceType: text("service_type").notNull(), // boarding, training, walking, grooming
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  duration: integer("duration"), // in minutes for training/walking
  status: text("status").notNull().default("pending"), // pending, confirmed, in_progress, completed, cancelled
  notes: text("notes"),
  totalAmount: integer("total_amount"), // in pence
});

// Staff time tracking table
export const timeEntries = pgTable("time_entries", {
  id: serial("id").primaryKey(),
  staffId: integer("staff_id").notNull(),
  clockInTime: timestamp("clock_in_time").notNull(),
  clockOutTime: timestamp("clock_out_time"),
  breakStartTime: timestamp("break_start_time"),
  breakEndTime: timestamp("break_end_time"),
  totalBreakTime: integer("total_break_time"), // in minutes
  notes: text("notes"),
  date: timestamp("date").notNull(),
});

// Kennel logs table for detailed tracking
export const kennelLogs = pgTable("kennel_logs", {
  id: serial("id").primaryKey(),
  kennelId: integer("kennel_id").notNull(),
  dogId: integer("dog_id"),
  staffId: integer("staff_id").notNull(),
  activityType: text("activity_type").notNull(), // feeding, cleaning, walking, medication, exercise
  completed: boolean("completed").notNull().default(false),
  notes: text("notes"),
  timestamp: timestamp("timestamp").defaultNow(),
  scheduledTime: timestamp("scheduled_time"),
});

// Daily reports table
export const dailyReports = pgTable("daily_reports", {
  id: serial("id").primaryKey(),
  dogId: integer("dog_id").notNull(),
  date: timestamp("date").notNull(),
  activities: json("activities"), // JSON array of completed activities
  feeding: json("feeding"), // feeding times and amounts
  exercise: json("exercise"), // exercise details
  medications: json("medications"), // medication given
  notes: text("notes"),
  staffNotes: text("staff_notes"),
  photos: json("photos"), // array of photo URLs
  behaviorNotes: text("behavior_notes"),
  overallWellbeing: text("overall_wellbeing"), // good, fair, needs_attention
  createdBy: integer("created_by"), // staff member who created
  createdAt: timestamp("created_at").defaultNow(),
});

// Service Pricing table
export const servicePricing = pgTable("service_pricing", {
  id: serial("id").primaryKey(),
  serviceName: text("service_name").notNull(),
  serviceType: text("service_type").notNull(), // 'boarding', 'training_1on1', 'training_group', 'walking'
  pricePerUnit: integer("price_per_unit").notNull(), // in pence
  unit: text("unit").notNull(), // 'per_night', 'per_session', 'per_walk', 'per_hour'
  description: text("description"),
  isActive: boolean("is_active").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Estimates table - Auto-generated from calendar bookings
export const estimates = pgTable("estimates", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  bookingId: integer("booking_id"),
  kennelNumber: integer("kennel_number"),
  dogIds: integer("dog_ids").array().notNull(), // Array of dog IDs
  serviceType: text("service_type").notNull(),
  checkInDate: timestamp("check_in_date").notNull(),
  checkOutDate: timestamp("check_out_date").notNull(),
  nights: integer("nights").notNull(),
  pricePerNight: integer("price_per_night").notNull(), // in pence
  totalAmount: integer("total_amount").notNull(), // in pence
  status: text("status").notNull().default("pending"), // pending, approved, converted_to_invoice, cancelled
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Invoices table - Converted from estimates
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  estimateId: integer("estimate_id"), // Link back to original estimate
  clientId: integer("client_id").notNull(),
  bookingId: integer("booking_id"),
  amount: integer("amount").notNull(), // in pence
  depositAmount: integer("deposit_amount").default(0), // in pence
  depositPaid: integer("deposit_paid").default(0), // in pence
  balanceRemaining: integer("balance_remaining").notNull(), // in pence
  status: text("status").notNull().default("unpaid"), // unpaid, partially_paid, paid, cancelled
  paymentStatus: text("payment_status").notNull().default("no_deposit"), // no_deposit, deposit_requested, deposit_paid, full_payment
  issueDate: timestamp("issue_date").notNull(),
  dueDate: timestamp("due_date"),
  paidDate: timestamp("paid_date"),
  description: text("description"),
  services: text("services"), // JSON string of services breakdown
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertStaffSchema = createInsertSchema(staff).omit({
  id: true,
  status: true,
  clockInTime: true,
  breakStartTime: true,
  lastClockOut: true,
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDogSchema = createInsertSchema(dogs).omit({
  id: true,
});

export const insertKennelSchema = createInsertSchema(kennels).omit({
  id: true,
  status: true,
  dogId: true,
  checkInDate: true,
  checkOutDate: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  status: true,
  completedAt: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  status: true,
});

export const insertDailyReportSchema = createInsertSchema(dailyReports).omit({
  id: true,
});

export const insertEstimateSchema = createInsertSchema(estimates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTimeEntrySchema = createInsertSchema(timeEntries).omit({
  id: true,
});

export const insertKennelLogSchema = createInsertSchema(kennelLogs).omit({
  id: true,
  timestamp: true,
});

export const insertServicePricingSchema = createInsertSchema(servicePricing).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Staff = typeof staff.$inferSelect;
export type InsertStaff = z.infer<typeof insertStaffSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type Dog = typeof dogs.$inferSelect;
export type InsertDog = z.infer<typeof insertDogSchema>;

export type Kennel = typeof kennels.$inferSelect;
export type InsertKennel = z.infer<typeof insertKennelSchema>;

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export type Booking = typeof bookings.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;

export type DailyReport = typeof dailyReports.$inferSelect;
export type InsertDailyReport = z.infer<typeof insertDailyReportSchema>;

export type Estimate = typeof estimates.$inferSelect;
export type InsertEstimate = typeof insertEstimateSchema._type;
export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;

export type TimeEntry = typeof timeEntries.$inferSelect;
export type InsertTimeEntry = z.infer<typeof insertTimeEntrySchema>;

export type KennelLog = typeof kennelLogs.$inferSelect;
export type InsertKennelLog = z.infer<typeof insertKennelLogSchema>;

export type ServicePricing = typeof servicePricing.$inferSelect;
export type InsertServicePricing = z.infer<typeof insertServicePricingSchema>;

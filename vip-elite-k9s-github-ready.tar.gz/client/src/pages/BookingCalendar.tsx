import React, { useEffect, useState } from "react";
import { format, eachDayOfInterval, parseISO } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BookingCalendar() {
  const [, setLocation] = useLocation();
  const [dateOffset, setDateOffset] = useState(0);
  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('week');
  
  // NEW: Click-to-book state
  const [showBookingDialog, setShowBookingDialog] = useState(false);
  const [selectedBookingData, setSelectedBookingData] = useState({
    kennelNumber: 0,
    checkInDate: "",
    checkOutDate: "",
    clientId: 0,
    dogIds: [] as number[], // Support multiple dogs (max 2)
    serviceType: "boarding"
  });
  
  // Estimate calculation state
  const [estimateData, setEstimateData] = useState({
    totalCost: 0,
    nights: 0,
    costPerNight: 40,
    breakdown: '',
  });

  const { data: kennels = [], refetch: refetchKennels } = useQuery({ 
    queryKey: ["/api/kennels"],
    refetchOnWindowFocus: true,
    refetchInterval: 5000
  });
  const { data: dogs = [] } = useQuery({ 
    queryKey: ["/api/dogs"],
    refetchOnWindowFocus: true
  });
  const { data: clients = [] } = useQuery({ 
    queryKey: ["/api/clients"],
    refetchOnWindowFocus: true
  });
  const { data: bookings = [], refetch: refetchBookings } = useQuery({ 
    queryKey: ["/api/bookings"],
    refetchOnWindowFocus: true,
    refetchInterval: 5000
  });
  const { data: servicePricing = [] } = useQuery({ 
    queryKey: ["/api/service-pricing"]
  });
  
  // NEW: Additional data for booking form
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Calculate estimate when dates, dogs, or service type change
  useEffect(() => {
    if (selectedBookingData.checkInDate && selectedBookingData.checkOutDate && selectedBookingData.dogIds.length > 0 && selectedBookingData.serviceType) {
      const checkIn = new Date(selectedBookingData.checkInDate);
      const checkOut = new Date(selectedBookingData.checkOutDate);
      
      // Simple fixed pricing based on service type
      let servicePrice = 40;
      let unit = "session";
      let quantity = 1;
      
      // Use fixed prices as shown in the dropdown
      switch (selectedBookingData.serviceType) {
        case 'boarding':
          servicePrice = 40;
          quantity = Math.max(1, Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)));
          unit = quantity === 1 ? "night" : "nights";
          break;
        case 'training':
          servicePrice = 45; // 1-on-1 training
          quantity = 1;
          unit = "session";
          break;
        case 'group-training':
          servicePrice = 40; // Group training
          quantity = 1;
          unit = "session";
          break;
        case 'walking':
          servicePrice = 20;
          quantity = 1;
          unit = "walk";
          break;
        default:
          servicePrice = 40;
          quantity = 1;
          unit = "session";
      }
      
      const totalCost = quantity * servicePrice * selectedBookingData.dogIds.length;
      
      setEstimateData({
        totalCost,
        nights: quantity,
        costPerNight: servicePrice,
        breakdown: `${quantity} ${unit} × £${servicePrice}/${unit.replace('s', '')} × ${selectedBookingData.dogIds.length} dog(s) = £${totalCost}`
      });
    }
  }, [selectedBookingData.checkInDate, selectedBookingData.checkOutDate, selectedBookingData.dogIds, selectedBookingData.serviceType]);
  
  // Booking mutation
  const createBookingMutation = useMutation({
    mutationFn: (bookingData: any) => apiRequest("POST", "/api/bookings", bookingData),
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Booking created successfully",
      });
      setShowBookingDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/kennels"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create booking",
        variant: "destructive",
      });
    },
  });

  const startDate = new Date();
  startDate.setDate(startDate.getDate() + dateOffset);
  
  // Calculate days based on view mode
  let days;
  if (viewMode === 'day') {
    days = [startDate];
  } else if (viewMode === 'week') {
    days = eachDayOfInterval({
      start: startDate,
      end: new Date(startDate.getTime() + 6 * 86400000),
    });
  } else { // month
    const monthStart = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    const monthEnd = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 0);
    days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  }

  const handleRefresh = () => {
    refetchKennels();
    refetchBookings();
  };

  // NEW: Click-to-book handler
  const handleCellClick = (kennelNumber: number, date: Date) => {
    // Check if cell is available (no bookings for this kennel on this date)
    const dayBookings = bookings.filter((booking: any) => {
      if (booking.kennelNumber !== kennelNumber) return false;
      const checkIn = new Date(booking.startDate || booking.checkInDate);
      const checkOut = new Date(booking.endDate || booking.checkOutDate);
      checkIn.setHours(0, 0, 0, 0);
      checkOut.setHours(23, 59, 59, 999);
      const clickedDate = new Date(date);
      clickedDate.setHours(12, 0, 0, 0);
      return clickedDate >= checkIn && clickedDate <= checkOut;
    });

    // Only open booking form if cell is available
    if (dayBookings.length === 0) {
      setSelectedBookingData({
        kennelNumber,
        checkInDate: date.toISOString().split('T')[0],
        checkOutDate: "", // User will select this
        clientId: 0,
        dogIds: [], // Support multiple dogs
        serviceType: "boarding"
      });
      setShowBookingDialog(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/30 text-white">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text">
            VIP Elite K9s - Booking Calendar
          </h1>
          <Button 
            onClick={() => setLocation("/admin-dashboard")}
            className="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 text-white font-bold"
          >
            Back to Dashboard
          </Button>
        </div>

        {/* View Mode Tabs */}
        <div className="flex justify-center">
          <div className="bg-black/40 rounded-lg p-1 border border-yellow-400/30">
            {(['day', 'week', 'month'] as const).map((mode) => (
              <Button
                key={mode}
                onClick={() => {
                  setViewMode(mode);
                  setDateOffset(0); // Reset to current date when changing view
                }}
                className={`mx-1 px-4 py-2 font-semibold capitalize ${
                  viewMode === mode
                    ? 'bg-yellow-600 text-black'
                    : 'bg-transparent text-yellow-400 hover:bg-yellow-600/20'
                }`}
              >
                {mode}
              </Button>
            ))}
          </div>
        </div>

        {/* Navigation Controls */}
        <div className="flex justify-center items-center space-x-4">
          <Button
            onClick={() => {
              if (viewMode === 'day') setDateOffset(dateOffset - 1);
              else if (viewMode === 'week') setDateOffset(dateOffset - 7);
              else setDateOffset(dateOffset - 30); // month
            }}
            className="bg-yellow-600/20 hover:bg-yellow-600/40 text-yellow-400 border border-yellow-400/50"
          >
            ← Previous {viewMode}
          </Button>
          
          <Button
            onClick={() => setDateOffset(0)}
            className="bg-yellow-600 hover:bg-yellow-700 text-black font-bold"
          >
            Today
          </Button>
          
          <Button
            onClick={() => {
              if (viewMode === 'day') setDateOffset(dateOffset + 1);
              else if (viewMode === 'week') setDateOffset(dateOffset + 7);
              else setDateOffset(dateOffset + 30); // month
            }}
            className="bg-yellow-600/20 hover:bg-yellow-600/40 text-yellow-400 border border-yellow-400/50"
          >
            Next {viewMode} →
          </Button>
          
          <Button
            onClick={handleRefresh}
            className="bg-blue-600/20 hover:bg-blue-600/40 text-blue-400 border border-blue-400/50"
          >
            🔄 Refresh
          </Button>
        </div>

        {/* Calendar Card */}
        <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
          <CardHeader>
            <CardTitle className="text-yellow-400 text-xl">
              {viewMode === 'day' ? 'Daily' : viewMode === 'week' ? '7-Day' : 'Monthly'} Kennel Booking Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-screen overflow-y-auto">
              <table className="w-full table-auto border-collapse text-sm">
                <thead>
                  <tr>
                    <th className="border border-yellow-400/30 p-3 bg-yellow-400/10 text-yellow-400 font-bold">
                      Kennel
                    </th>
                    {days.map((day) => (
                      <th key={day.toISOString()} className="border border-yellow-400/30 p-3 bg-yellow-400/10 text-yellow-400 font-bold">
                        {format(day, "MMM d")}
                        <br />
                        <span className="text-xs text-gray-300">{format(day, "EEE")}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[...Array(20)].map((_, i) => {
                    const kennelNum = i + 1;
                    return (
                      <tr key={kennelNum} className="hover:bg-yellow-400/5">
                        <td className="border border-yellow-400/30 p-3 text-center font-semibold text-yellow-300 bg-black/60">
                          Kennel #{kennelNum}
                        </td>
                        {days.map((day) => {
                          // Find all active bookings for this kennel on this specific day
                          const dayBookings = (bookings as any[]).filter((booking: any) => {
                            if (!booking.startDate || !booking.endDate) return false;
                            if (booking.status === 'cancelled') return false; // Skip cancelled bookings
                            
                            const bookingStart = new Date(booking.startDate);
                            const bookingEnd = new Date(booking.endDate);
                            
                            // Set times to midnight for accurate date comparison
                            const dayMidnight = new Date(day);
                            dayMidnight.setHours(0, 0, 0, 0);
                            
                            const startMidnight = new Date(bookingStart);
                            startMidnight.setHours(0, 0, 0, 0);
                            
                            const endMidnight = new Date(bookingEnd);
                            endMidnight.setHours(0, 0, 0, 0);
                            
                            // Check if this day falls within the booking period (inclusive of start and end dates)
                            return dayMidnight >= startMidnight && dayMidnight <= endMidnight;
                          });

                          // Find kennel to get assigned dogs for this specific kennel
                          const kennel = (kennels as any[]).find((k: any) => k.number === kennelNum);
                          
                          // Show all bookings for this kennel number OR if kennel is unassigned, show on kennel 1
                          const kennelBookings = dayBookings.filter((booking: any) => {
                            // If booking has a specific kennel assignment, use that
                            if (booking.kennelNumber && booking.kennelNumber === kennelNum) {
                              return true;
                            }
                            // If no kennel assignment and this is kennel 1, show all unassigned bookings
                            if (!booking.kennelNumber && kennelNum === 1) {
                              return true;
                            }
                            // Check if kennel has dogs assigned that match this booking
                            if (kennel && kennel.dogIds && kennel.dogIds.includes(booking.dogId)) {
                              return true;
                            }
                            return false;
                          });

                          const isOccupied = kennelBookings.length > 0;

                          // Determine if this is check-in or check-out day for ANY dog
                          let dayType = 'occupied'; // default
                          if (isOccupied && kennelBookings.length > 0) {
                            const dayMidnight = new Date(day);
                            dayMidnight.setHours(0, 0, 0, 0);
                            
                            // Check all bookings for this day to see if any dog is checking in or out
                            for (const booking of kennelBookings) {
                              const startMidnight = new Date(booking.startDate);
                              startMidnight.setHours(0, 0, 0, 0);
                              
                              const endMidnight = new Date(booking.endDate);
                              endMidnight.setHours(0, 0, 0, 0);
                              
                              if (dayMidnight.getTime() === startMidnight.getTime()) {
                                dayType = 'checkin'; // Green if ANY dog is checking in today
                                break;
                              } else if (dayMidnight.getTime() === endMidnight.getTime()) {
                                dayType = 'checkout'; // Red if ANY dog is checking out today
                                // Don't break here - check-in takes priority over checkout
                              }
                            }
                          }

                          // Simple cell coloring based on day type
                          let cellClasses = "border border-yellow-400/30 p-3 text-center text-sm ";
                          if (isOccupied) {
                            if (dayType === 'checkin') {
                              cellClasses += "bg-green-600 text-white font-bold"; // Check-in day = Green
                            } else if (dayType === 'checkout') {
                              cellClasses += "bg-red-600 text-white font-bold"; // Checkout day = Red
                            } else {
                              cellClasses += "bg-orange-500 text-white font-bold"; // Regular occupied = Orange
                            }
                          } else {
                            cellClasses += "bg-black/40 text-gray-400 hover:bg-yellow-400/10";
                          }

                          return (
                            <td
                              key={day.toISOString()}
                              className={cellClasses}
                            >
                              {isOccupied ? (
                                <div>
                                  {kennelBookings.map((booking: any, index: number) => {
                                    const dog = (dogs as any[]).find((d: any) => d.id === booking.dogId);
                                    const client = (clients as any[]).find((c: any) => c.id === booking.clientId);
                                    
                                    if (!dog) return null;
                                    
                                    // Determine if this specific dog is checking in today
                                    const dayMidnight = new Date(day);
                                    dayMidnight.setHours(0, 0, 0, 0);
                                    const startMidnight = new Date(booking.startDate);
                                    startMidnight.setHours(0, 0, 0, 0);
                                    
                                    const isThisDogCheckingIn = dayMidnight.getTime() === startMidnight.getTime();
                                    
                                    return (
                                      <div key={booking.id} className={index > 0 ? "mt-1 pt-1 border-t border-white/20" : ""}>
                                        <div className="font-bold text-xs">{dog.name}</div>
                                        <div className="text-xs">{dog.breed}</div>
                                        {kennelBookings.length > 1 && client && (
                                          <div className="text-xs opacity-75">{client.name}</div>
                                        )}
                                        <div className="text-xs opacity-75">
                                          {isThisDogCheckingIn ? 'Checking In' :
                                           dayType === 'checkout' ? 'Checking Out' :
                                           `Out: ${new Date(booking.endDate).toLocaleDateString()}`}
                                        </div>
                                      </div>
                                    );
                                  }).filter(Boolean)}
                                </div>
                              ) : (
                                <span 
                                  className="text-gray-500 cursor-pointer hover:text-yellow-400 hover:bg-yellow-400/10 px-2 py-1 rounded transition-colors"
                                  onClick={() => handleCellClick(kennelNum, day)}
                                  title="Click to book this kennel"
                                >
                                  Available
                                </span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <Card className="bg-black/60 border border-yellow-400/30">
          <CardContent className="p-4">
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-yellow-600 rounded"></div>
                <span>Booked</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-black/40 border border-yellow-400/30 rounded"></div>
                <span>Available</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* NEW: Click-to-Book Dialog */}
        {showBookingDialog && (
          <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
            <DialogContent className="bg-black/95 border border-yellow-400/30 max-w-md">
              <DialogHeader>
                <DialogTitle className="text-yellow-400 text-xl">
                  Book Kennel #{selectedBookingData.kennelNumber}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                {/* Check-in Date (Pre-filled) */}
                <div>
                  <Label className="text-yellow-400">Check-in Date</Label>
                  <Input 
                    type="date" 
                    value={selectedBookingData.checkInDate}
                    onChange={(e) => setSelectedBookingData(prev => ({...prev, checkInDate: e.target.value}))}
                    className="bg-black/60 border-yellow-400/30 text-white"
                  />
                </div>

                {/* Check-out Date */}
                <div>
                  <Label className="text-yellow-400">Check-out Date</Label>
                  <Input 
                    type="date" 
                    value={selectedBookingData.checkOutDate}
                    onChange={(e) => setSelectedBookingData(prev => ({...prev, checkOutDate: e.target.value}))}
                    className="bg-black/60 border-yellow-400/30 text-white"
                    min={selectedBookingData.checkInDate}
                  />
                </div>

                {/* Service Type Selection */}
                <div>
                  <Label className="text-yellow-400">Service Type</Label>
                  <Select 
                    value={selectedBookingData.serviceType}
                    onValueChange={(value) => setSelectedBookingData(prev => ({...prev, serviceType: value}))}
                  >
                    <SelectTrigger className="bg-black/60 border-yellow-400/30 text-white">
                      <SelectValue placeholder="Select service type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="boarding">Boarding (£40/night)</SelectItem>
                      <SelectItem value="training">1-on-1 Training (£45/session)</SelectItem>
                      <SelectItem value="group-training">Group Training (£40/session)</SelectItem>
                      <SelectItem value="walking">Dog Walking (£20/walk)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Client Selection */}
                <div>
                  <Label className="text-yellow-400">Client</Label>
                  <Select 
                    value={selectedBookingData.clientId.toString()}
                    onValueChange={(value) => {
                      setSelectedBookingData(prev => ({
                        ...prev, 
                        clientId: parseInt(value),
                        dogId: 0 // Reset dog selection when client changes
                      }));
                    }}
                  >
                    <SelectTrigger className="bg-black/60 border-yellow-400/30 text-white">
                      <SelectValue placeholder="Select client" />
                    </SelectTrigger>
                    <SelectContent>
                      {(clients as any[]).map((client: any) => (
                        <SelectItem key={client.id} value={client.id.toString()}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Multi-Dog Selection (Max 2) */}
                {selectedBookingData.clientId > 0 && (
                  <div>
                    <Label className="text-yellow-400">Dogs (Max 2 from same client)</Label>
                    <div className="space-y-2 bg-black/40 p-3 rounded border border-yellow-400/30">
                      {(dogs as any[])
                        .filter((dog: any) => dog.clientId === selectedBookingData.clientId)
                        .map((dog: any) => (
                          <div key={dog.id} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              id={`dog-${dog.id}`}
                              checked={selectedBookingData.dogIds.includes(dog.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  if (selectedBookingData.dogIds.length < 2) {
                                    setSelectedBookingData(prev => ({
                                      ...prev, 
                                      dogIds: [...prev.dogIds, dog.id]
                                    }));
                                  } else {
                                    toast({
                                      title: "Maximum Reached",
                                      description: "You can only select up to 2 dogs per kennel",
                                      variant: "destructive",
                                    });
                                  }
                                } else {
                                  setSelectedBookingData(prev => ({
                                    ...prev, 
                                    dogIds: prev.dogIds.filter(id => id !== dog.id)
                                  }));
                                }
                              }}
                              className="rounded text-yellow-400 focus:ring-yellow-400"
                            />
                            <label htmlFor={`dog-${dog.id}`} className="text-white cursor-pointer">
                              {dog.name} ({dog.breed})
                            </label>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {/* Cost Estimate Display */}
                {selectedBookingData.checkInDate && selectedBookingData.checkOutDate && selectedBookingData.dogIds.length > 0 && (
                  <div className="bg-gradient-to-r from-yellow-400/20 to-amber-400/20 p-4 rounded-lg border border-yellow-400/50">
                    <h3 className="text-yellow-400 font-semibold text-lg mb-2">Booking Estimate</h3>
                    <div className="space-y-1 text-white">
                      <p className="text-sm">{estimateData.breakdown}</p>
                      <p className="text-xl font-bold text-yellow-400">Total: £{estimateData.totalCost}</p>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={() => {
                      if (!selectedBookingData.checkOutDate || selectedBookingData.dogIds.length === 0) {
                        toast({
                          title: "Missing Information",
                          description: "Please fill in all required fields and select at least one dog",
                          variant: "destructive",
                        });
                        return;
                      }

                      // Create separate bookings for each dog
                      selectedBookingData.dogIds.forEach(dogId => {
                        createBookingMutation.mutate({
                          clientId: selectedBookingData.clientId,
                          dogId: dogId,
                          serviceType: selectedBookingData.serviceType,
                          startDate: selectedBookingData.checkInDate,
                          endDate: selectedBookingData.checkOutDate,
                          kennelNumber: selectedBookingData.kennelNumber,
                          status: 'confirmed'
                        });
                      });
                    }}
                    disabled={createBookingMutation.isPending}
                    className="flex-1 bg-yellow-400 hover:bg-yellow-500 text-black"
                  >
                    {createBookingMutation.isPending ? "Booking..." : "Create Booking"}
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => setShowBookingDialog(false)}
                    className="border-gray-400 text-gray-400 hover:bg-gray-400/10"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}
import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { StaffCard } from "@/components/staff-card";
import { StaffLoginModal } from "@/components/staff-login-modal";
import type { Staff } from "@shared/schema";

export default function StaffLogin() {
  const [, setLocation] = useLocation();
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);

  const { data: staff = [], isLoading } = useQuery({
    queryKey: ["/api/staff"],
  });

  const handleStaffClick = (staffMember: Staff) => {
    setSelectedStaff(staffMember);
    setShowLoginModal(true);
  };

  const handleLoginSuccess = () => {
    setShowLoginModal(false);
    setLocation("/staff/dashboard");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading staff...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-royal-blue mb-2">VIP Elite K9s</h1>
            <h2 className="text-xl font-semibold text-foreground">Staff Login</h2>
            <p className="text-muted-foreground mt-2">Click on your profile to log in</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-center">Select Your Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {staff.map((staffMember: Staff) => (
                  <StaffCard 
                    key={staffMember.id}
                    staff={staffMember}
                    onClick={() => handleStaffClick(staffMember)}
                    showStatus={false}
                  />
                ))}
              </div>
              
              {staff.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No staff members found.</p>
                  <p className="text-muted-foreground text-sm mt-2">Ask your administrator to add staff members.</p>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="text-center mt-6">
            <Button variant="outline" onClick={() => setLocation("/")}>
              Back to Admin Dashboard
            </Button>
          </div>
        </div>
      </div>

      {selectedStaff && (
        <StaffLoginModal
          staff={selectedStaff}
          open={showLoginModal}
          onOpenChange={setShowLoginModal}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
    </div>
  );
}

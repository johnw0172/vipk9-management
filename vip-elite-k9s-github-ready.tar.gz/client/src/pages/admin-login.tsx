import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Lock, Shield, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import logoPath from "@assets/LOGO JPEG.jpg";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [pin, setPin] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleNumberClick = (number: string) => {
    if (pin.length < 6) {
      setPin(pin + number);
    }
  };

  const handleClear = () => {
    setPin("");
  };

  const handleBackspace = () => {
    setPin(pin.slice(0, -1));
  };

  const handleLogin = async () => {
    if (pin.length === 0) {
      toast({
        title: "Enter Admin PIN",
        description: "Please enter your admin PIN to continue",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    // Simulate admin authentication (replace with real auth)
    setTimeout(() => {
      if (pin === "123456" || pin === "admin" || pin === "0000") {
        toast({
          title: "Welcome Administrator! ✓",
          description: "Access granted to admin dashboard",
        });
        setLocation("/admin-dashboard");
      } else {
        toast({
          title: "Access Denied",
          description: "Invalid admin PIN. Please try again.",
          variant: "destructive",
        });
        setPin("");
      }
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 relative">
      {/* Elegant Border Frame */}
      <div className="absolute inset-0 border-8 border-double border-yellow-400 m-4 pointer-events-none"></div>
      <div className="absolute inset-0 border-4 border-yellow-500/30 m-8 pointer-events-none"></div>
      
      {/* Header */}
      <div className="bg-black/90 backdrop-blur shadow-xl border-b-2 border-yellow-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={logoPath} 
                alt="VIP Elite K9s" 
                className="h-12 w-12 rounded-full object-cover border-3 border-yellow-400 shadow-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-yellow-400">VIP Elite K9s</h1>
                <p className="text-sm text-gray-300">Admin Access Portal</p>
              </div>
            </div>
            
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 font-semibold"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Homepage
            </Button>
          </div>
        </div>
      </div>

      {/* Login Content */}
      <div className="flex items-center justify-center min-h-[calc(100vh-120px)] p-6 relative z-10">
        <Card className="w-full max-w-md bg-black/80 backdrop-blur border-4 border-double border-yellow-400 relative">
          <div className="absolute inset-2 border border-yellow-500/30 pointer-events-none"></div>
          
          <CardHeader className="text-center relative">
            <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Shield className="w-8 h-8 text-black" />
            </div>
            <CardTitle className="text-2xl font-bold text-yellow-400 mb-2">
              Administrator Access
            </CardTitle>
            <p className="text-gray-300">Enter your admin PIN to continue</p>
          </CardHeader>

          <CardContent className="space-y-6 relative">
            {/* PIN Display */}
            <div className="bg-black/60 border-2 border-yellow-400 rounded-lg p-4">
              <div className="flex justify-center space-x-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-3 h-3 rounded-full border-2 ${
                      i < pin.length
                        ? "bg-yellow-400 border-yellow-400"
                        : "border-yellow-400/50"
                    }`}
                  />
                ))}
              </div>
              <div className="text-center mt-2 text-yellow-400 font-mono text-lg tracking-wider">
                {pin.replace(/./g, "●")}
              </div>
            </div>

            {/* Keypad */}
            <div className="grid grid-cols-3 gap-3">
              {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((number) => (
                <Button
                  key={number}
                  variant="outline"
                  onClick={() => handleNumberClick(number)}
                  className="h-14 text-xl font-bold border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black transition-all"
                >
                  {number}
                </Button>
              ))}
              
              <Button
                variant="outline"
                onClick={handleClear}
                className="h-14 border-2 border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
              >
                Clear
              </Button>
              
              <Button
                variant="outline"
                onClick={() => handleNumberClick("0")}
                className="h-14 text-xl font-bold border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black transition-all"
              >
                0
              </Button>
              
              <Button
                variant="outline"
                onClick={handleBackspace}
                className="h-14 border-2 border-orange-400 text-orange-400 hover:bg-orange-400 hover:text-white"
              >
                ⌫
              </Button>
            </div>

            {/* Login Button */}
            <Button
              onClick={handleLogin}
              disabled={isLoading || pin.length === 0}
              className="w-full h-14 bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-bold text-lg border-2 border-yellow-300 shadow-lg disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Lock className="w-5 h-5 mr-2 animate-spin" />
                  Authenticating...
                </>
              ) : (
                <>
                  <Crown className="w-5 h-5 mr-2" />
                  Access Dashboard
                </>
              )}
            </Button>

            <div className="text-center text-gray-400 text-sm">
              Secure admin access for VIP Elite K9s management
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { ArrowLeft, Edit2, Plus, Save, X, DollarSign } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

interface ServicePricing {
  id: number;
  serviceName: string;
  serviceType: string;
  pricePerUnit: number;
  unit: string;
  description: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function PricingManagement() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  const { data: pricing = [], isLoading } = useQuery({
    queryKey: ["/api/service-pricing"],
    refetchOnWindowFocus: true,
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest("PUT", `/api/service-pricing/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-pricing"] });
      setEditingId(null);
      toast({
        title: "Success",
        description: "Service pricing updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update pricing",
        variant: "destructive",
      });
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/service-pricing", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/service-pricing"] });
      setIsAddingNew(false);
      toast({
        title: "Success",
        description: "New service pricing created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create new pricing",
        variant: "destructive",
      });
    },
  });

  const formatPrice = (priceInPence: number) => {
    return (priceInPence / 100).toFixed(2);
  };

  const handleSave = (id: number, formData: FormData) => {
    const data = {
      serviceName: formData.get("serviceName"),
      serviceType: formData.get("serviceType"),
      pricePerUnit: parseFloat(formData.get("pricePerUnit") as string),
      unit: formData.get("unit"),
      description: formData.get("description"),
      isActive: formData.get("isActive") === "true",
    };
    updateMutation.mutate({ id, data });
  };

  const handleCreate = (formData: FormData) => {
    const data = {
      serviceName: formData.get("serviceName"),
      serviceType: formData.get("serviceType"),
      pricePerUnit: parseFloat(formData.get("pricePerUnit") as string),
      unit: formData.get("unit"),
      description: formData.get("description"),
      isActive: true,
    };
    createMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/30 text-white flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-yellow-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/30 text-white">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => setLocation("/admin-dashboard")}
              className="bg-gray-700 hover:bg-gray-600 text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text">
              Service Pricing Management
            </h1>
          </div>
          
          <Dialog open={isAddingNew} onOpenChange={setIsAddingNew}>
            <DialogTrigger asChild>
              <Button className="bg-yellow-600 hover:bg-yellow-700 text-black font-bold">
                <Plus className="w-4 h-4 mr-2" />
                Add New Service
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-yellow-400 text-white">
              <DialogHeader>
                <DialogTitle className="text-yellow-400">Add New Service</DialogTitle>
              </DialogHeader>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleCreate(new FormData(e.target as HTMLFormElement));
                }}
                className="space-y-4"
              >
                <div>
                  <Label htmlFor="serviceName">Service Name</Label>
                  <Input
                    id="serviceName"
                    name="serviceName"
                    className="bg-gray-800 border-gray-600 text-white"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="serviceType">Service Type</Label>
                  <Select name="serviceType" required>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select service type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="boarding">Boarding</SelectItem>
                      <SelectItem value="training_1on1">1-on-1 Training</SelectItem>
                      <SelectItem value="training_group">Group Training</SelectItem>
                      <SelectItem value="walking">Dog Walking</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="pricePerUnit">Price (£)</Label>
                  <Input
                    id="pricePerUnit"
                    name="pricePerUnit"
                    type="number"
                    step="0.01"
                    className="bg-gray-800 border-gray-600 text-white"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="unit">Unit</Label>
                  <Select name="unit" required>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="per_night">Per Night</SelectItem>
                      <SelectItem value="per_session">Per Session</SelectItem>
                      <SelectItem value="per_walk">Per Walk</SelectItem>
                      <SelectItem value="per_hour">Per Hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    name="description"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddingNew(false)}
                    className="border-gray-600 text-gray-300"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-yellow-600 hover:bg-yellow-700 text-black">
                    Create Service
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pricing Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {pricing.map((service: ServicePricing) => (
            <Card key={service.id} className="bg-black/80 backdrop-blur border-2 border-yellow-400">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-yellow-400 flex items-center">
                    <DollarSign className="w-5 h-5 mr-2" />
                    {service.serviceName}
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge variant={service.isActive ? "default" : "secondary"}>
                      {service.isActive ? "Active" : "Inactive"}
                    </Badge>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditingId(service.id)}
                      className="text-yellow-400 hover:bg-yellow-400/10"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {editingId === service.id ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSave(service.id, new FormData(e.target as HTMLFormElement));
                    }}
                    className="space-y-3"
                  >
                    <div>
                      <Label htmlFor={`serviceName-${service.id}`}>Service Name</Label>
                      <Input
                        id={`serviceName-${service.id}`}
                        name="serviceName"
                        defaultValue={service.serviceName}
                        className="bg-gray-800 border-gray-600 text-white text-sm"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`price-${service.id}`}>Price (£)</Label>
                      <Input
                        id={`price-${service.id}`}
                        name="pricePerUnit"
                        type="number"
                        step="0.01"
                        defaultValue={service.pricePerUnit}
                        className="bg-gray-800 border-gray-600 text-white text-sm"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`description-${service.id}`}>Description</Label>
                      <Textarea
                        id={`description-${service.id}`}
                        name="description"
                        defaultValue={service.description || ""}
                        className="bg-gray-800 border-gray-600 text-white text-sm"
                      />
                    </div>
                    <input type="hidden" name="serviceType" value={service.serviceType} />
                    <input type="hidden" name="unit" value={service.unit} />
                    <input type="hidden" name="isActive" value={service.isActive.toString()} />
                    <div className="flex justify-end space-x-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => setEditingId(null)}
                        className="text-gray-400"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                      <Button
                        type="submit"
                        size="sm"
                        className="bg-yellow-600 hover:bg-yellow-700 text-black"
                      >
                        <Save className="w-4 h-4" />
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-green-400">
                      £{service.pricePerUnit} {service.unit.replace('_', ' ')}
                    </div>
                    <div className="text-sm text-gray-300 capitalize">
                      {service.serviceType.replace('_', ' ')}
                    </div>
                    {service.description && (
                      <p className="text-sm text-gray-400">{service.description}</p>
                    )}
                    <div className="text-xs text-gray-500">
                      Last updated: {new Date(service.updatedAt).toLocaleDateString()}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
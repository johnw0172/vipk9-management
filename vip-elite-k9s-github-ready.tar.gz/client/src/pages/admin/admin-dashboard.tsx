import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Users, Calendar, DollarSign, Clock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { VIPHeader } from "@/components/vip-header";
import { StaffCard } from "@/components/staff-card";
import { KennelGrid } from "@/components/kennel-grid";
import { AddStaffModal } from "@/components/add-staff-modal";
import { AddJobModal } from "@/components/add-job-modal";
import { ErrorBoundary, LoadingSpinner } from "@/components/error-boundary";

export default function AdminDashboard() {
  const [showAddStaff, setShowAddStaff] = useState(false);
  const [showAddJob, setShowAddJob] = useState(false);

  // Fetch dashboard data with authentication
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/dashboard/stats"],
  });

  const { data: staff = [], isLoading: staffLoading } = useQuery({
    queryKey: ["/api/admin/staff"],
  });

  const { data: jobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/admin/jobs"],
  });

  const { data: kennels = [], isLoading: kennelsLoading } = useQuery({
    queryKey: ["/api/admin/kennels"],
  });

  if (statsLoading || staffLoading || jobsLoading || kennelsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner message="Loading VIP Elite K9s Admin Dashboard..." />
      </div>
    );
  }

  const todayJobs = jobs.filter((job: any) => {
    const today = new Date().toDateString();
    return new Date(job.scheduledDate).toDateString() === today;
  });

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        <VIPHeader 
          title="Admin Dashboard" 
          subtitle="VIP Elite K9s Management System"
          showNavigation={true}
        />

        <div className="container mx-auto px-6 py-8">
          {/* Dashboard Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Staff On Duty</CardTitle>
                <Users className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {stats?.staffOnDuty || 0}
                </div>
                <p className="text-xs text-muted-foreground">Currently clocked in</p>
              </CardContent>
            </Card>

            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Dogs Boarding</CardTitle>
                <Calendar className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {stats?.dogsBoarding || 0}
                </div>
                <p className="text-xs text-muted-foreground">In our care today</p>
              </CardContent>
            </Card>

            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Today's Jobs</CardTitle>
                <Clock className="h-4 w-4 text-amber-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">
                  {todayJobs.length}
                </div>
                <p className="text-xs text-muted-foreground">Scheduled for today</p>
              </CardContent>
            </Card>

            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  £{stats?.revenue || "0.00"}
                </div>
                <p className="text-xs text-muted-foreground">This month</p>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Staff Management */}
            <Card className="vip-card lg:col-span-1">
              <CardHeader className="vip-header">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Staff Management</CardTitle>
                    <CardDescription className="text-blue-100">
                      Monitor and manage your team
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => setShowAddStaff(true)}
                    className="vip-button-gold"
                  >
                    Add Staff
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                  {staff.map((member: any) => (
                    <StaffCard
                      key={member.id}
                      staff={member}
                      showStatus={true}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Kennel Grid */}
            <Card className="vip-card lg:col-span-2">
              <CardHeader className="vip-header">
                <CardTitle className="text-white">Facility Overview</CardTitle>
                <CardDescription className="text-blue-100">
                  Live kennel status and occupancy
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <KennelGrid kennels={kennels} />
              </CardContent>
            </Card>
          </div>

          {/* Today's Jobs */}
          <Card className="vip-card mt-8">
            <CardHeader className="vip-header">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Today's Schedule</CardTitle>
                  <CardDescription className="text-blue-100">
                    Jobs and tasks for {new Date().toLocaleDateString()}
                  </CardDescription>
                </div>
                <Button 
                  onClick={() => setShowAddJob(true)}
                  className="vip-button-gold"
                >
                  Add Job
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid gap-4">
                {todayJobs.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No jobs scheduled for today
                  </div>
                ) : (
                  todayJobs.map((job: any) => (
                    <div
                      key={job.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                          job.status === 'completed' ? 'bg-green-100 text-green-800' :
                          job.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {job.status.replace('_', ' ')}
                        </div>
                        <div>
                          <h4 className="font-semibold">{job.type}</h4>
                          <p className="text-sm text-gray-600">{job.description}</p>
                        </div>
                      </div>
                      <div className="text-sm text-gray-500">
                        {job.scheduledTime}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Modals */}
        <AddStaffModal 
          open={showAddStaff} 
          onOpenChange={setShowAddStaff} 
        />
        <AddJobModal 
          open={showAddJob} 
          onOpenChange={setShowAddJob} 
        />
      </div>
    </ErrorBoundary>
  );
}
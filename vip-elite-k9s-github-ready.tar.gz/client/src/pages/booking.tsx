import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertBookingSchema } from "@shared/schema";
import { z } from "zod";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Dog, 
  GraduationCap, 
  Home, 
  MapPin,
  Plus,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";

// Extended booking schema with validation
const bookingFormSchema = insertBookingSchema.extend({
  serviceTimes: z.array(z.string()).min(1, "Please select at least one time slot"),
  specialRequests: z.string().optional(),
}).omit({
  status: true,
  totalAmount: true,
});

export default function BookingPage() {
  const [selectedService, setSelectedService] = useState<string>("");
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Mock client - in real app this would come from auth context
  const currentClient = { id: 1, name: "Test Client" };

  // Service definitions with pricing
  const services = [
    {
      id: "training",
      title: "Professional Training",
      description: "One-on-one training sessions with certified trainers",
      icon: GraduationCap,
      price: 85,
      duration: "60 minutes",
      color: "bg-blue-500",
      features: [
        "Personalized training plan",
        "Progress tracking",
        "Behavior modification",
        "Basic obedience",
        "Problem solving"
      ]
    },
    {
      id: "walking",
      title: "Premium Dog Walking",
      description: "Professional walking services in safe, secure areas",
      icon: MapPin,
      price: 35,
      duration: "30-60 minutes",
      color: "bg-green-500",
      features: [
        "Experienced walkers",
        "GPS tracking",
        "Photo updates",
        "Flexible scheduling",
        "Weather protection"
      ]
    },
    {
      id: "boarding",
      title: "Luxury Boarding",
      description: "Premium overnight care in our state-of-the-art facility",
      icon: Home,
      price: 125,
      duration: "Per night",
      color: "bg-purple-500",
      features: [
        "24/7 supervision",
        "Spacious kennels",
        "Daily exercise",
        "Feeding management",
        "Medical care available"
      ]
    }
  ];

  // Available time slots
  const timeSlots = [
    "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", 
    "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", 
    "4:00 PM", "5:00 PM", "6:00 PM"
  ];

  // Get client's pets
  const { data: pets = [] } = useQuery({
    queryKey: ["/api/dogs", "client", currentClient.id],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/dogs/client/${currentClient.id}`);
      return response.json();
    },
  });

  // Get client's bookings
  const { data: bookings = [] } = useQuery({
    queryKey: ["/api/bookings", "client", currentClient.id],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/bookings/client/${currentClient.id}`);
      return response.json();
    },
  });

  // Booking form
  const bookingForm = useForm({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      clientId: currentClient.id,
      dogId: 0,
      serviceType: "",
      startDate: new Date(),
      endDate: null,
      duration: null,
      notes: "",
      serviceTimes: [],
      specialRequests: "",
    },
  });

  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/bookings", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed! ✓",
        description: "Your service has been scheduled successfully. We'll send you a confirmation shortly.",
      });
      setShowBookingForm(false);
      setSelectedService("");
      bookingForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "Unable to complete your booking. Please try again or contact us.",
        variant: "destructive",
      });
    },
  });

  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId);
    setShowBookingForm(true);
    bookingForm.setValue("serviceType", serviceId);
  };

  const handleBookingSubmit = (data: any) => {
    // Calculate pricing based on service and duration
    const service = services.find(s => s.id === data.serviceType);
    const totalAmount = service ? service.price : 0;

    const bookingData = {
      ...data,
      status: "pending",
      totalAmount,
      startDate: selectedDate || new Date(),
      endDate: data.serviceType === "boarding" ? data.endDate : null,
    };

    createBookingMutation.mutate(bookingData);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed": return "bg-green-500";
      case "pending": return "bg-yellow-500";
      case "completed": return "bg-blue-500";
      case "cancelled": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-royal-blue to-blue-600 text-white p-6">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-2">Book Premium Services</h1>
          <p className="text-blue-100">Schedule the best care for your beloved pets</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Service Selection */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Choose Your Service</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => {
              const IconComponent = service.icon;
              return (
                <Card 
                  key={service.id} 
                  className="cursor-pointer hover:shadow-xl transition-all duration-300 hover:scale-105 border-t-4"
                  style={{ borderTopColor: service.color.replace('bg-', '') }}
                  onClick={() => handleServiceSelect(service.id)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className={`w-12 h-12 ${service.color} rounded-full flex items-center justify-center mr-4`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">{service.title}</h3>
                        <p className="text-muted-foreground">{service.duration}</p>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                    
                    <div className="mb-4">
                      <div className="text-2xl font-bold text-royal-blue">${service.price}</div>
                      <div className="text-sm text-muted-foreground">per {service.duration}</div>
                    </div>

                    <ul className="space-y-1 mb-4">
                      {service.features.slice(0, 3).map((feature, index) => (
                        <li key={index} className="text-sm flex items-center">
                          <CheckCircle className="h-3 w-3 text-green-500 mr-2" />
                          {feature}
                        </li>
                      ))}
                    </ul>

                    <Button className="w-full bg-royal-blue hover:bg-blue-700">
                      Book {service.title}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Current Bookings */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Your Current Bookings</h2>
          {bookings.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {bookings.map((booking: any) => (
                <Card key={booking.id} className="border-l-4 border-l-royal-blue">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold capitalize">{booking.serviceType}</h4>
                      <Badge className={`${getStatusColor(booking.status)} text-white`}>
                        {booking.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {format(new Date(booking.startDate), 'MMM dd, yyyy')}
                    </p>
                    <p className="text-lg font-bold text-royal-blue">
                      ${booking.totalAmount}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="text-center py-8 border-2 border-dashed">
              <CardContent>
                <CalendarIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No bookings yet. Schedule your first service above!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Booking Form Dialog */}
      <Dialog open={showBookingForm} onOpenChange={setShowBookingForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl">
              Book {services.find(s => s.id === selectedService)?.title}
            </DialogTitle>
            <p className="text-muted-foreground">
              Fill out the details below to schedule your service
            </p>
          </DialogHeader>

          <Form {...bookingForm}>
            <form onSubmit={bookingForm.handleSubmit(handleBookingSubmit)} className="space-y-6">
              {/* Pet Selection */}
              <FormField
                control={bookingForm.control}
                name="dogId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Select Your Pet</FormLabel>
                    <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose which pet needs this service" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {pets.map((pet: any) => (
                          <SelectItem key={pet.id} value={pet.id.toString()}>
                            <div className="flex items-center gap-2">
                              <Dog className="h-4 w-4" />
                              {pet.name} - {pet.breed}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Date Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Time Selection for Training/Walking */}
              {(selectedService === "training" || selectedService === "walking") && (
                <FormField
                  control={bookingForm.control}
                  name="serviceTimes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred Time Slots</FormLabel>
                      <div className="grid grid-cols-3 gap-2">
                        {timeSlots.map((time) => (
                          <Button
                            key={time}
                            type="button"
                            variant={field.value?.includes(time) ? "default" : "outline"}
                            className="text-sm"
                            onClick={() => {
                              const current = field.value || [];
                              if (current.includes(time)) {
                                field.onChange(current.filter(t => t !== time));
                              } else {
                                field.onChange([...current, time]);
                              }
                            }}
                          >
                            {time}
                          </Button>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* End Date for Boarding */}
              {selectedService === "boarding" && (
                <FormField
                  control={bookingForm.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Check-out Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className="w-full justify-start text-left font-normal"
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {field.value ? format(new Date(field.value), "PPP") : "Pick check-out date"}
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={field.value ? new Date(field.value) : undefined}
                            onSelect={(date) => field.onChange(date?.toISOString())}
                            disabled={(date) => date < (selectedDate || new Date())}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* Special Notes */}
              <FormField
                control={bookingForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Instructions</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Any special requests or important information for our staff..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Pricing Summary */}
              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Booking Summary</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Service:</span>
                    <span className="capitalize">{selectedService}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Price:</span>
                    <span className="font-semibold">
                      ${services.find(s => s.id === selectedService)?.price}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Date:</span>
                    <span>{selectedDate ? format(selectedDate, "MMM dd, yyyy") : "Not selected"}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setShowBookingForm(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-royal-blue hover:bg-blue-700"
                  disabled={createBookingMutation.isPending || !selectedDate}
                >
                  {createBookingMutation.isPending ? "Confirming..." : "Confirm Booking"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [isAddingClient, setIsAddingClient] = useState(false);
  const [isAddingDog, setIsAddingDog] = useState(false);
  const [viewingClient, setViewingClient] = useState<any>(null);
  const [viewingDog, setViewingDog] = useState<any>(null);
  const [editingDog, setEditingDog] = useState<any>(null);

  const { data: staff = [] } = useQuery({ queryKey: ["/api/staff"] });
  const { data: clients = [] } = useQuery({ queryKey: ["/api/clients"] });
  const { data: dogs = [] } = useQuery({ queryKey: ["/api/dogs"] });
  const { data: kennels = [] } = useQuery({ queryKey: ["/api/kennels"] });

  const updateDogMutation = useMutation({
    mutationFn: ({ id, ...data }: any) => 
      apiRequest("PATCH", `/api/dogs/${id}`, data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      setEditingDog(null);
      toast({
        title: "Dog Updated Successfully! ✓",
        description: "Dog profile has been updated",
      });
    },
    onError: () => {
      toast({
        title: "Error Updating Dog",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleUpdateDog = () => {
    if (!editingDog) return;
    updateDogMutation.mutate(editingDog);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900/30 text-white">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-bold text-transparent bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text">
            VIP Elite K9s Admin Dashboard
          </h1>
          <Button 
            onClick={() => setLocation("/")}
            className="bg-gradient-to-r from-red-500 to-red-700 hover:from-red-600 hover:to-red-800 text-white font-bold"
          >
            Logout
          </Button>
        </div>

        {/* Dog Management */}
        <Card className="bg-black/80 backdrop-blur border-2 border-purple-400">
          <CardHeader>
            <CardTitle className="text-purple-400 text-xl">Dog Management</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dogs.slice(0, 5).map((dog: any) => (
                <div key={dog.id} className="bg-black/60 border border-purple-400/30 rounded-lg p-3 hover:border-purple-400 hover:bg-black/80 transition-all">
                  <div className="flex items-center justify-between">
                    <div 
                      className="flex-1 cursor-pointer"
                      onClick={() => setViewingDog(dog)}
                    >
                      <h4 className="text-white font-medium">{dog.name}</h4>
                      <p className="text-gray-400 text-sm">{dog.breed} • {dog.age ? `${dog.age} years` : 'Age unknown'}</p>
                      <p className="text-gray-500 text-xs">
                        Owner: {clients.find((c: any) => c.id === dog.clientId)?.name || 'Unknown'}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm"
                        onClick={() => setViewingDog(dog)}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Dog Detail Modal */}
        <Dialog open={!!viewingDog} onOpenChange={() => setViewingDog(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400 text-xl">Dog Profile: {viewingDog?.name}</DialogTitle>
            </DialogHeader>
            {viewingDog && (
              <div className="space-y-6">
                <div className="flex items-center space-x-6">
                  <div className="w-32 h-32 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center text-black font-bold text-3xl">
                    🐕
                  </div>
                  <div className="flex-1">
                    <h2 className="text-3xl font-bold text-white">{viewingDog.name}</h2>
                    <p className="text-purple-400 text-lg">{viewingDog.breed}</p>
                    <p className="text-gray-400">
                      Owner: {clients.find((c: any) => c.id === viewingDog.clientId)?.name || 'Unknown'}
                    </p>
                    <div className="flex space-x-3 mt-2">
                      <Badge className="bg-purple-500 text-white">
                        {viewingDog.age ? `${viewingDog.age} years` : 'Age unknown'}
                      </Badge>
                      <Badge className="bg-purple-500 text-white">
                        {viewingDog.weight} {viewingDog.weightUnit || 'lbs'}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Food Type</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white">
                      {viewingDog.foodType || 'Not specified'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Feeding Instructions</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.feedingInstructions || 'No feeding instructions provided'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Exercise Requirements</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.exerciseRequirements || 'No exercise requirements provided'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Behavior Notes</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.behaviorNotes || 'No behavior notes provided'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Allergies</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.allergies || 'No known allergies'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Medication</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.medication || 'No medication required'}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3">
                  <Button 
                    variant="outline"
                    className="border-purple-400 text-purple-400 hover:bg-purple-400/10"
                    onClick={() => setViewingDog(null)}
                  >
                    Close
                  </Button>
                  <Button 
                    onClick={() => {
                      setEditingDog(viewingDog);
                      setViewingDog(null);
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    Edit Profile
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Dog Edit Form Dialog */}
        <Dialog open={!!editingDog} onOpenChange={() => setEditingDog(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Edit Dog Profile: {editingDog?.name}</DialogTitle>
            </DialogHeader>
            {editingDog && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="editDogName" className="text-gray-300">Dog Name</Label>
                    <Input
                      id="editDogName"
                      value={editingDog.name || ""}
                      onChange={(e) => setEditingDog({...editingDog, name: e.target.value})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="editDogBreed" className="text-gray-300">Breed</Label>
                    <Input
                      id="editDogBreed"
                      value={editingDog.breed || ""}
                      onChange={(e) => setEditingDog({...editingDog, breed: e.target.value})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="editDogAge" className="text-gray-300">Age (years)</Label>
                    <Input
                      id="editDogAge"
                      type="number"
                      value={editingDog.age || ""}
                      onChange={(e) => setEditingDog({...editingDog, age: parseInt(e.target.value) || 0})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="editDogWeight" className="text-gray-300">Weight</Label>
                    <Input
                      id="editDogWeight"
                      type="number"
                      value={editingDog.weight || ""}
                      onChange={(e) => setEditingDog({...editingDog, weight: parseFloat(e.target.value) || 0})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="editDogWeightUnit" className="text-gray-300">Unit</Label>
                    <Select value={editingDog.weightUnit || "lbs"} onValueChange={(value) => setEditingDog({...editingDog, weightUnit: value})}>
                      <SelectTrigger className="bg-black/60 border-purple-400/30 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-purple-400 text-white">
                        <SelectItem value="lbs">lbs</SelectItem>
                        <SelectItem value="kg">kg</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="editDogFood" className="text-gray-300">Food Type</Label>
                  <Select value={editingDog.foodType || ""} onValueChange={(value) => setEditingDog({...editingDog, foodType: value})}>
                    <SelectTrigger className="bg-black/60 border-purple-400/30 text-white">
                      <SelectValue placeholder="Select food type" />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-purple-400 text-white">
                      <SelectItem value="Dry Kibble">Dry Kibble</SelectItem>
                      <SelectItem value="Wet Food">Wet Food</SelectItem>
                      <SelectItem value="Raw Diet">Raw Diet</SelectItem>
                      <SelectItem value="Prescription Diet">Prescription Diet</SelectItem>
                      <SelectItem value="Grain-Free">Grain-Free</SelectItem>
                      <SelectItem value="Senior Formula">Senior Formula</SelectItem>
                      <SelectItem value="Puppy Formula">Puppy Formula</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="editFeedingInstructions" className="text-gray-300">Feeding Instructions</Label>
                  <Textarea
                    id="editFeedingInstructions"
                    value={editingDog.feedingInstructions || ""}
                    onChange={(e) => setEditingDog({...editingDog, feedingInstructions: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="editExerciseRequirements" className="text-gray-300">Exercise Requirements</Label>
                  <Textarea
                    id="editExerciseRequirements"
                    value={editingDog.exerciseRequirements || ""}
                    onChange={(e) => setEditingDog({...editingDog, exerciseRequirements: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="editBehaviorNotes" className="text-gray-300">Behavior Notes</Label>
                  <Textarea
                    id="editBehaviorNotes"
                    value={editingDog.behaviorNotes || ""}
                    onChange={(e) => setEditingDog({...editingDog, behaviorNotes: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="editAllergies" className="text-gray-300">Allergies</Label>
                  <Textarea
                    id="editAllergies"
                    value={editingDog.allergies || ""}
                    onChange={(e) => setEditingDog({...editingDog, allergies: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={2}
                  />
                </div>

                <div>
                  <Label htmlFor="editMedication" className="text-gray-300">Medication</Label>
                  <Textarea
                    id="editMedication"
                    value={editingDog.medication || ""}
                    onChange={(e) => setEditingDog({...editingDog, medication: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={2}
                  />
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <Button 
                    variant="outline"
                    className="border-purple-400 text-purple-400 hover:bg-purple-400/10"
                    onClick={() => setEditingDog(null)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleUpdateDog}
                    disabled={updateDogMutation.isPending}
                    className="bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white"
                  >
                    {updateDogMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
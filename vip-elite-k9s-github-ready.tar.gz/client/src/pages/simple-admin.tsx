import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, Users, UserPlus, Home, Coffee, LogOut, UserCheck, ArrowLeft, Trash2, AlertTriangle, Edit, DollarSign } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import logoPath from "@assets/LOGO JPEG.jpg";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [isAddingClient, setIsAddingClient] = useState(false);
  const [isAddingDog, setIsAddingDog] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [viewingClient, setViewingClient] = useState<any>(null);
  const [viewingDog, setViewingDog] = useState<any>(null);
  const [assigningKennel, setAssigningKennel] = useState<any>(null);
  const [selectedDogForKennel, setSelectedDogForKennel] = useState<number>(0);
  const [selectedMultipleDogs, setSelectedMultipleDogs] = useState<number[]>([]);
  const [checkInDate, setCheckInDate] = useState("");
  const [checkOutDate, setCheckOutDate] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [dogSearchQuery, setDogSearchQuery] = useState("");
  const [showSecondDogConfirmation, setShowSecondDogConfirmation] = useState(false);
  const [secondDogCandidate, setSecondDogCandidate] = useState<any>(null);
  
  // Estimate & Invoice states
  const [isCreatingEstimate, setIsCreatingEstimate] = useState(false);
  const [newEstimate, setNewEstimate] = useState({
    clientId: 0,
    dogIds: [] as number[],
    services: [] as string[],
    checkInDate: "",
    checkOutDate: "",
    notes: ""
  });
  const [viewingKennelDetails, setViewingKennelDetails] = useState<any>(null);
  const [kennelChoiceDialog, setKennelChoiceDialog] = useState<any>(null);
  const [editingClient, setEditingClient] = useState<any>(null);
  const [editingDog, setEditingDog] = useState<any>(null);
  const [newStaff, setNewStaff] = useState({
    name: "",
    role: "",
    pin: "",
    phone: "",
    email: ""
  });
  const [newClient, setNewClient] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    emergencyContactName: "",
    emergencyContactPhone: "",
    emergencyContactRelationship: "",
    vetName: "",
    vetPhone: "",
    vetAddress: "",
    password: ""
  });
  const [newDog, setNewDog] = useState({
    name: "",
    breed: "",
    age: "",
    weight: "",
    weightUnit: "lbs",
    foodType: "",
    clientId: 0,
    feedingInstructions: "",
    exerciseRequirements: "",
    behaviorNotes: "",
    allergies: "",
    medication: ""
  });

  const { data: staff = [], isLoading: staffLoading } = useQuery({ 
    queryKey: ["/api/staff"] 
  });

  const { data: clients = [], isLoading: clientsLoading } = useQuery({ 
    queryKey: ["/api/clients"] 
  });

  const { data: dogs = [], isLoading: dogsLoading } = useQuery({ 
    queryKey: ["/api/dogs"] 
  });

  const { data: kennels = [], isLoading: kennelsLoading } = useQuery({ 
    queryKey: ["/api/kennels"] 
  });

  const { data: servicePricing = [] } = useQuery({
    queryKey: ["/api/service-pricing"],
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["/api/bookings"],
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ["/api/invoices"],
  });

  const { data: estimates = [] } = useQuery({
    queryKey: ["/api/estimates"],
  });

  const addStaffMutation = useMutation({
    mutationFn: (staffData: typeof newStaff) => 
      apiRequest("POST", "/api/staff", staffData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
      setIsAddingStaff(false);
      setNewStaff({ name: "", role: "", pin: "", phone: "", email: "" });
      toast({
        title: "Staff Added Successfully! ✓",
        description: "New staff member has been added to the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Adding Staff",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const updateStaffStatusMutation = useMutation({
    mutationFn: ({ id, action }: { id: number; action: string }) => 
      apiRequest("PATCH", `/api/staff/${id}/${action}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
      toast({
        title: "Status Updated ✓",
        description: "Staff status has been updated",
      });
    },
  });

  const addClientMutation = useMutation({
    mutationFn: (clientData: typeof newClient) => 
      apiRequest("POST", "/api/clients", clientData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setIsAddingClient(false);
      setNewClient({ 
        name: "", email: "", phone: "", address: "", emergencyContactName: "", 
        emergencyContactPhone: "", emergencyContactRelationship: "", vetName: "", 
        vetPhone: "", vetAddress: "", password: "" 
      });
      toast({
        title: "Client Added Successfully! ✓",
        description: "New client has been added to the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Adding Client",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const addDogMutation = useMutation({
    mutationFn: (dogData: typeof newDog) => 
      apiRequest("POST", "/api/dogs", dogData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      setIsAddingDog(false);
      setNewDog({
        name: "", breed: "", age: "", weight: "", weightUnit: "lbs", foodType: "", clientId: 0,
        feedingInstructions: "", exerciseRequirements: "", behaviorNotes: "", allergies: "", medication: ""
      });
      toast({
        title: "Dog Added Successfully! ✓",
        description: "New dog has been added to the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Adding Dog",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const deleteClientMutation = useMutation({
    mutationFn: (clientId: number) => 
      apiRequest("DELETE", `/api/clients/${clientId}`),
    onSuccess: async () => {
      // Force immediate cache invalidation and refetch
      await queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      await queryClient.refetchQueries({ queryKey: ["/api/clients"] });
      await queryClient.refetchQueries({ queryKey: ["/api/dogs"] });
      toast({
        title: "Client Removed Successfully! ✓",
        description: "Client and all associated data have been removed",
      });
    },
    onError: () => {
      toast({
        title: "Error Removing Client",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const updateDogMutation = useMutation({
    mutationFn: ({ id, ...data }: any) => 
      apiRequest("PATCH", `/api/dogs/${id}`, data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      await queryClient.refetchQueries({ queryKey: ["/api/dogs"] });
      setEditingDog(null);
      toast({
        title: "Dog Updated Successfully! ✓",
        description: "Dog profile has been updated",
      });
    },
    onError: () => {
      toast({
        title: "Error Updating Dog",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const deleteDogMutation = useMutation({
    mutationFn: (dogId: number) => 
      apiRequest("DELETE", `/api/dogs/${dogId}`),
    onSuccess: async () => {
      // Force immediate cache invalidation and refetch
      await queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      await queryClient.refetchQueries({ queryKey: ["/api/dogs"] });
      toast({
        title: "Dog Removed Successfully! ✓",
        description: "Dog profile has been removed from the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Removing Dog",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const updateClientMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      apiRequest("PATCH", `/api/clients/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setEditingClient(null);
      toast({
        title: "Client Updated Successfully! ✓",
        description: "Client information has been saved",
      });
    },
    onError: () => {
      toast({
        title: "Error Updating Client",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });



  const assignDogToKennelMutation = useMutation({
    mutationFn: ({ kennelId, dogId, checkInDate, checkOutDate }: { 
      kennelId: number; 
      dogId: number; 
      checkInDate: string; 
      checkOutDate: string; 
    }) => 
      apiRequest("POST", "/api/kennels/assign", {
        kennelIds: [kennelId],
        dogIds: [dogId],
        checkInDate,
        checkOutDate
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/kennels"] });
      await queryClient.refetchQueries({ queryKey: ["/api/kennels"] });
      setAssigningKennel(null);
      setSelectedDogForKennel(0);
      setCheckInDate("");
      setCheckOutDate("");
      toast({
        title: "Dog Assigned Successfully! ✓",
        description: "Dog has been checked into the kennel",
      });
    },
    onError: () => {
      toast({
        title: "Assignment Failed",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const createEstimateMutation = useMutation({
    mutationFn: (estimateData: typeof newEstimate) => 
      apiRequest("POST", "/api/estimates", estimateData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      setIsCreatingEstimate(false);
      setNewEstimate({
        clientId: 0,
        dogIds: [],
        services: [],
        checkInDate: "",
        checkOutDate: "",
        notes: ""
      });
      toast({
        title: "Estimate Created Successfully! ✓",
        description: "Cost estimate has been generated and saved",
      });
    },
    onError: () => {
      toast({
        title: "Error Creating Estimate",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const convertToInvoiceMutation = useMutation({
    mutationFn: (invoiceId: number) => 
      apiRequest("PATCH", `/api/invoices/${invoiceId}/convert`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Invoice Created Successfully! ✓",
        description: "Estimate has been converted to an official invoice",
      });
    },
  });

  const handleAddStaff = () => {
    if (!newStaff.name || !newStaff.role || !newStaff.pin) {
      toast({
        title: "Missing Information",
        description: "Please fill in name, role, and PIN",
        variant: "destructive",
      });
      return;
    }
    addStaffMutation.mutate(newStaff);
  };

  const handleAddClient = () => {
    if (!newClient.name || !newClient.email || !newClient.password) {
      toast({
        title: "Missing Information",
        description: "Please fill in name, email, and password",
        variant: "destructive",
      });
      return;
    }
    
    // Send ALL client data including emergency contacts and vet info
    const completeClientData = {
      name: newClient.name,
      email: newClient.email,
      phone: newClient.phone || null,
      address: newClient.address || null,
      password: newClient.password,
      emergencyContactName: newClient.emergencyContactName || null,
      emergencyContactPhone: newClient.emergencyContactPhone || null,
      emergencyContactRelationship: newClient.emergencyContactRelationship || null,
      vetName: newClient.vetName || null,
      vetPhone: newClient.vetPhone || null,
      vetAddress: newClient.vetAddress || null,
    };
    
    addClientMutation.mutate(completeClientData);
  };

  const handleAddDog = () => {
    if (!newDog.name || !newDog.breed || !newDog.clientId) {
      toast({
        title: "Missing Information",
        description: "Please fill in name, breed, and select a client",
        variant: "destructive",
      });
      return;
    }
    addDogMutation.mutate({
      ...newDog,
      age: newDog.age ? parseInt(newDog.age) : undefined,
    });
  };

  const calculateEstimateCost = () => {
    if (!newEstimate.checkInDate || !newEstimate.checkOutDate || newEstimate.services.length === 0) {
      return 0;
    }

    const checkIn = new Date(newEstimate.checkInDate);
    const checkOut = new Date(newEstimate.checkOutDate);
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
    
    let totalCost = 0;
    
    newEstimate.services.forEach(serviceType => {
      const pricing = (servicePricing as any[]).find((p: any) => p.serviceType.toLowerCase() === serviceType.toLowerCase());
      if (pricing) {
        if (serviceType.toLowerCase() === 'boarding') {
          // Boarding is per night per dog - pricing is in pounds, convert properly
          totalCost += pricing.pricePerUnit * nights * newEstimate.dogIds.length;
        } else {
          // Other services are per session per dog - pricing is in pounds
          totalCost += pricing.pricePerUnit * newEstimate.dogIds.length;
        }
      }
    });
    
    return totalCost;
  };

  const handleCreateEstimate = () => {
    if (!newEstimate.clientId || newEstimate.dogIds.length === 0 || !newEstimate.checkInDate || !newEstimate.checkOutDate || newEstimate.services.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields for the estimate",
        variant: "destructive",
      });
      return;
    }
    createEstimateMutation.mutate(newEstimate);
  };

  const handleStatusUpdate = (staffId: number, action: string) => {
    updateStaffStatusMutation.mutate({ id: staffId, action });
  };

  const handleKennelClick = (kennelNumber: number) => {
    // NEW: Always show kennel details with booking queue, regardless of status
    const kennel = kennels.find((k: any) => k.number === kennelNumber) || { number: kennelNumber, status: 'available' };
    setViewingKennelDetails({
      ...kennel,
      bookings: bookings.filter((booking: any) => 
        booking.serviceType === 'boarding' && 
        booking.status !== 'cancelled' &&
        booking.kennelNumber === kennelNumber
      )
    });
  };

  // Create the mutation for multiple dogs at the top level
  const assignMultipleDogsMutation = useMutation({
    mutationFn: ({ kennelId, dogIds, checkInDate, checkOutDate }: { 
      kennelId: number; 
      dogIds: number[]; 
      checkInDate: string; 
      checkOutDate: string; 
    }) => 
      apiRequest("POST", "/api/kennels/assign", {
        kennelIds: [kennelId],
        dogIds: dogIds,
        checkInDate,
        checkOutDate
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/kennels"] });
      await queryClient.refetchQueries({ queryKey: ["/api/kennels"] });
      setAssigningKennel(null);
      setSelectedMultipleDogs([]);
      setSelectedDogForKennel(0);
      setCheckInDate("");
      setCheckOutDate("");
      toast({
        title: "Dogs Assigned Successfully! ✓",
        description: `Dogs have been checked into the kennel`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Assignment Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleAssignDog = () => {
    if (selectedMultipleDogs.length === 0 || !checkInDate || !checkOutDate) {
      toast({
        title: "Missing Information",
        description: "Please select dogs and enter check-in/check-out dates",
        variant: "destructive",
      });
      return;
    }

    // Use the mutation created at the top level
    assignMultipleDogsMutation.mutate({
      kennelId: assigningKennel.id,
      dogIds: selectedMultipleDogs,
      checkInDate,
      checkOutDate
    });
  };

  const confirmSecondDogAssignment = () => {
    setShowSecondDogConfirmation(false);
    assignDogToKennelMutation.mutate({
      kennelId: assigningKennel.id,
      dogId: selectedDogForKennel,
      checkInDate,
      checkOutDate
    });
  };

  const unassignKennelMutation = useMutation({
    mutationFn: (kennelId: number) => 
      apiRequest("PATCH", `/api/kennels/${kennelId}/unassign`),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/kennels"] });
      await queryClient.refetchQueries({ queryKey: ["/api/kennels"] });
      toast({
        title: "Kennel Unassigned ✓",
        description: "Dogs have been checked out successfully",
      });
    },
    onError: () => {
      toast({
        title: "Unassign Failed",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleUnassignKennel = (kennelId: number) => {
    unassignKennelMutation.mutate(kennelId);
  };

  const handleUpdateDog = () => {
    if (!editingDog) return;
    updateDogMutation.mutate(editingDog);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "clocked_in":
        return <Badge className="bg-green-500 text-white">Clocked In</Badge>;
      case "on_break":
        return <Badge className="bg-yellow-500 text-white">On Break</Badge>;
      case "clocked_out":
        return <Badge className="bg-gray-500 text-white">Clocked Out</Badge>;
      default:
        return <Badge className="bg-gray-400 text-white">Unknown</Badge>;
    }
  };

  const filteredStaff = staff.filter(member => {
    if (statusFilter === "all") return true;
    return member.status === statusFilter;
  });

  const clockedInCount = staff.filter(s => s.status === "clocked_in").length;
  const onBreakCount = staff.filter(s => s.status === "on_break").length;

  if (staffLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-yellow-400 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-yellow-400">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 relative">
      {/* Elegant Border Frame */}
      <div className="absolute inset-0 border-8 border-double border-yellow-400 m-4 pointer-events-none"></div>
      <div className="absolute inset-0 border-4 border-yellow-500/30 m-8 pointer-events-none"></div>
      
      {/* Header */}
      <div className="bg-black/90 backdrop-blur shadow-xl border-b-2 border-yellow-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={logoPath} 
                alt="VIP Elite K9s" 
                className="h-12 w-12 rounded-full object-cover border-3 border-yellow-400 shadow-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-yellow-400">👑 Admin Dashboard</h1>
                <p className="text-sm text-gray-300">Staff Management Center</p>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button
                onClick={() => setLocation("/admin/bookings")}
                className="bg-gradient-to-r from-purple-500 to-purple-700 hover:from-purple-600 hover:to-purple-800 text-white font-bold"
              >
                📅 Booking Calendar
              </Button>
              <Button
                onClick={() => setLocation("/admin/pricing-management")}
                className="bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white font-bold"
              >
                <DollarSign className="w-4 h-4 mr-2" />
                💰 Pricing
              </Button>
              <Button
                onClick={() => setLocation("/")}
                variant="outline"
                className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 font-semibold"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Homepage
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 relative z-10">
        {/* Staff Overview Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Total Staff</p>
                  <p className="text-3xl font-bold text-white">{staff.length}</p>
                </div>
                <Users className="w-8 h-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-2 border-green-400">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Clocked In</p>
                  <p className="text-3xl font-bold text-white">{clockedInCount}</p>
                </div>
                <UserCheck className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-2 border-yellow-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-500 text-sm font-medium">On Break</p>
                  <p className="text-3xl font-bold text-white">{onBreakCount}</p>
                </div>
                <Coffee className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
            <CardContent className="p-6">
              <Dialog open={isAddingStaff} onOpenChange={setIsAddingStaff}>
                <DialogTrigger asChild>
                  <Button className="w-full h-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-bold">
                    <UserPlus className="w-6 h-6 mr-2" />
                    Add New Staff
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-black/90 border-2 border-yellow-400 text-white">
                  <DialogHeader>
                    <DialogTitle className="text-yellow-400">Add New Staff Member</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name" className="text-gray-300">Full Name</Label>
                      <Input
                        id="name"
                        value={newStaff.name}
                        onChange={(e) => setNewStaff({...newStaff, name: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="Enter full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="role" className="text-gray-300">Role</Label>
                      <Select onValueChange={(value) => setNewStaff({...newStaff, role: value})}>
                        <SelectTrigger className="bg-black/60 border-yellow-400/50 text-white">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent className="bg-black border-yellow-400 text-white">
                          <SelectItem value="Head Trainer" className="text-white hover:bg-yellow-400/20">Head Trainer</SelectItem>
                          <SelectItem value="Trainer" className="text-white hover:bg-yellow-400/20">Trainer</SelectItem>
                          <SelectItem value="Dog Walker" className="text-white hover:bg-yellow-400/20">Dog Walker</SelectItem>
                          <SelectItem value="Kennel Cleaner" className="text-white hover:bg-yellow-400/20">Kennel Cleaner</SelectItem>
                          <SelectItem value="Media" className="text-white hover:bg-yellow-400/20">Media</SelectItem>
                          <SelectItem value="Decoys" className="text-white hover:bg-yellow-400/20">Decoys</SelectItem>
                          <SelectItem value="Caretaker" className="text-white hover:bg-yellow-400/20">Caretaker</SelectItem>
                          <SelectItem value="Manager" className="text-white hover:bg-yellow-400/20">Manager</SelectItem>
                          <SelectItem value="Receptionist" className="text-white hover:bg-yellow-400/20">Receptionist</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="pin" className="text-gray-300">4-Digit PIN</Label>
                      <Input
                        id="pin"
                        value={newStaff.pin}
                        onChange={(e) => setNewStaff({...newStaff, pin: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="0000"
                        maxLength={4}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-gray-300">Phone (Optional)</Label>
                      <Input
                        id="phone"
                        value={newStaff.phone}
                        onChange={(e) => setNewStaff({...newStaff, phone: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="(555) 123-4567"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="text-gray-300">Email (Optional)</Label>
                      <Input
                        id="email"
                        value={newStaff.email}
                        onChange={(e) => setNewStaff({...newStaff, email: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="email@example.com"
                      />
                    </div>
                    <Button 
                      onClick={handleAddStaff}
                      disabled={addStaffMutation.isPending}
                      className="w-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-bold"
                    >
                      {addStaffMutation.isPending ? "Adding..." : "Add Staff Member"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Staff Management Section */}
        <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-yellow-400 text-xl">Staff Management</CardTitle>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48 bg-black/60 border-yellow-400/50 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-yellow-400">
                  <SelectItem value="all">All Staff</SelectItem>
                  <SelectItem value="clocked_in">Clocked In Only</SelectItem>
                  <SelectItem value="on_break">On Break Only</SelectItem>
                  <SelectItem value="clocked_out">Clocked Out Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {filteredStaff.map((member) => (
                <div key={member.id} className="bg-black/60 border border-yellow-400/30 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-black font-bold text-lg">
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-white font-semibold">{member.name}</h3>
                        <p className="text-gray-400 capitalize">{member.role}</p>
                        <p className="text-gray-500 text-sm">PIN: {member.pin}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {getStatusBadge(member.status)}
                      
                      <div className="flex space-x-2">
                        {member.status === "clocked_out" && (
                          <Button
                            size="sm"
                            onClick={() => handleStatusUpdate(member.id, "clock-in")}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <Clock className="w-4 h-4 mr-1" />
                            Clock In
                          </Button>
                        )}
                        
                        {member.status === "clocked_in" && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "break-start")}
                              className="bg-yellow-600 hover:bg-yellow-700 text-white"
                            >
                              <Coffee className="w-4 h-4 mr-1" />
                              Break
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "clock-out")}
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <LogOut className="w-4 h-4 mr-1" />
                              Clock Out
                            </Button>
                          </>
                        )}
                        
                        {member.status === "on_break" && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "break-end")}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <UserCheck className="w-4 h-4 mr-1" />
                              Return
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "clock-out")}
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <LogOut className="w-4 h-4 mr-1" />
                              Clock Out
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {filteredStaff.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  {statusFilter === "all" 
                    ? "No staff members added yet. Click 'Add New Staff' to get started."
                    : `No staff members with status: ${statusFilter}`
                  }
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Client & Dog Management Section */}
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          {/* Client Management */}
          <Card className="bg-black/80 backdrop-blur border-2 border-blue-400">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-blue-400 text-xl">Client Management</CardTitle>
                <Dialog open={isAddingClient} onOpenChange={setIsAddingClient}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 text-white font-bold">
                      Add Client
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black/90 border-2 border-blue-400 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-blue-400">Add New Client - Boarding Information</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-6">
                      {/* Basic Information */}
                      <div>
                        <h3 className="text-lg font-semibold text-blue-400 mb-3">Basic Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="clientName" className="text-gray-300">Full Name *</Label>
                            <Input
                              id="clientName"
                              value={newClient.name}
                              onChange={(e) => setNewClient({...newClient, name: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="Enter client name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="clientEmail" className="text-gray-300">Email *</Label>
                            <Input
                              id="clientEmail"
                              value={newClient.email}
                              onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="client@example.com"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 mt-4">
                          <div>
                            <Label htmlFor="clientPhone" className="text-gray-300">Phone Number</Label>
                            <Input
                              id="clientPhone"
                              value={newClient.phone}
                              onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="(555) 123-4567"
                            />
                          </div>
                          <div>
                            <Label htmlFor="clientPassword" className="text-gray-300">Password *</Label>
                            <Input
                              id="clientPassword"
                              type="password"
                              value={newClient.password}
                              onChange={(e) => setNewClient({...newClient, password: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="Enter password"
                            />
                          </div>
                        </div>
                        <div className="mt-4">
                          <Label htmlFor="clientAddress" className="text-gray-300">Home Address</Label>
                          <Input
                            id="clientAddress"
                            value={newClient.address}
                            onChange={(e) => setNewClient({...newClient, address: e.target.value})}
                            className="bg-black/60 border-blue-400/50 text-white"
                            placeholder="123 Main Street, City, State, ZIP"
                          />
                        </div>
                      </div>

                      {/* Emergency Contact */}
                      <div>
                        <h3 className="text-lg font-semibold text-yellow-400 mb-3">Emergency Contact</h3>
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <Label htmlFor="emergencyName" className="text-gray-300">Contact Name</Label>
                            <Input
                              id="emergencyName"
                              value={newClient.emergencyContactName}
                              onChange={(e) => setNewClient({...newClient, emergencyContactName: e.target.value})}
                              className="bg-black/60 border-yellow-400/50 text-white"
                              placeholder="Emergency contact name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="emergencyPhone" className="text-gray-300">Contact Phone</Label>
                            <Input
                              id="emergencyPhone"
                              value={newClient.emergencyContactPhone}
                              onChange={(e) => setNewClient({...newClient, emergencyContactPhone: e.target.value})}
                              className="bg-black/60 border-yellow-400/50 text-white"
                              placeholder="(555) 987-6543"
                            />
                          </div>
                          <div>
                            <Label htmlFor="emergencyRelationship" className="text-gray-300">Relationship</Label>
                            <Input
                              id="emergencyRelationship"
                              value={newClient.emergencyContactRelationship}
                              onChange={(e) => setNewClient({...newClient, emergencyContactRelationship: e.target.value})}
                              className="bg-black/60 border-yellow-400/50 text-white"
                              placeholder="Spouse, Parent, etc."
                            />
                          </div>
                        </div>
                      </div>

                      {/* Veterinarian Information */}
                      <div>
                        <h3 className="text-lg font-semibold text-green-400 mb-3">Veterinarian Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="vetName" className="text-gray-300">Vet Clinic Name</Label>
                            <Input
                              id="vetName"
                              value={newClient.vetName}
                              onChange={(e) => setNewClient({...newClient, vetName: e.target.value})}
                              className="bg-black/60 border-green-400/50 text-white"
                              placeholder="Animal Hospital Name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="vetPhone" className="text-gray-300">Vet Phone Number</Label>
                            <Input
                              id="vetPhone"
                              value={newClient.vetPhone}
                              onChange={(e) => setNewClient({...newClient, vetPhone: e.target.value})}
                              className="bg-black/60 border-green-400/50 text-white"
                              placeholder="(555) 111-2222"
                            />
                          </div>
                        </div>
                        <div className="mt-4">
                          <Label htmlFor="vetAddress" className="text-gray-300">Vet Clinic Address</Label>
                          <Input
                            id="vetAddress"
                            value={newClient.vetAddress}
                            onChange={(e) => setNewClient({...newClient, vetAddress: e.target.value})}
                            className="bg-black/60 border-green-400/50 text-white"
                            placeholder="Veterinary clinic address"
                          />
                        </div>
                      </div>

                      <Button 
                        onClick={handleAddClient}
                        disabled={addClientMutation.isPending}
                        className="w-full bg-gradient-to-r from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 text-white font-bold py-3"
                      >
                        {addClientMutation.isPending ? "Adding Client..." : "Add Client with Boarding Info"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-scroll">
                {clients.map((client: any) => (
                  <div key={client.id} className="bg-black/60 border border-blue-400/30 rounded-lg p-3 hover:border-blue-400 hover:bg-black/80 transition-all">
                    <div className="flex items-center justify-between">
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => setViewingClient(client)}
                      >
                        <h4 className="text-white font-medium">{client.name}</h4>
                        <p className="text-gray-400 text-sm">{client.email}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-blue-500 text-white">
                          {dogs.filter((dog: any) => dog.clientId === client.id).length} dogs
                        </Badge>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-green-400 text-green-400 hover:bg-green-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingClient(client);
                          }}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (window.confirm(`Are you sure you want to remove ${client.name}? This will also remove all their dogs and cannot be undone.`)) {
                              deleteClientMutation.mutate(client.id);
                            }
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {clients.length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    No clients added yet. Click 'Add Client' to get started.
                  </div>
                )}
                {clients.length > 5 && (
                  <div className="text-center text-blue-400 text-sm">
                    + {clients.length - 5} more clients
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Dog Management */}
          <Card className="bg-black/80 backdrop-blur border-2 border-purple-400">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-purple-400 text-xl">Dog Management</CardTitle>
                <Dialog open={isAddingDog} onOpenChange={setIsAddingDog}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white font-bold">
                      Add Dog
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-purple-400">Add New Dog</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="dogName" className="text-gray-300">Dog Name</Label>
                          <Input
                            id="dogName"
                            value={newDog.name}
                            onChange={(e) => setNewDog({...newDog, name: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="Enter dog name"
                          />
                        </div>
                        <div>
                          <Label htmlFor="dogBreed" className="text-gray-300">Breed</Label>
                          <Input
                            id="dogBreed"
                            value={newDog.breed}
                            onChange={(e) => setNewDog({...newDog, breed: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="Golden Retriever"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="dogAge" className="text-gray-300">Age (years)</Label>
                          <Input
                            id="dogAge"
                            value={newDog.age}
                            onChange={(e) => setNewDog({...newDog, age: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="3"
                          />
                        </div>
                        <div>
                          <Label htmlFor="dogWeight" className="text-gray-300">Weight</Label>
                          <div className="flex gap-2">
                            <Input
                              id="dogWeight"
                              value={newDog.weight}
                              onChange={(e) => setNewDog({...newDog, weight: e.target.value})}
                              className="bg-black/60 border-purple-400/50 text-white flex-1"
                              placeholder="65"
                            />
                            <Select value={newDog.weightUnit} onValueChange={(value) => setNewDog({...newDog, weightUnit: value})}>
                              <SelectTrigger className="w-20 bg-black/60 border-purple-400/50 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-black border-purple-400">
                                <SelectItem value="lbs" className="text-white hover:bg-purple-600 focus:bg-purple-600">lbs</SelectItem>
                                <SelectItem value="kg" className="text-white hover:bg-purple-600 focus:bg-purple-600">kg</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="dogClient" className="text-gray-300">Owner</Label>
                          <Select onValueChange={(value) => setNewDog({...newDog, clientId: parseInt(value)})}>
                            <SelectTrigger className="bg-black/60 border-purple-400/50 text-white">
                              <SelectValue placeholder="Select owner" />
                            </SelectTrigger>
                            <SelectContent className="bg-black border-purple-400">
                              {clients.map((client: any) => (
                                <SelectItem key={client.id} value={client.id.toString()} className="text-white hover:bg-purple-600 focus:bg-purple-600">
                                  {client.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="foodType" className="text-gray-300">Food Type</Label>
                          <Select value={newDog.foodType} onValueChange={(value) => setNewDog({...newDog, foodType: value})}>
                            <SelectTrigger className="bg-black/60 border-purple-400/50 text-white">
                              <SelectValue placeholder="Select food type" />
                            </SelectTrigger>
                            <SelectContent className="bg-black border-purple-400">
                              <SelectItem value="raw" className="text-white hover:bg-purple-600 focus:bg-purple-600">Raw Diet</SelectItem>
                              <SelectItem value="dry" className="text-white hover:bg-purple-600 focus:bg-purple-600">Dry Kibble</SelectItem>
                              <SelectItem value="wet" className="text-white hover:bg-purple-600 focus:bg-purple-600">Wet/Canned</SelectItem>
                              <SelectItem value="freeze-dried" className="text-white hover:bg-purple-600 focus:bg-purple-600">Freeze-Dried</SelectItem>
                              <SelectItem value="homemade" className="text-white hover:bg-purple-600 focus:bg-purple-600">Homemade</SelectItem>
                              <SelectItem value="prescription" className="text-white hover:bg-purple-600 focus:bg-purple-600">Prescription Diet</SelectItem>
                              <SelectItem value="mixed" className="text-white hover:bg-purple-600 focus:bg-purple-600">Mixed Diet</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="feedingInstructions" className="text-gray-300">Feeding Instructions</Label>
                          <Input
                            id="feedingInstructions"
                            value={newDog.feedingInstructions}
                            onChange={(e) => setNewDog({...newDog, feedingInstructions: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="2 cups twice daily"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="exerciseRequirements" className="text-gray-300">Exercise Requirements</Label>
                        <Input
                          id="exerciseRequirements"
                          value={newDog.exerciseRequirements}
                          onChange={(e) => setNewDog({...newDog, exerciseRequirements: e.target.value})}
                          className="bg-black/60 border-purple-400/50 text-white"
                          placeholder="2 walks daily, 30 minutes each"
                        />
                      </div>

                      <div>
                        <Label htmlFor="behaviorNotes" className="text-gray-300">Behavior Notes</Label>
                        <Input
                          id="behaviorNotes"
                          value={newDog.behaviorNotes}
                          onChange={(e) => setNewDog({...newDog, behaviorNotes: e.target.value})}
                          className="bg-black/60 border-purple-400/50 text-white"
                          placeholder="Friendly, good with children"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="allergies" className="text-gray-300">Allergies</Label>
                          <Input
                            id="allergies"
                            value={newDog.allergies}
                            onChange={(e) => setNewDog({...newDog, allergies: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="None known"
                          />
                        </div>
                        <div>
                          <Label htmlFor="medication" className="text-gray-300">Medication</Label>
                          <Input
                            id="medication"
                            value={newDog.medication}
                            onChange={(e) => setNewDog({...newDog, medication: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="None"
                          />
                        </div>
                      </div>

                      <Button 
                        onClick={handleAddDog}
                        disabled={addDogMutation.isPending}
                        className="w-full bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white font-bold"
                      >
                        {addDogMutation.isPending ? "Adding..." : "Add Dog"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dogs.slice(0, 5).map((dog: any) => (
                  <div key={dog.id} className="bg-black/60 border border-purple-400/30 rounded-lg p-3 hover:border-purple-400 hover:bg-black/80 transition-all">
                    <div className="flex items-center justify-between">
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => setViewingDog(dog)}
                      >
                        <h4 className="text-white font-medium">{dog.name}</h4>
                        <p className="text-gray-400 text-sm">{dog.breed} • {dog.age ? `${dog.age} years` : 'Age unknown'}</p>
                        <p className="text-gray-500 text-xs">
                          Owner: {clients.find((c: any) => c.id === dog.clientId)?.name || 'Unknown'}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-right">
                          <Badge className="bg-purple-500 text-white">
                            {dog.weight || 'Weight unknown'}
                          </Badge>
                          {dog.medication && (
                            <div className="text-xs text-yellow-400 mt-1">Medication</div>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (window.confirm(`Are you sure you want to remove ${dog.name} from the system? This cannot be undone.`)) {
                              deleteDogMutation.mutate(dog.id);
                            }
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {dogs.length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    No dogs added yet. Click 'Add Dog' to get started.
                  </div>
                )}
                {dogs.length > 5 && (
                  <div className="text-center text-purple-400 text-sm">
                    + {dogs.length - 5} more dogs
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Client Detail Modal */}
        <Dialog open={!!viewingClient} onOpenChange={() => setViewingClient(null)}>
          <DialogContent className="bg-black/90 border-2 border-blue-400 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-blue-400 text-xl">Client Profile: {viewingClient?.name}</DialogTitle>
            </DialogHeader>
            {viewingClient && (
              <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-2">
                <div className="flex items-center space-x-6">
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-black font-bold text-2xl">
                    {viewingClient.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-white">{viewingClient.name}</h2>
                    <p className="text-blue-400">{viewingClient.email}</p>
                    <p className="text-gray-400">{viewingClient.phone || 'No phone number'}</p>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                    📷 Add Photo
                  </Button>
                </div>

                {/* Basic Information */}
                <div className="border-b border-blue-400/30 pb-4">
                  <h3 className="text-blue-400 font-semibold mb-3">📋 Basic Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Email Address</Label>
                      <div className="bg-black/60 border border-blue-400/30 rounded p-2 text-white">
                        {viewingClient.email}
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Phone Number</Label>
                      <div className="bg-black/60 border border-blue-400/30 rounded p-2 text-white">
                        {viewingClient.phone || 'Not provided'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Label className="text-gray-300">Address</Label>
                    <div className="bg-black/60 border border-blue-400/30 rounded p-2 text-white">
                      {viewingClient.address || 'No address provided'}
                    </div>
                  </div>
                </div>

                {/* Emergency Contact */}
                <div className="border-b border-yellow-400/30 pb-4">
                  <h3 className="text-yellow-400 font-semibold mb-3">🚨 Emergency Contact</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Contact Name</Label>
                      <div className="bg-black/60 border border-yellow-400/30 rounded p-2 text-white">
                        {viewingClient.emergencyContactName || 'Not provided'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Contact Phone</Label>
                      <div className="bg-black/60 border border-yellow-400/30 rounded p-2 text-white">
                        {viewingClient.emergencyContactPhone || 'Not provided'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Label className="text-gray-300">Relationship</Label>
                    <div className="bg-black/60 border border-yellow-400/30 rounded p-2 text-white">
                      {viewingClient.emergencyContactRelationship || 'Not specified'}
                    </div>
                  </div>
                </div>

                {/* Veterinarian Information */}
                <div className="border-b border-green-400/30 pb-4">
                  <h3 className="text-green-400 font-semibold mb-3">🏥 Veterinarian Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Vet Clinic Name</Label>
                      <div className="bg-black/60 border border-green-400/30 rounded p-2 text-white">
                        {viewingClient.vetName || 'Not provided'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Vet Phone</Label>
                      <div className="bg-black/60 border border-green-400/30 rounded p-2 text-white">
                        {viewingClient.vetPhone || 'Not provided'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Label className="text-gray-300">Vet Address</Label>
                    <div className="bg-black/60 border border-green-400/30 rounded p-2 text-white">
                      {viewingClient.vetAddress || 'No address provided'}
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Their Dogs</Label>
                  <div className="space-y-2 mt-2">
                    {dogs.filter((dog: any) => dog.clientId === viewingClient.id).map((dog: any) => (
                      <div key={dog.id} className="bg-black/60 border border-purple-400/30 rounded-lg p-3 flex justify-between items-center">
                        <div>
                          <h4 className="text-white font-medium">{dog.name}</h4>
                          <p className="text-gray-400 text-sm">{dog.breed} • {dog.age ? `${dog.age} years` : 'Age unknown'}</p>
                        </div>
                        <Button 
                          size="sm"
                          onClick={() => setViewingDog(dog)}
                          className="bg-purple-600 hover:bg-purple-700 text-white"
                        >
                          View Details
                        </Button>
                      </div>
                    ))}
                    {dogs.filter((dog: any) => dog.clientId === viewingClient.id).length === 0 && (
                      <p className="text-gray-400 text-center py-4">No dogs registered yet</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Dog Detail Modal */}
        <Dialog open={!!viewingDog} onOpenChange={() => setViewingDog(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400 text-xl">Dog Profile: {viewingDog?.name}</DialogTitle>
            </DialogHeader>
            {viewingDog && (
              <div className="space-y-6">
                <div className="flex items-center space-x-6">
                  <div className="w-32 h-32 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center text-black font-bold text-3xl">
                    🐕
                  </div>
                  <div className="flex-1">
                    <h2 className="text-3xl font-bold text-white">{viewingDog.name}</h2>
                    <p className="text-purple-400 text-lg">{viewingDog.breed}</p>
                    <p className="text-gray-400">
                      Owner: {clients.find((c: any) => c.id === viewingDog.clientId)?.name || 'Unknown'}
                    </p>
                    <div className="flex space-x-3 mt-2">
                      <Badge className="bg-purple-500 text-white">
                        {viewingDog.age ? `${viewingDog.age} years` : 'Age unknown'}
                      </Badge>
                      <Badge className="bg-purple-500 text-white">
                        {viewingDog.weight || 'Weight unknown'}
                      </Badge>
                    </div>
                  </div>
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    📷 Add Photo
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Feeding Instructions</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.feedingInstructions || 'No feeding instructions provided'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Exercise Requirements</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.exerciseRequirements || 'No exercise requirements provided'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Behavior Notes</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.behaviorNotes || 'No behavior notes provided'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Allergies</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.allergies || 'No known allergies'}
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Medication</Label>
                  <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                    {viewingDog.medication || 'No medication required'}
                  </div>
                </div>

                <div className="flex justify-end space-x-3">
                  <Button 
                    variant="outline"
                    className="border-purple-400 text-purple-400 hover:bg-purple-400/10"
                    onClick={() => setViewingDog(null)}
                  >
                    Close
                  </Button>
                  <Button 
                    onClick={() => {
                      setEditingDog(viewingDog);
                      setViewingDog(null);
                    }}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    Edit Profile
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Kennel Management Section */}
        <div className="mt-6">
          <Card className="bg-black/90 border-2 border-purple-400">
            <CardHeader>
              <CardTitle className="text-purple-400 text-xl flex items-center">
                🏠 Kennel Management (20 Kennels)
                <Badge className="ml-auto bg-purple-600 text-white">
                  {kennels.filter((k: any) => k.status === 'occupied').length} Occupied
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {kennelsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-purple-400 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <div className="grid grid-cols-5 gap-3">
                  {Array.from({ length: 20 }, (_, i) => {
                    const kennelNumber = i + 1;
                    const kennel = kennels.find((k: any) => k.number === kennelNumber);
                    
                    // NEW: Get dogs for this kennel based on ACTUAL BOOKINGS
                    const kennelBookings = bookings.filter((booking: any) => 
                      booking.serviceType === 'boarding' && 
                      booking.status !== 'cancelled' &&
                      booking.kennelNumber === kennelNumber
                    );
                    
                    const assignedDogs = kennelBookings.map((booking: any) => 
                      dogs.find((d: any) => d.id === booking.dogId)
                    ).filter(Boolean);
                    
                    const dogCount = assignedDogs.length;
                    const getKennelStyle = () => {
                      if (kennel?.status === 'cleaning') return 'border-yellow-400 bg-yellow-900/20';
                      if (dogCount === 0) return 'border-green-400 bg-green-900/20 hover:bg-green-800/30';
                      if (dogCount === 1) return 'border-red-400 bg-red-900/20';
                      if (dogCount === 2) return 'border-orange-400 bg-orange-900/20';
                      return 'border-gray-400 bg-gray-900/20';
                    };

                    const getStatusText = () => {
                      if (kennel?.status === 'cleaning') return 'Cleaning';
                      if (dogCount === 0) return 'Available';
                      
                      // NEW: Check ACTUAL booking dates to determine current vs pending
                      const today = new Date();
                      today.setHours(0, 0, 0, 0);
                      
                      let currentCount = 0;
                      let pendingCount = 0;
                      
                      kennelBookings.forEach((booking: any) => {
                        const checkIn = new Date(booking.startDate || booking.checkInDate);
                        const checkOut = new Date(booking.endDate || booking.checkOutDate);
                        checkIn.setHours(0, 0, 0, 0);
                        checkOut.setHours(23, 59, 59, 999);
                        
                        if (today >= checkIn && today <= checkOut) {
                          currentCount++; // Dog is currently checked in
                        } else if (checkIn > today) {
                          pendingCount++; // Future booking
                        }
                      });
                      
                      if (currentCount > 0 && pendingCount > 0) {
                        return `Current + ${pendingCount} Pending`;
                      } else if (currentCount > 0) {
                        return `${currentCount} Occupied`;
                      } else if (pendingCount > 0) {
                        return `${pendingCount} Pending`;
                      } else {
                        return 'Available';
                      }
                    };

                    const getStatusColor = () => {
                      if (kennel?.status === 'cleaning') return 'text-yellow-300';
                      if (dogCount === 0) return 'text-green-300';
                      if (dogCount === 1) return 'text-red-300';
                      if (dogCount === 2) return 'text-orange-300';
                      return 'text-gray-300';
                    };
                    
                    return (
                      <div
                        key={kennelNumber}
                        className={`
                          relative border-2 rounded-lg p-2 h-28 cursor-pointer transition-all hover:scale-105
                          ${getKennelStyle()}
                        `}
                        onClick={() => handleKennelClick(kennelNumber)}
                      >
                        <div className="text-center h-full flex flex-col justify-between">
                          <div className="text-white font-bold text-sm">#{kennelNumber}</div>
                          <div className={`text-xs font-medium ${getStatusColor()}`}>
                            {getStatusText()}
                          </div>
                          
                          {/* NEW: Display dogs based on actual booking status */}
                          {kennelBookings.length > 0 && (
                            <div className="text-white text-xs space-y-0.5">
                              {(() => {
                                const today = new Date();
                                today.setHours(0, 0, 0, 0);
                                
                                // Find currently checked in dog
                                const currentBooking = kennelBookings.find((booking: any) => {
                                  const checkIn = new Date(booking.startDate || booking.checkInDate);
                                  const checkOut = new Date(booking.endDate || booking.checkOutDate);
                                  checkIn.setHours(0, 0, 0, 0);
                                  checkOut.setHours(23, 59, 59, 999);
                                  return today >= checkIn && today <= checkOut;
                                });
                                
                                if (currentBooking) {
                                  const currentDog = dogs.find((d: any) => d.id === currentBooking.dogId);
                                  return (
                                    <div className="truncate font-medium">
                                      {currentDog?.name}
                                    </div>
                                  );
                                } else {
                                  // Show next upcoming dog
                                  const upcomingBooking = kennelBookings
                                    .filter((booking: any) => {
                                      const checkIn = new Date(booking.startDate || booking.checkInDate);
                                      return checkIn > today;
                                    })
                                    .sort((a: any, b: any) => {
                                      const dateA = new Date(a.startDate || a.checkInDate);
                                      const dateB = new Date(b.startDate || b.checkInDate);
                                      return dateA.getTime() - dateB.getTime();
                                    })[0];
                                  
                                  if (upcomingBooking) {
                                    const upcomingDog = dogs.find((d: any) => d.id === upcomingBooking.dogId);
                                    const checkInDate = new Date(upcomingBooking.startDate || upcomingBooking.checkInDate);
                                    return (
                                      <div className="truncate">
                                        <div className="font-medium">{upcomingDog?.name}</div>
                                        <div className="text-gray-400 text-xs">
                                          {checkInDate.toLocaleDateString()}
                                        </div>
                                      </div>
                                    );
                                  }
                                }
                                return null;
                              })()}
                            </div>
                          )}

                          {/* Status indicator */}
                          <div className={`absolute bottom-1 right-1 w-2 h-2 rounded-full ${
                            kennel?.status === 'cleaning' ? 'bg-yellow-400' :
                            dogCount === 0 ? 'bg-green-400' :
                            dogCount === 1 ? 'bg-red-400' :
                            dogCount >= 2 ? 'bg-orange-400' :
                            'bg-green-400'
                          }`}></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-purple-400/30">
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
                    <span className="text-green-300">Available ({kennels.filter((k: any) => k.status === 'available').length})</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-400 rounded-full mr-2"></div>
                    <span className="text-red-300">Occupied ({kennels.filter((k: any) => k.status === 'occupied').length})</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-yellow-400 rounded-full mr-2"></div>
                    <span className="text-yellow-300">Cleaning ({kennels.filter((k: any) => k.status === 'cleaning').length})</span>
                  </div>
                </div>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                  🐕 Assign Dog to Kennel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Estimates & Invoicing Section */}
        <div className="grid gap-6 mb-8">
          <Card className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border-2 border-cyan-400 shadow-2xl shadow-cyan-500/20">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-cyan-400 flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-cyan-600 rounded-lg flex items-center justify-center mr-4">
                  💰
                </div>
                Estimates & Invoicing
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                {/* Create New Estimate */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-cyan-300 text-lg font-semibold">Create New Estimate</h3>
                    <Button
                      onClick={() => setIsCreatingEstimate(true)}
                      className="bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                    >
                      ➕ New Estimate
                    </Button>
                  </div>
                  
                  {/* Live Cost Calculator */}
                  {newEstimate.checkInDate && newEstimate.checkOutDate && newEstimate.services.length > 0 && newEstimate.dogIds.length > 0 && (
                    <div className="bg-cyan-500/10 border border-cyan-400/30 rounded-lg p-4">
                      <h4 className="text-cyan-300 font-medium mb-2">💡 Live Cost Preview</h4>
                      <div className="text-2xl font-bold text-cyan-400">
                        £{calculateEstimateCost().toFixed(2)}
                      </div>
                      <div className="text-sm text-gray-300 mt-1">
                        {Math.ceil((new Date(newEstimate.checkOutDate).getTime() - new Date(newEstimate.checkInDate).getTime()) / (1000 * 60 * 60 * 24))} nights • {newEstimate.dogIds.length} dog{newEstimate.dogIds.length === 1 ? '' : 's'} • {newEstimate.services.length} service{newEstimate.services.length === 1 ? '' : 's'}
                      </div>
                    </div>
                  )}
                </div>

                {/* Active Booking Estimates */}
                <div className="space-y-4">
                  <h3 className="text-cyan-300 text-lg font-semibold">Active Booking Estimates</h3>
                  <div className="max-h-64 overflow-y-auto space-y-3">
                    {kennels.filter((k: any) => k.status === 'occupied' && k.dogIds?.length > 0).map((kennel: any) => {
                      const assignedDogIds = kennel.dogIds || [];
                      const assignedDogs = assignedDogIds.map((dogId: number) => 
                        dogs.find((d: any) => d.id === dogId)
                      ).filter(Boolean);
                      
                      if (kennel.checkInDate && kennel.checkOutDate) {
                        const checkIn = new Date(kennel.checkInDate);
                        const checkOut = new Date(kennel.checkOutDate);
                        const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
                        const boardingService = servicePricing.find((s: any) => s.serviceType === 'boarding');
                        const pricePerNight = boardingService ? boardingService.basePrice / 100 : 40;
                        
                        // Create separate estimate for each dog
                        return assignedDogs.map((dog: any, index: number) => {
                          const costPerDog = pricePerNight * nights;
                          const client = clients.find((c: any) => c.id === dog?.clientId);
                          
                          return (
                            <div key={`${kennel.id}-${dog.id}`} className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-400/30 rounded-lg p-3">
                              <div className="flex justify-between items-start">
                                <div>
                                  <div className="text-white font-semibold">Kennel #{kennel.number} - {dog?.name}</div>
                                  <div className="text-cyan-300 text-sm">
                                    {client?.name || 'Unknown Client'}
                                  </div>
                                  <div className="text-gray-400 text-xs">
                                    {checkIn.toLocaleDateString()} → {checkOut.toLocaleDateString()}
                                  </div>
                                  <div className="text-gray-400 text-xs">
                                    {nights} night{nights === 1 ? '' : 's'} • Boarding Service
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-cyan-400 font-bold text-lg">
                                    £{costPerDog.toFixed(0)}
                                  </div>
                                  <div className="text-gray-400 text-xs">
                                    £{pricePerNight}/night
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        });
                      }
                      return null;
                    }).flat()}
                    
                    {kennels.filter((k: any) => k.status === 'occupied' && k.dogIds?.length > 0).length === 0 && (
                      <div className="text-gray-400 text-center py-4">
                        No active kennel bookings
                      </div>
                    )}
                  </div>
                </div>
                  
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-cyan-300 text-lg font-semibold">Financial Management</h3>
                    <Button 
                      size="sm" 
                      className="bg-cyan-600 hover:bg-cyan-700 text-white"
                      onClick={() => {/* TODO: Open detailed financial view */}}
                    >
                      View All
                    </Button>
                  </div>
                  
                  <div className="max-h-80 overflow-y-auto space-y-3">
                    {estimates.length === 0 && invoices.length === 0 ? (
                      <div className="text-gray-400 text-center py-6 border border-dashed border-gray-600 rounded-lg">
                        <DollarSign className="w-8 h-8 mx-auto mb-2 text-gray-500" />
                        <div>No estimates or invoices yet</div>
                        <div className="text-sm">They'll appear here when bookings are made</div>
                      </div>
                    ) : (
                      // Group by client for better organization
                      (() => {
                        const grouped = new Map();
                        
                        // Group estimates by client
                        estimates.forEach((estimate: any) => {
                          const clientId = estimate.clientId;
                          if (!grouped.has(clientId)) {
                            grouped.set(clientId, { estimates: [], invoices: [] });
                          }
                          grouped.get(clientId).estimates.push(estimate);
                        });
                        
                        // Group invoices by client
                        invoices.forEach((invoice: any) => {
                          const clientId = invoice.clientId;
                          if (!grouped.has(clientId)) {
                            grouped.set(clientId, { estimates: [], invoices: [] });
                          }
                          grouped.get(clientId).invoices.push(invoice);
                        });
                        
                        return Array.from(grouped.entries()).map(([clientId, data]: [any, any]) => {
                          const client = clients.find((c: any) => c.id === parseInt(clientId));
                          const clientName = client?.name || 'Unknown Client';
                          
                          return (
                            <div key={`client-${clientId}`} className="bg-gray-900/40 border border-gray-700 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-3">
                                <h4 className="font-semibold text-white">{clientName}</h4>
                                <div className="text-sm text-gray-400">
                                  {data.estimates.length + data.invoices.length} items
                                </div>
                              </div>
                              
                              <div className="space-y-2">
                                {/* Estimates */}
                                {data.estimates.map((estimate: any) => (
                                  <div key={`est-${estimate.id}`} className="bg-green-900/20 border border-green-500/30 rounded p-3 flex items-center justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <Badge className="bg-green-600 text-white text-xs">EST</Badge>
                                        <span className="font-medium text-green-400">#{estimate.id}</span>
                                        <span className="text-sm text-gray-400">
                                          {new Date(estimate.createdAt).toLocaleDateString()}
                                        </span>
                                      </div>
                                      <div className="text-sm text-gray-300 mt-1">
                                        £{(estimate.totalAmount / 100).toFixed(2)} • {estimate.nights} nights • {estimate.serviceType}
                                      </div>
                                    </div>
                                    <div className="flex gap-1">
                                      <Button
                                        size="sm"
                                        className="bg-green-600 hover:bg-green-700 text-white text-xs"
                                        onClick={() => {/* TODO: Convert to invoice */}}
                                      >
                                        → Invoice
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="destructive"
                                        className="text-xs"
                                        onClick={async () => {
                                          if (window.confirm('Cancel this estimate? This will remove the estimate and associated booking from the calendar.')) {
                                            try {
                                              console.log(`🚫 Frontend: Cancelling estimate ${estimate.id}...`);
                                              
                                              // First delete the estimate, then delete associated booking
                                              const deleteEstimateResponse = await fetch(`/api/estimates/${estimate.id}`, { 
                                                method: 'DELETE' 
                                              });
                                              
                                              if (deleteEstimateResponse.ok) {
                                                console.log('✅ Estimate deleted successfully');
                                                
                                                // If there's a booking associated, delete it too
                                                if (estimate.bookingId) {
                                                  const deleteBookingResponse = await fetch(`/api/bookings/${estimate.bookingId}`, { 
                                                    method: 'DELETE' 
                                                  });
                                                  
                                                  if (deleteBookingResponse.ok) {
                                                    console.log('✅ Associated booking deleted successfully');
                                                  } else {
                                                    console.log('⚠️ Estimate deleted but booking deletion failed');
                                                  }
                                                }
                                                
                                                console.log('✅ Estimate successfully cancelled!');
                                                // Refresh all relevant data
                                                queryClient.invalidateQueries({ queryKey: ['/api/estimates'] });
                                                queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
                                                queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
                                              } else {
                                                console.error('❌ Cancellation failed:', result.message);
                                                alert('Failed to cancel estimate: ' + result.message);
                                              }
                                            } catch (error) {
                                              console.error('❌ Frontend cancellation error:', error);
                                              alert('Failed to cancel estimate');
                                            }
                                          }
                                        }}
                                      >
                                        Cancel
                                      </Button>
                                    </div>
                                  </div>
                                ))}
                                
                                {/* Invoices */}
                                {data.invoices.map((invoice: any) => (
                                  <div key={`inv-${invoice.id}`} className="bg-blue-900/20 border border-blue-500/30 rounded p-3 flex items-center justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <Badge className="bg-blue-600 text-white text-xs">INV</Badge>
                                        <span className="font-medium text-blue-400">#{invoice.id}</span>
                                        <span className="text-sm text-gray-400">
                                          {new Date(invoice.issueDate).toLocaleDateString()}
                                        </span>
                                      </div>
                                      <div className="text-sm text-gray-300 mt-1">
                                        £{(invoice.amount / 100).toFixed(2)} • Status: {invoice.status}
                                      </div>
                                    </div>
                                    <Badge 
                                      className={`text-xs ${
                                        invoice.status === 'paid' ? 'bg-green-600' : 
                                        invoice.status === 'partially_paid' ? 'bg-yellow-600' : 'bg-gray-600'
                                      } text-white`}
                                    >
                                      {invoice.status}
                                    </Badge>
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        });
                      })()
                    )}
                  </div>
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Dog Assignment Dialog */}
        <Dialog open={!!assigningKennel} onOpenChange={() => setAssigningKennel(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="text-purple-400 text-xl">
                🐕 Add Booking to Kennel #{assigningKennel?.number}
              </DialogTitle>
              {assigningKennel?.status === 'occupied' && assigningKennel?.dogIds?.length > 0 && checkInDate && checkOutDate && (() => {
                const newCheckIn = new Date(checkInDate);
                const newCheckOut = new Date(checkOutDate);
                const existingCheckIn = new Date(assigningKennel.checkInDate);
                const existingCheckOut = new Date(assigningKennel.checkOutDate);
                const hasOverlap = newCheckIn < existingCheckOut && newCheckOut > existingCheckIn;
                
                if (hasOverlap) {
                  const existingDog = dogs.find((d: any) => d.id === assigningKennel.dogIds[0]);
                  return (
                    <div className="bg-red-600/20 border border-red-500 rounded p-3 mt-2">
                      <p className="text-red-300 text-sm">
                        ⚠️ Date conflict: {existingDog?.name} is in this kennel until {new Date(assigningKennel.checkOutDate).toLocaleDateString()}
                      </p>
                    </div>
                  );
                } else {
                  return (
                    <div className="bg-green-600/20 border border-green-500 rounded p-3 mt-2">
                      <p className="text-green-300 text-sm">
                        ✅ Available for your dates - current booking ends before your check-in
                      </p>
                    </div>
                  );
                }
              })()}
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Service Selection */}
              <div>
                <Label className="text-gray-300">Select Service</Label>
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger className="bg-black/60 border-purple-400/50 text-white">
                    <SelectValue placeholder="Choose service type" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-purple-400">
                    {servicePricing.map((service: any) => (
                      <SelectItem key={service.serviceType} value={service.serviceType} className="text-white hover:bg-purple-600">
                        {service.serviceType === 'Boarding' && '🏠'} 
                        {service.serviceType === 'Training' && '🎯'} 
                        {service.serviceType === 'Walking' && '🚶'} 
                        {' '}{service.serviceName} (£{service.pricePerUnit}/{service.unit.replace('per ', '')})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Multiple Dog Selection */}
              <div>
                <Label className="text-gray-300">Select Dogs (click multiple for same check-in)</Label>
                <Input
                  type="text"
                  placeholder="Type dog name or owner name..."
                  value={dogSearchQuery}
                  onChange={(e) => setDogSearchQuery(e.target.value)}
                  className="bg-black/60 border-purple-400/50 text-white mb-2"
                />
                <div className="max-h-32 overflow-y-auto border border-purple-400/30 rounded bg-black/40">
                  {(() => {
                    // Filter dogs based on kennel status and search query
                    let availableDogs = dogs.filter((dog: any) => {
                      // Don't show dogs already assigned to any kennel
                      const isAlreadyAssigned = kennels.some((k: any) => 
                        k.dogIds?.includes(dog.id) || k.dogId === dog.id
                      );
                      if (isAlreadyAssigned) return false;

                      // If adding to occupied kennel, check dates and household rules
                      if (assigningKennel?.status === 'occupied' && assigningKennel?.dogIds?.length > 0 && checkInDate && checkOutDate) {
                        const existingDogId = assigningKennel.dogIds[0];
                        const existingDog = dogs.find((d: any) => d.id === existingDogId);
                        
                        if (existingDog && dog.clientId !== existingDog.clientId) {
                          // Different household - check if dates overlap
                          const newCheckIn = new Date(checkInDate);
                          const newCheckOut = new Date(checkOutDate);
                          const existingCheckIn = new Date(assigningKennel.checkInDate);
                          const existingCheckOut = new Date(assigningKennel.checkOutDate);
                          const hasOverlap = newCheckIn < existingCheckOut && newCheckOut > existingCheckIn;
                          
                          if (hasOverlap) return false; // Hide if dates conflict
                          // If no overlap, allow different household
                        }
                      }

                      // Search filter
                      if (dogSearchQuery) {
                        const ownerName = clients.find((c: any) => c.id === dog.clientId)?.name || '';
                        const searchTerm = dogSearchQuery.toLowerCase();
                        return dog.name.toLowerCase().includes(searchTerm) || 
                               ownerName.toLowerCase().includes(searchTerm) ||
                               dog.breed.toLowerCase().includes(searchTerm);
                      }

                      return true;
                    });

                    return availableDogs.map((dog: any) => {
                      const isSelected = selectedMultipleDogs.includes(dog.id);
                      return (
                        <div
                          key={dog.id}
                          onClick={() => {
                            // Toggle dog selection with family validation
                            if (selectedMultipleDogs.includes(dog.id)) {
                              setSelectedMultipleDogs(prev => prev.filter(id => id !== dog.id));
                            } else {
                              // Check if this dog is from the same family as already selected dogs
                              if (selectedMultipleDogs.length > 0) {
                                const firstSelectedDog = dogs.find((d: any) => d.id === selectedMultipleDogs[0]);
                                if (firstSelectedDog && firstSelectedDog.clientId !== dog.clientId) {
                                  toast({
                                    title: "Family Validation Failed",
                                    description: "Only dogs from the same family can be selected together",
                                    variant: "destructive",
                                  });
                                  return;
                                }
                              }

                              // Check for occupied kennel with different household (date conflict)
                              if (assigningKennel?.status === 'occupied' && assigningKennel?.dogIds?.length > 0 && checkInDate && checkOutDate) {
                                const existingDogId = assigningKennel.dogIds[0];
                                const existingDog = dogs.find((d: any) => d.id === existingDogId);
                                
                                if (existingDog && existingDog.clientId !== dog.clientId) {
                                  // Check if dates overlap
                                  const newCheckIn = new Date(checkInDate);
                                  const newCheckOut = new Date(checkOutDate);
                                  const existingCheckIn = new Date(assigningKennel.checkInDate);
                                  const existingCheckOut = new Date(assigningKennel.checkOutDate);
                                  
                                  // Check for date overlap
                                  const hasOverlap = newCheckIn < existingCheckOut && newCheckOut > existingCheckIn;
                                  
                                  if (hasOverlap) {
                                    toast({
                                      title: "Booking Conflict",
                                      description: `This kennel is occupied by ${existingDog.name} during those dates. Choose different dates or kennel.`,
                                      variant: "destructive",
                                    });
                                    return;
                                  }
                                  // If no date overlap, it's ok to proceed even with different household
                                }
                              }
                              
                              setSelectedMultipleDogs(prev => [...prev, dog.id]);
                            }
                          }}
                          className={`p-2 cursor-pointer border-b border-purple-400/20 hover:bg-purple-600/30 transition-colors ${
                            isSelected ? 'bg-purple-600/50 border-purple-400' : ''
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <div className="flex-1">
                              <div className="text-white font-medium text-sm">{dog.name} • {dog.breed}</div>
                              <div className="text-purple-300 text-xs">{clients.find((c: any) => c.id === dog.clientId)?.name}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-gray-300 text-xs">{dog.weight}kg</div>
                              {isSelected && (
                                <div className="text-green-400 text-sm">✓</div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    });
                  })()}
                  {dogs.length === 0 && (
                    <div className="p-3 text-gray-400 text-center text-sm">No dogs found</div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Check-In Date</Label>
                  <Input
                    type="date"
                    value={checkInDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                    className="bg-black/60 border-purple-400/50 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Check-Out Date</Label>
                  <Input
                    type="date"
                    value={checkOutDate}
                    onChange={(e) => setCheckOutDate(e.target.value)}
                    className="bg-black/60 border-purple-400/50 text-white"
                  />
                </div>
              </div>

              {/* Live Estimate Display */}
              {selectedMultipleDogs.length > 0 && checkInDate && checkOutDate && selectedService && (
                <div className="bg-gradient-to-r from-amber-600/20 to-yellow-500/20 border-2 border-amber-500 rounded-lg p-4 mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-amber-400 font-semibold flex items-center">
                      💰 Live Estimate
                    </h4>
                    <span className="text-xs text-amber-300">Auto-calculated</span>
                  </div>
                  
                  {(() => {
                    const startDate = new Date(checkInDate);
                    const endDate = new Date(checkOutDate);
                    const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
                    const serviceInfo = servicePricing.find((s: any) => s.serviceType === selectedService);
                    const pricePerUnit = serviceInfo ? serviceInfo.pricePerUnit : 0;
                    const totalCost = days * pricePerUnit * selectedMultipleDogs.length;
                    
                    return (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">Service:</span>
                          <span className="text-white">{serviceInfo?.serviceName || selectedService}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">Duration:</span>
                          <span className="text-white">{days} {days === 1 ? 'night' : 'nights'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">Dogs:</span>
                          <span className="text-white">{selectedMultipleDogs.length} {selectedMultipleDogs.length === 1 ? 'dog' : 'dogs'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">Rate:</span>
                          <span className="text-white">£{pricePerUnit.toFixed(2)}/night per dog</span>
                        </div>
                        <div className="border-t border-amber-500/30 pt-2">
                          <div className="flex justify-between font-bold text-lg">
                            <span className="text-amber-400">Total Estimate:</span>
                            <span className="text-amber-300">£{totalCost.toFixed(2)}</span>
                          </div>
                        </div>
                        <div className="text-xs text-amber-200 text-center mt-2">
                          ✨ Estimate updates automatically as you add dogs
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setAssigningKennel(null);
                    setSelectedService("");
                    setDogSearchQuery("");
                    setSelectedDogForKennel(0);
                    setCheckInDate("");
                    setCheckOutDate("");
                  }}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleAssignDog}
                  disabled={!selectedService || selectedMultipleDogs.length === 0 || !checkInDate || !checkOutDate}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white disabled:opacity-50"
                >
                  {selectedMultipleDogs.length === 0 ? "Select Dogs" : 
                   selectedMultipleDogs.length === 1 ? "Assign Dog" : `Assign ${selectedMultipleDogs.length} Dogs`}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Second Dog Confirmation Dialog */}
        <Dialog open={showSecondDogConfirmation} onOpenChange={setShowSecondDogConfirmation}>
          <DialogContent className="bg-black/90 border-2 border-yellow-400 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="text-yellow-400 text-xl">
                ⚠️ Confirm Second Dog Assignment
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="bg-yellow-600/20 border border-yellow-500 rounded p-4">
                <p className="text-yellow-100 mb-3">
                  Kennel #{assigningKennel?.number} already has <strong>1 dog</strong>.
                </p>
                <p className="text-yellow-100 mb-3">
                  You're about to add <strong>{secondDogCandidate?.name}</strong> as a second dog from the same household.
                </p>
                <p className="text-yellow-300 text-sm">
                  Are you sure you want to proceed with this assignment?
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowSecondDogConfirmation(false)}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={confirmSecondDogAssignment}
                  disabled={assignDogToKennelMutation.isPending}
                  className="flex-1 bg-yellow-600 hover:bg-yellow-700 text-black font-semibold"
                >
                  {assignDogToKennelMutation.isPending ? "Adding..." : "Yes, Add Second Dog"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Client Edit Dialog */}
        <Dialog open={!!editingClient} onOpenChange={() => setEditingClient(null)}>
          <DialogContent className="bg-black/90 border-2 border-green-400 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-green-400 text-xl">
                ✏️ Edit Client: {editingClient?.name}
              </DialogTitle>
            </DialogHeader>
            
            {editingClient && (
              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Full Name</Label>
                    <Input
                      value={editingClient.name || ""}
                      onChange={(e) => setEditingClient({...editingClient, name: e.target.value})}
                      className="bg-black/60 border-green-400/50 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Email</Label>
                    <Input
                      value={editingClient.email || ""}
                      onChange={(e) => setEditingClient({...editingClient, email: e.target.value})}
                      className="bg-black/60 border-green-400/50 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Phone</Label>
                    <Input
                      value={editingClient.phone || ""}
                      onChange={(e) => setEditingClient({...editingClient, phone: e.target.value})}
                      className="bg-black/60 border-green-400/50 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-300">Address</Label>
                    <Input
                      value={editingClient.address || ""}
                      onChange={(e) => setEditingClient({...editingClient, address: e.target.value})}
                      className="bg-black/60 border-green-400/50 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-green-300 font-medium">Emergency Contact</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label className="text-gray-300">Name</Label>
                      <Input
                        value={editingClient.emergencyContactName || ""}
                        onChange={(e) => setEditingClient({...editingClient, emergencyContactName: e.target.value})}
                        className="bg-black/60 border-green-400/50 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Phone</Label>
                      <Input
                        value={editingClient.emergencyContactPhone || ""}
                        onChange={(e) => setEditingClient({...editingClient, emergencyContactPhone: e.target.value})}
                        className="bg-black/60 border-green-400/50 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Relationship</Label>
                      <Input
                        value={editingClient.emergencyContactRelationship || ""}
                        onChange={(e) => setEditingClient({...editingClient, emergencyContactRelationship: e.target.value})}
                        className="bg-black/60 border-green-400/50 text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-green-300 font-medium">Veterinarian Information</h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label className="text-gray-300">Clinic Name</Label>
                      <Input
                        value={editingClient.vetName || ""}
                        onChange={(e) => setEditingClient({...editingClient, vetName: e.target.value})}
                        className="bg-black/60 border-green-400/50 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Phone</Label>
                      <Input
                        value={editingClient.vetPhone || ""}
                        onChange={(e) => setEditingClient({...editingClient, vetPhone: e.target.value})}
                        className="bg-black/60 border-green-400/50 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-gray-300">Address</Label>
                      <Input
                        value={editingClient.vetAddress || ""}
                        onChange={(e) => setEditingClient({...editingClient, vetAddress: e.target.value})}
                        className="bg-black/60 border-green-400/50 text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setEditingClient(null)}
                    className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={() => updateClientMutation.mutate({ id: editingClient.id, data: editingClient })}
                    disabled={updateClientMutation.isPending}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  >
                    {updateClientMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Kennel Details Dialog - Staff Information View */}
        <Dialog open={!!viewingKennelDetails} onOpenChange={() => setViewingKennelDetails(null)}>
          <DialogContent className="bg-black/90 border-2 border-blue-400 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-blue-400 text-2xl flex items-center">
                🏠 Kennel #{viewingKennelDetails?.number} - Detailed Information
                <Badge className="ml-3 bg-blue-600 text-white">
                  {viewingKennelDetails?.dogIds?.length || 0} Dog{viewingKennelDetails?.dogIds?.length === 1 ? '' : 's'}
                </Badge>
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {viewingKennelDetails?.dogIds?.map((dogId: number, index: number) => {
                const dog = dogs.find((d: any) => d.id === dogId);
                const client = clients.find((c: any) => c.id === dog?.clientId);
                
                return (
                  <div key={dogId} className="bg-gray-900/50 border border-blue-400/30 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-blue-400 text-xl font-bold">
                        🐕 Dog #{index + 1}: {dog?.name}
                      </h3>
                      <Badge className="bg-blue-600 text-white">
                        {dog?.breed}
                      </Badge>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Dog Information */}
                      <div className="space-y-3">
                        <h4 className="text-blue-300 font-semibold text-lg border-b border-blue-400/30 pb-2">
                          🐾 Dog Information
                        </h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Age:</span>
                            <span className="text-white">{dog?.age || 'N/A'} years old</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Weight:</span>
                            <span className="text-white">{dog?.weight || 'N/A'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Check-in:</span>
                            <span className="text-white">
                              {viewingKennelDetails?.checkInDate 
                                ? new Date(viewingKennelDetails.checkInDate).toLocaleDateString()
                                : 'N/A'
                              }
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Check-out:</span>
                            <span className="text-white">
                              {viewingKennelDetails?.checkOutDate 
                                ? new Date(viewingKennelDetails.checkOutDate).toLocaleDateString()
                                : 'N/A'
                              }
                            </span>
                          </div>
                        </div>

                        {/* Care Instructions */}
                        <div className="mt-4">
                          <h5 className="text-blue-300 font-medium mb-2">🍽️ Feeding Instructions</h5>
                          <p className="text-gray-300 text-sm bg-gray-800/50 p-2 rounded">
                            {dog?.feedingInstructions || 'No specific feeding instructions provided'}
                          </p>
                        </div>

                        <div className="mt-3">
                          <h5 className="text-blue-300 font-medium mb-2">🏃 Exercise Requirements</h5>
                          <p className="text-gray-300 text-sm bg-gray-800/50 p-2 rounded">
                            {dog?.exerciseRequirements || 'No specific exercise requirements provided'}
                          </p>
                        </div>

                        <div className="mt-3">
                          <h5 className="text-blue-300 font-medium mb-2">🧠 Behavior Notes</h5>
                          <p className="text-gray-300 text-sm bg-gray-800/50 p-2 rounded">
                            {dog?.behaviorNotes || 'No behavior notes provided'}
                          </p>
                        </div>
                      </div>

                      {/* Client Information */}
                      <div className="space-y-3">
                        <h4 className="text-green-300 font-semibold text-lg border-b border-green-400/30 pb-2">
                          👤 Owner Information
                        </h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Owner:</span>
                            <span className="text-white font-medium">{client?.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Email:</span>
                            <span className="text-white">{client?.email}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Phone:</span>
                            <span className="text-white">{client?.phone || 'N/A'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Address:</span>
                            <span className="text-white text-right ml-2">{client?.address || 'N/A'}</span>
                          </div>
                        </div>

                        {/* Emergency Contact */}
                        <div className="mt-4">
                          <h5 className="text-red-300 font-medium mb-2">🚨 Emergency Contact</h5>
                          <div className="bg-red-900/20 border border-red-400/30 p-3 rounded text-sm">
                            <div className="flex justify-between mb-1">
                              <span className="text-gray-400">Name:</span>
                              <span className="text-white">{client?.emergencyContactName || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between mb-1">
                              <span className="text-gray-400">Phone:</span>
                              <span className="text-white">{client?.emergencyContactPhone || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Relationship:</span>
                              <span className="text-white">{client?.emergencyContactRelationship || 'N/A'}</span>
                            </div>
                          </div>
                        </div>

                        {/* Veterinarian Information */}
                        <div className="mt-4">
                          <h5 className="text-purple-300 font-medium mb-2">🏥 Veterinarian</h5>
                          <div className="bg-purple-900/20 border border-purple-400/30 p-3 rounded text-sm">
                            <div className="flex justify-between mb-1">
                              <span className="text-gray-400">Clinic:</span>
                              <span className="text-white">{client?.vetName || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between mb-1">
                              <span className="text-gray-400">Phone:</span>
                              <span className="text-white">{client?.vetPhone || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Address:</span>
                              <span className="text-white text-right ml-2">{client?.vetAddress || 'N/A'}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Medical & Special Notes */}
                    {(dog?.allergies || dog?.medication) && (
                      <div className="mt-4 bg-yellow-900/20 border border-yellow-400/30 p-4 rounded">
                        <h5 className="text-yellow-300 font-medium mb-2">⚠️ Important Medical Information</h5>
                        {dog?.allergies && (
                          <div className="mb-2">
                            <span className="text-gray-400">Allergies:</span>
                            <span className="text-white ml-2">{dog.allergies}</span>
                          </div>
                        )}
                        {dog?.medication && (
                          <div>
                            <span className="text-gray-400">Medication:</span>
                            <span className="text-white ml-2">{dog.medication}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {index < (viewingKennelDetails?.dogIds?.length - 1) && (
                      <hr className="mt-6 border-gray-600" />
                    )}
                  </div>
                );
              })}

              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setViewingKennelDetails(null)}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Close
                </Button>
                <Button 
                  onClick={() => handleUnassignKennel(viewingKennelDetails.id)}
                  disabled={unassignKennelMutation.isPending}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                >
                  {unassignKennelMutation.isPending ? "Checking Out..." : "Check Out All Dogs"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Create Estimate Dialog */}
        <Dialog open={isCreatingEstimate} onOpenChange={setIsCreatingEstimate}>
          <DialogContent className="bg-black/90 border-2 border-cyan-400 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-cyan-400 text-2xl flex items-center">
                💰 Create New Estimate
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Client Selection */}
              <div>
                <Label className="text-gray-300 text-lg font-medium">Select Client</Label>
                <Select value={newEstimate.clientId.toString()} onValueChange={(value) => setNewEstimate({...newEstimate, clientId: parseInt(value)})}>
                  <SelectTrigger className="bg-black/60 border-cyan-400/50 text-white">
                    <SelectValue placeholder="Choose client" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-cyan-400">
                    {clients.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()} className="text-white hover:bg-cyan-600">
                        {client.name} - {client.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Dog Selection */}
              <div>
                <Label className="text-gray-300 text-lg font-medium">Select Dogs</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {dogs.filter((dog: any) => !newEstimate.clientId || dog.clientId === newEstimate.clientId).map((dog: any) => (
                    <div key={dog.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`dog-${dog.id}`}
                        checked={newEstimate.dogIds.includes(dog.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewEstimate({...newEstimate, dogIds: [...newEstimate.dogIds, dog.id]});
                          } else {
                            setNewEstimate({...newEstimate, dogIds: newEstimate.dogIds.filter(id => id !== dog.id)});
                          }
                        }}
                        className="rounded border-cyan-400"
                      />
                      <Label htmlFor={`dog-${dog.id}`} className="text-white">
                        {dog.name} ({dog.breed})
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Booking Dates */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300 text-lg font-medium">Check-in Date</Label>
                  <Input
                    type="date"
                    value={newEstimate.checkInDate}
                    onChange={(e) => setNewEstimate({...newEstimate, checkInDate: e.target.value})}
                    className="bg-black/60 border-cyan-400/50 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300 text-lg font-medium">Check-out Date</Label>
                  <Input
                    type="date"
                    value={newEstimate.checkOutDate}
                    onChange={(e) => setNewEstimate({...newEstimate, checkOutDate: e.target.value})}
                    className="bg-black/60 border-cyan-400/50 text-white"
                  />
                </div>
              </div>

              {/* Service Selection */}
              <div>
                <Label className="text-gray-300 text-lg font-medium">Select Services</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {servicePricing.map((service: any) => (
                    <div key={service.serviceType} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`service-${service.serviceType}`}
                        checked={newEstimate.services.includes(service.serviceType)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewEstimate({...newEstimate, services: [...newEstimate.services, service.serviceType]});
                          } else {
                            setNewEstimate({...newEstimate, services: newEstimate.services.filter(s => s !== service.serviceType)});
                          }
                        }}
                        className="rounded border-cyan-400"
                      />
                      <Label htmlFor={`service-${service.serviceType}`} className="text-white">
                        {service.serviceName} - £{service.pricePerUnit.toFixed(2)} {service.unit}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Live Cost Preview */}
              {newEstimate.checkInDate && newEstimate.checkOutDate && newEstimate.services.length > 0 && newEstimate.dogIds.length > 0 && (
                <div className="bg-cyan-500/20 border-2 border-cyan-400 rounded-lg p-6">
                  <h3 className="text-cyan-300 text-xl font-bold mb-4">💡 Estimate Preview</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-lg">
                      <span className="text-gray-300">Duration:</span>
                      <span className="text-white font-medium">
                        {Math.ceil((new Date(newEstimate.checkOutDate).getTime() - new Date(newEstimate.checkInDate).getTime()) / (1000 * 60 * 60 * 24))} nights
                      </span>
                    </div>
                    <div className="flex justify-between text-lg">
                      <span className="text-gray-300">Dogs:</span>
                      <span className="text-white font-medium">{newEstimate.dogIds.length}</span>
                    </div>
                    <div className="flex justify-between text-lg">
                      <span className="text-gray-300">Services:</span>
                      <span className="text-white font-medium">{newEstimate.services.length}</span>
                    </div>
                    <hr className="border-cyan-400/30 my-3" />
                    <div className="flex justify-between text-2xl font-bold">
                      <span className="text-cyan-300">Total Cost:</span>
                      <span className="text-cyan-400">£{calculateEstimateCost().toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Notes */}
              <div>
                <Label className="text-gray-300 text-lg font-medium">Additional Notes</Label>
                <textarea
                  value={newEstimate.notes}
                  onChange={(e) => setNewEstimate({...newEstimate, notes: e.target.value})}
                  className="w-full h-20 bg-black/60 border border-cyan-400/50 text-white rounded p-3"
                  placeholder="Any special requirements or notes..."
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setIsCreatingEstimate(false)}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateEstimate}
                  disabled={createEstimateMutation.isPending}
                  className="flex-1 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white"
                >
                  {createEstimateMutation.isPending ? "Creating..." : "Create Estimate"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Dog Edit Form Dialog */}
        <Dialog open={!!editingDog} onOpenChange={() => setEditingDog(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Edit Dog Profile: {editingDog?.name}</DialogTitle>
            </DialogHeader>
            {editingDog && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="editDogName" className="text-gray-300">Dog Name</Label>
                    <Input
                      id="editDogName"
                      value={editingDog.name || ""}
                      onChange={(e) => setEditingDog({...editingDog, name: e.target.value})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="editDogBreed" className="text-gray-300">Breed</Label>
                    <Input
                      id="editDogBreed"
                      value={editingDog.breed || ""}
                      onChange={(e) => setEditingDog({...editingDog, breed: e.target.value})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="editDogAge" className="text-gray-300">Age (years)</Label>
                    <Input
                      id="editDogAge"
                      type="number"
                      value={editingDog.age || ""}
                      onChange={(e) => setEditingDog({...editingDog, age: parseInt(e.target.value) || 0})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="editDogWeight" className="text-gray-300">Weight</Label>
                    <Input
                      id="editDogWeight"
                      type="number"
                      value={editingDog.weight || ""}
                      onChange={(e) => setEditingDog({...editingDog, weight: parseFloat(e.target.value) || 0})}
                      className="bg-black/60 border-purple-400/30 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="editDogWeightUnit" className="text-gray-300">Unit</Label>
                    <Select value={editingDog.weightUnit || "lbs"} onValueChange={(value) => setEditingDog({...editingDog, weightUnit: value})}>
                      <SelectTrigger className="bg-black/60 border-purple-400/30 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-black border-purple-400 text-white">
                        <SelectItem value="lbs">lbs</SelectItem>
                        <SelectItem value="kg">kg</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="editDogFood" className="text-gray-300">Food Type</Label>
                  <Select value={editingDog.foodType || ""} onValueChange={(value) => setEditingDog({...editingDog, foodType: value})}>
                    <SelectTrigger className="bg-black/60 border-purple-400/30 text-white">
                      <SelectValue placeholder="Select food type" />
                    </SelectTrigger>
                    <SelectContent className="bg-black border-purple-400 text-white">
                      <SelectItem value="Dry Kibble">Dry Kibble</SelectItem>
                      <SelectItem value="Wet Food">Wet Food</SelectItem>
                      <SelectItem value="Raw Diet">Raw Diet</SelectItem>
                      <SelectItem value="Prescription Diet">Prescription Diet</SelectItem>
                      <SelectItem value="Grain-Free">Grain-Free</SelectItem>
                      <SelectItem value="Senior Formula">Senior Formula</SelectItem>
                      <SelectItem value="Puppy Formula">Puppy Formula</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="editFeedingInstructions" className="text-gray-300">Feeding Instructions</Label>
                  <Textarea
                    id="editFeedingInstructions"
                    value={editingDog.feedingInstructions || ""}
                    onChange={(e) => setEditingDog({...editingDog, feedingInstructions: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="editExerciseRequirements" className="text-gray-300">Exercise Requirements</Label>
                  <Textarea
                    id="editExerciseRequirements"
                    value={editingDog.exerciseRequirements || ""}
                    onChange={(e) => setEditingDog({...editingDog, exerciseRequirements: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="editBehaviorNotes" className="text-gray-300">Behavior Notes</Label>
                  <Textarea
                    id="editBehaviorNotes"
                    value={editingDog.behaviorNotes || ""}
                    onChange={(e) => setEditingDog({...editingDog, behaviorNotes: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="editAllergies" className="text-gray-300">Allergies</Label>
                  <Textarea
                    id="editAllergies"
                    value={editingDog.allergies || ""}
                    onChange={(e) => setEditingDog({...editingDog, allergies: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={2}
                  />
                </div>

                <div>
                  <Label htmlFor="editMedication" className="text-gray-300">Medication</Label>
                  <Textarea
                    id="editMedication"
                    value={editingDog.medication || ""}
                    onChange={(e) => setEditingDog({...editingDog, medication: e.target.value})}
                    className="bg-black/60 border-purple-400/30 text-white resize-none"
                    rows={2}
                  />
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <Button 
                    variant="outline"
                    className="border-purple-400 text-purple-400 hover:bg-purple-400/10"
                    onClick={() => setEditingDog(null)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleUpdateDog}
                    disabled={updateDogMutation.isPending}
                    className="bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white"
                  >
                    {updateDogMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Kennel Choice Dialog - View Current Dog OR Book Another Dog */}
        <Dialog open={!!kennelChoiceDialog} onOpenChange={() => setKennelChoiceDialog(null)}>
          <DialogContent className="bg-black/90 border-2 border-yellow-400 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="text-yellow-400 text-xl text-center">
                🏠 Kennel #{kennelChoiceDialog?.number} Options
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 text-center">
              <p className="text-gray-300">What would you like to do?</p>
              
              <div className="space-y-3">
                <Button
                  onClick={() => {
                    setViewingKennelDetails(kennelChoiceDialog);
                    setKennelChoiceDialog(null);
                  }}
                  className="w-full bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 text-white py-3"
                >
                  👁️ View Current Dog Details
                </Button>
                
                <Button
                  onClick={() => {
                    setAssigningKennel(kennelChoiceDialog);
                    setKennelChoiceDialog(null);
                  }}
                  className="w-full bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white py-3"
                >
                  📅 Book Another Dog
                </Button>
              </div>
              
              <Button
                variant="outline"
                onClick={() => setKennelChoiceDialog(null)}
                className="border-gray-400 text-gray-400 hover:bg-gray-400/10 w-full"
              >
                Cancel
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* NEW: Kennel Details Dialog with Booking Queue */}
        {viewingKennelDetails && (
          <Dialog open={!!viewingKennelDetails} onOpenChange={() => setViewingKennelDetails(null)}>
            <DialogContent className="bg-black/95 border border-yellow-400/30 max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-yellow-400 text-xl">
                  Kennel #{viewingKennelDetails.number} - Booking Queue
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                {/* Current Status */}
                <div className="bg-yellow-400/10 border border-yellow-400/30 rounded-lg p-4">
                  <h3 className="text-yellow-400 font-semibold mb-2">Current Status</h3>
                  <div className="text-white">
                    {(() => {
                      const today = new Date();
                      today.setHours(0, 0, 0, 0);
                      
                      const currentBookings = viewingKennelDetails.bookings?.filter((booking: any) => {
                        const checkIn = new Date(booking.startDate || booking.checkInDate);
                        const checkOut = new Date(booking.endDate || booking.checkOutDate);
                        checkIn.setHours(0, 0, 0, 0);
                        checkOut.setHours(23, 59, 59, 999);
                        return today >= checkIn && today <= checkOut;
                      }) || [];
                      
                      if (currentBookings.length === 0) {
                        return <span className="text-green-400">Available</span>;
                      }
                      
                      return (
                        <div className="space-y-2">
                          {currentBookings.map((booking: any) => {
                            const dog = dogs?.find((d: any) => d.id === booking.dogId);
                            const client = clients?.find((c: any) => c.id === dog?.clientId);
                            return (
                              <div key={booking.id} className="bg-red-900/20 border border-red-400/30 rounded p-2">
                                <div className="text-red-400 font-medium">{dog?.name}</div>
                                <div className="text-gray-300 text-sm">{client?.name}</div>
                                <div className="text-gray-400 text-xs">
                                  {new Date(booking.startDate || booking.checkInDate).toLocaleDateString()} - 
                                  {new Date(booking.endDate || booking.checkOutDate).toLocaleDateString()}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })()}
                  </div>
                </div>
                
                {/* Upcoming Bookings Queue */}
                <div className="bg-blue-400/10 border border-blue-400/30 rounded-lg p-4">
                  <h3 className="text-blue-400 font-semibold mb-2">Upcoming Bookings</h3>
                  <div className="space-y-2">
                    {(() => {
                      const today = new Date();
                      today.setHours(0, 0, 0, 0);
                      
                      const upcomingBookings = (viewingKennelDetails.bookings || [])
                        .filter((booking: any) => {
                          const checkIn = new Date(booking.startDate || booking.checkInDate);
                          return checkIn > today;
                        })
                        .sort((a: any, b: any) => {
                          const dateA = new Date(a.startDate || a.checkInDate);
                          const dateB = new Date(b.startDate || b.checkInDate);
                          return dateA.getTime() - dateB.getTime();
                        });
                      
                      if (upcomingBookings.length === 0) {
                        return <span className="text-gray-400">No upcoming bookings</span>;
                      }
                      
                      return upcomingBookings.map((booking: any, index: number) => {
                        const dog = dogs?.find((d: any) => d.id === booking.dogId);
                        const client = clients?.find((c: any) => c.id === dog?.clientId);
                        return (
                          <div key={booking.id} className="bg-blue-900/20 border border-blue-400/30 rounded p-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="text-blue-400 font-medium">#{index + 1} - {dog?.name}</div>
                                <div className="text-gray-300 text-sm">{client?.name}</div>
                                <div className="text-gray-400 text-xs">
                                  {new Date(booking.startDate || booking.checkInDate).toLocaleDateString()} - 
                                  {new Date(booking.endDate || booking.checkOutDate).toLocaleDateString()}
                                </div>
                              </div>
                              <div className="text-right text-xs text-gray-400">
                                {(() => {
                                  const checkIn = new Date(booking.startDate || booking.checkInDate);
                                  const checkOut = new Date(booking.endDate || booking.checkOutDate);
                                  const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
                                  const boardingService = servicePricing?.find((s: any) => s.serviceType === 'boarding');
                                  const pricePerNight = boardingService ? boardingService.basePrice / 100 : 40;
                                  return `£${(pricePerNight * nights).toFixed(0)} (${nights}n)`;
                                })()}
                              </div>
                            </div>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
                
                {/* Quick Actions */}
                <div className="flex gap-2 pt-4 border-t border-yellow-400/30">
                  <Button
                    onClick={() => {
                      setViewingKennelDetails(null);
                      setNewBooking(prev => ({ 
                        ...prev, 
                        kennelNumber: viewingKennelDetails.number,
                        serviceType: 'boarding'
                      }));
                    }}
                    className="bg-yellow-400 hover:bg-yellow-500 text-black"
                  >
                    Add New Booking
                  </Button>
                  {viewingKennelDetails.status === 'cleaning' && (
                    <Button
                      onClick={() => {
                        // Mark kennel as available
                        setViewingKennelDetails(null);
                      }}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      Mark Available
                    </Button>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}
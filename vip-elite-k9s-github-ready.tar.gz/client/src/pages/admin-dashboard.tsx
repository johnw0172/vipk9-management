import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Plus, CalendarPlus, Users, Dog, Calendar, PoundSterling, Clock, CheckCircle, AlertTriangle, Home, Fan, BarChart3 } from "lucide-react";
import { VIPHeader } from "@/components/vip-header";
import { StaffCard } from "@/components/staff-card";
import { KennelGrid } from "@/components/kennel-grid";
import { StaffLoginModal } from "@/components/staff-login-modal";
import { AddStaffModal } from "@/components/add-staff-modal";
import { AddJobModal } from "@/components/add-job-modal";
import { useState } from "react";
import type { Staff } from "@shared/schema";

export default function AdminDashboard() {
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [showAddJobModal, setShowAddJobModal] = useState(false);

  const { data: staff = [], isLoading: staffLoading } = useQuery({
    queryKey: ["/api/staff"],
  });

  const { data: kennels = [], isLoading: kennelsLoading } = useQuery({
    queryKey: ["/api/kennels"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: todaysJobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: () => {
      const today = new Date().toISOString().split('T')[0];
      return fetch(`/api/jobs?date=${today}`, { credentials: "include" }).then(res => res.json());
    }
  });

  const handleStaffClick = (staffMember: Staff) => {
    setSelectedStaff(staffMember);
    setShowStaffModal(true);
  };

  const currentDate = new Date().toLocaleDateString('en-GB', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  if (staffLoading || kennelsLoading || statsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* VIP Elite K9s Premium Header */}
      <VIPHeader 
        title="VIP Elite K9s" 
        subtitle="Premium Dog Care Excellence"
        showNavigation={true}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-3xl font-bold text-foreground">Dashboard</h2>
              <p className="text-muted-foreground mt-1">{currentDate}</p>
            </div>
            <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row gap-3">
              <Button 
                className="bg-gold hover:bg-yellow-500 text-white"
                onClick={() => setShowAddStaffModal(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Staff
              </Button>
              <Button 
                className="bg-royal-blue hover:bg-blue-700 text-white"
                onClick={() => setShowAddJobModal(true)}
              >
                <CalendarPlus className="mr-2 h-4 w-4" />
                New Job
              </Button>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-100">
                  <Users className="text-royal-blue h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Staff On Duty</p>
                  <p className="text-2xl font-bold">{stats?.staffOnDuty || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-yellow-100">
                  <Dog className="text-gold h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Dogs Boarding</p>
                  <p className="text-2xl font-bold">{stats?.dogsBoarding || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-green-100">
                  <Calendar className="text-green-600 h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Today's Jobs</p>
                  <p className="text-2xl font-bold">{stats?.todaysJobs || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-purple-100">
                  <PoundSterling className="text-purple-600 h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-muted-foreground">Today's Revenue</p>
                  <p className="text-2xl font-bold">{stats?.revenue || "£0"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Staff Overview */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Staff Overview</CardTitle>
                  <Button variant="ghost" className="text-royal-blue hover:text-blue-700">
                    View All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {staff.map((staffMember: Staff) => (
                    <StaffCard 
                      key={staffMember.id} 
                      staff={staffMember} 
                      onClick={() => handleStaffClick(staffMember)}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Today's Schedule */}
          <div>
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Today's Schedule</CardTitle>
                  <Button variant="ghost" className="text-royal-blue hover:text-blue-700">
                    View All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {todaysJobs.length === 0 ? (
                    <p className="text-muted-foreground text-sm">No jobs scheduled for today</p>
                  ) : (
                    todaysJobs.slice(0, 5).map((job: any) => (
                      <div key={job.id} className="flex items-start space-x-3">
                        <div className="flex-shrink-0">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            job.type === 'training' ? 'bg-green-500' :
                            job.type === 'walk' ? 'bg-blue-500' :
                            job.type === 'feeding' ? 'bg-yellow-500' :
                            job.type === 'grooming' ? 'bg-purple-500' :
                            'bg-gray-500'
                          }`} />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium capitalize">{job.type}</p>
                          <p className="text-xs text-muted-foreground">{job.scheduledTime || 'Time TBD'} - {job.description}</p>
                          <p className="text-xs text-muted-foreground">Status: {job.status}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Kennel Overview */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">Kennel Overview</CardTitle>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                    <span className="text-sm text-muted-foreground">Occupied</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-gray-300 rounded-full" />
                    <span className="text-sm text-muted-foreground">Available</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                    <span className="text-sm text-muted-foreground">Cleaning</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <KennelGrid kennels={kennels} />
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity and Quick Actions */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Clock className="text-royal-blue h-4 w-4" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">No recent activity to display</p>
                    <p className="text-xs text-muted-foreground">Activity will appear here when staff interact with the system</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button 
                  variant="ghost" 
                  className="p-4 h-auto bg-muted hover:bg-muted/80 flex flex-col items-center space-y-2"
                  onClick={() => setShowAddStaffModal(true)}
                >
                  <Users className="text-royal-blue h-8 w-8" />
                  <span className="text-sm font-medium">Add Staff</span>
                </Button>
                <Button 
                  variant="ghost" 
                  className="p-4 h-auto bg-muted hover:bg-muted/80 flex flex-col items-center space-y-2"
                  onClick={() => setShowAddJobModal(true)}
                >
                  <CalendarPlus className="text-gold h-8 w-8" />
                  <span className="text-sm font-medium">New Job</span>
                </Button>
                <Button variant="ghost" className="p-4 h-auto bg-muted hover:bg-muted/80 flex flex-col items-center space-y-2">
                  <PoundSterling className="text-green-600 h-8 w-8" />
                  <span className="text-sm font-medium">Create Invoice</span>
                </Button>
                <Button variant="ghost" className="p-4 h-auto bg-muted hover:bg-muted/80 flex flex-col items-center space-y-2">
                  <CheckCircle className="text-purple-600 h-8 w-8" />
                  <span className="text-sm font-medium">View Reports</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Staff Login Modal */}
      {selectedStaff && (
        <StaffLoginModal
          staff={selectedStaff}
          open={showStaffModal}
          onOpenChange={setShowStaffModal}
        />
      )}

      {/* Add Staff Modal */}
      <AddStaffModal
        open={showAddStaffModal}
        onOpenChange={setShowAddStaffModal}
      />

      {/* Add Job Modal */}
      <AddJobModal
        open={showAddJobModal}
        onOpenChange={setShowAddJobModal}
      />
    </div>
  );
}

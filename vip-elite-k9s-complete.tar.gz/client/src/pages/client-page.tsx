import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Calendar, FileText, Phone } from "lucide-react";

export default function ClientPage() {
  const { data: dogs = [], isLoading: dogsLoading } = useQuery({
    queryKey: ["/api/dogs"],
  });

  const { data: reports = [], isLoading: reportsLoading } = useQuery({
    queryKey: ["/api/daily-reports"],
  });

  if (dogsLoading || reportsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 to-orange-100">
        <div className="text-lg text-amber-700">Loading your pet information...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100">
      {/* Header */}
      <div className="bg-amber-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-center">
            🐕 VIP Elite K9s - Client Portal
          </h1>
          <p className="text-center text-amber-100 mt-2">Your Pet's Care Information</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {/* My Dogs Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-amber-800 mb-4 flex items-center gap-2">
            <Heart className="w-6 h-6" />
            My Dogs
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {dogs.length === 0 ? (
              <Card className="border-2 border-amber-200">
                <CardContent className="p-6 text-center">
                  <p className="text-gray-600">No dogs registered yet.</p>
                </CardContent>
              </Card>
            ) : (
              dogs.map((dog: any) => (
                <Card key={dog.id} className="border-2 border-amber-200 hover:border-amber-400 transition-colors">
                  <CardHeader>
                    <CardTitle className="text-xl text-amber-800 flex items-center gap-2">
                      🐕 {dog.name}
                    </CardTitle>
                    <CardDescription>
                      {dog.breed} • {dog.age} years old
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      {dog.specialInstructions && (
                        <div>
                          <strong>Special Instructions:</strong>
                          <p className="text-gray-600">{dog.specialInstructions}</p>
                        </div>
                      )}
                      {dog.medications && (
                        <div>
                          <strong>Medications:</strong>
                          <p className="text-gray-600">{dog.medications}</p>
                        </div>
                      )}
                      {dog.emergencyContact && (
                        <div className="flex items-center gap-1 text-gray-600">
                          <Phone className="w-4 h-4" />
                          <span>Emergency: {dog.emergencyContact}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>

        {/* Daily Reports Section */}
        <div>
          <h2 className="text-2xl font-bold text-amber-800 mb-4 flex items-center gap-2">
            <FileText className="w-6 h-6" />
            Daily Care Reports
          </h2>
          
          <div className="grid gap-4">
            {reports.length === 0 ? (
              <Card className="border-2 border-amber-200">
                <CardContent className="p-6 text-center">
                  <p className="text-gray-600">No reports available yet.</p>
                </CardContent>
              </Card>
            ) : (
              reports.map((report: any) => (
                <Card key={report.id} className="border-2 border-amber-200">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg text-amber-800">
                          Daily Report - {dogs.find((d: any) => d.id === report.dogId)?.name || 'Unknown Dog'}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-1 mt-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(report.date).toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <Badge variant="outline" className="border-green-500 text-green-600">
                        ✅ Complete
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <strong>Meals:</strong>
                        <p className="text-gray-600">{report.mealsEaten || 'Not recorded'}</p>
                      </div>
                      <div>
                        <strong>Exercise:</strong>
                        <p className="text-gray-600">{report.exerciseTime || 'Not recorded'}</p>
                      </div>
                      <div>
                        <strong>Bathroom Breaks:</strong>
                        <p className="text-gray-600">{report.bathroomBreaks || 'Not recorded'}</p>
                      </div>
                      <div>
                        <strong>Mood:</strong>
                        <p className="text-gray-600">{report.mood || 'Not recorded'}</p>
                      </div>
                    </div>
                    
                    {report.notes && (
                      <div className="mt-4 p-3 bg-amber-50 rounded-lg">
                        <strong className="text-amber-800">Staff Notes:</strong>
                        <p className="text-gray-700 mt-1">{report.notes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Clock, Users, UserPlus, Home, Coffee, LogOut, UserCheck, ArrowLeft, Trash2, AlertTriangle } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import logoPath from "@assets/LOGO JPEG.jpg";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [isAddingClient, setIsAddingClient] = useState(false);
  const [isAddingDog, setIsAddingDog] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [viewingClient, setViewingClient] = useState<any>(null);
  const [viewingDog, setViewingDog] = useState<any>(null);
  const [assigningKennel, setAssigningKennel] = useState<any>(null);
  const [selectedDogForKennel, setSelectedDogForKennel] = useState<number>(0);
  const [checkInDate, setCheckInDate] = useState("");
  const [checkOutDate, setCheckOutDate] = useState("");
  const [newStaff, setNewStaff] = useState({
    name: "",
    role: "",
    pin: "",
    phone: "",
    email: ""
  });
  const [newClient, setNewClient] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    emergencyContactName: "",
    emergencyContactPhone: "",
    emergencyContactRelationship: "",
    vetName: "",
    vetPhone: "",
    vetAddress: "",
    password: ""
  });
  const [newDog, setNewDog] = useState({
    name: "",
    breed: "",
    age: "",
    weight: "",
    weightUnit: "lbs",
    foodType: "",
    clientId: 0,
    feedingInstructions: "",
    exerciseRequirements: "",
    behaviorNotes: "",
    allergies: "",
    medication: ""
  });

  const { data: staff = [], isLoading: staffLoading } = useQuery({ 
    queryKey: ["/api/staff"] 
  });

  const { data: clients = [], isLoading: clientsLoading } = useQuery({ 
    queryKey: ["/api/clients"] 
  });

  const { data: dogs = [], isLoading: dogsLoading } = useQuery({ 
    queryKey: ["/api/dogs"] 
  });

  const { data: kennels = [], isLoading: kennelsLoading } = useQuery({ 
    queryKey: ["/api/kennels"] 
  });

  const addStaffMutation = useMutation({
    mutationFn: (staffData: typeof newStaff) => 
      apiRequest("POST", "/api/staff", staffData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
      setIsAddingStaff(false);
      setNewStaff({ name: "", role: "", pin: "", phone: "", email: "" });
      toast({
        title: "Staff Added Successfully! ✓",
        description: "New staff member has been added to the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Adding Staff",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const updateStaffStatusMutation = useMutation({
    mutationFn: ({ id, action }: { id: number; action: string }) => 
      apiRequest("PATCH", `/api/staff/${id}/${action}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
      toast({
        title: "Status Updated ✓",
        description: "Staff status has been updated",
      });
    },
  });

  const addClientMutation = useMutation({
    mutationFn: (clientData: typeof newClient) => 
      apiRequest("POST", "/api/clients", clientData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setIsAddingClient(false);
      setNewClient({ 
        name: "", email: "", phone: "", address: "", emergencyContactName: "", 
        emergencyContactPhone: "", emergencyContactRelationship: "", vetName: "", 
        vetPhone: "", vetAddress: "", password: "" 
      });
      toast({
        title: "Client Added Successfully! ✓",
        description: "New client has been added to the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Adding Client",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const addDogMutation = useMutation({
    mutationFn: (dogData: typeof newDog) => 
      apiRequest("POST", "/api/dogs", dogData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      setIsAddingDog(false);
      setNewDog({
        name: "", breed: "", age: "", weight: "", weightUnit: "lbs", foodType: "", clientId: 0,
        feedingInstructions: "", exerciseRequirements: "", behaviorNotes: "", allergies: "", medication: ""
      });
      toast({
        title: "Dog Added Successfully! ✓",
        description: "New dog has been added to the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Adding Dog",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const deleteClientMutation = useMutation({
    mutationFn: (clientId: number) => 
      apiRequest("DELETE", `/api/clients/${clientId}`),
    onSuccess: async () => {
      // Force immediate cache invalidation and refetch
      await queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      await queryClient.refetchQueries({ queryKey: ["/api/clients"] });
      await queryClient.refetchQueries({ queryKey: ["/api/dogs"] });
      toast({
        title: "Client Removed Successfully! ✓",
        description: "Client and all associated data have been removed",
      });
    },
    onError: () => {
      toast({
        title: "Error Removing Client",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const deleteDogMutation = useMutation({
    mutationFn: (dogId: number) => 
      apiRequest("DELETE", `/api/dogs/${dogId}`),
    onSuccess: async () => {
      // Force immediate cache invalidation and refetch
      await queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      await queryClient.refetchQueries({ queryKey: ["/api/dogs"] });
      toast({
        title: "Dog Removed Successfully! ✓",
        description: "Dog profile has been removed from the system",
      });
    },
    onError: () => {
      toast({
        title: "Error Removing Dog",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const assignDogToKennelMutation = useMutation({
    mutationFn: ({ kennelId, dogId, checkInDate, checkOutDate }: { 
      kennelId: number; 
      dogId: number; 
      checkInDate: string; 
      checkOutDate: string; 
    }) => 
      apiRequest("POST", "/api/kennels/assign", {
        kennelIds: [kennelId],
        dogIds: [dogId],
        checkInDate,
        checkOutDate
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/kennels"] });
      await queryClient.refetchQueries({ queryKey: ["/api/kennels"] });
      setAssigningKennel(null);
      setSelectedDogForKennel(0);
      setCheckInDate("");
      setCheckOutDate("");
      toast({
        title: "Dog Assigned Successfully! ✓",
        description: "Dog has been checked into the kennel",
      });
    },
    onError: () => {
      toast({
        title: "Assignment Failed",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleAddStaff = () => {
    if (!newStaff.name || !newStaff.role || !newStaff.pin) {
      toast({
        title: "Missing Information",
        description: "Please fill in name, role, and PIN",
        variant: "destructive",
      });
      return;
    }
    addStaffMutation.mutate(newStaff);
  };

  const handleAddClient = () => {
    if (!newClient.name || !newClient.email || !newClient.password) {
      toast({
        title: "Missing Information",
        description: "Please fill in name, email, and password",
        variant: "destructive",
      });
      return;
    }
    
    // Send ALL client data including emergency contacts and vet info
    const completeClientData = {
      name: newClient.name,
      email: newClient.email,
      phone: newClient.phone || null,
      address: newClient.address || null,
      password: newClient.password,
      emergencyContactName: newClient.emergencyContactName || null,
      emergencyContactPhone: newClient.emergencyContactPhone || null,
      emergencyContactRelationship: newClient.emergencyContactRelationship || null,
      vetName: newClient.vetName || null,
      vetPhone: newClient.vetPhone || null,
      vetAddress: newClient.vetAddress || null,
    };
    
    addClientMutation.mutate(completeClientData);
  };

  const handleAddDog = () => {
    if (!newDog.name || !newDog.breed || !newDog.clientId) {
      toast({
        title: "Missing Information",
        description: "Please fill in name, breed, and select a client",
        variant: "destructive",
      });
      return;
    }
    addDogMutation.mutate({
      ...newDog,
      age: newDog.age ? parseInt(newDog.age) : undefined,
    });
  };

  const handleStatusUpdate = (staffId: number, action: string) => {
    updateStaffStatusMutation.mutate({ id: staffId, action });
  };

  const handleKennelClick = (kennel: any) => {
    if (kennel?.status === 'available') {
      setAssigningKennel(kennel);
    }
  };

  const handleAssignDog = () => {
    if (!selectedDogForKennel || !checkInDate || !checkOutDate) {
      toast({
        title: "Missing Information",
        description: "Please select a dog and enter check-in/check-out dates",
        variant: "destructive",
      });
      return;
    }
    
    assignDogToKennelMutation.mutate({
      kennelId: assigningKennel.id,
      dogId: selectedDogForKennel,
      checkInDate,
      checkOutDate
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "clocked_in":
        return <Badge className="bg-green-500 text-white">Clocked In</Badge>;
      case "on_break":
        return <Badge className="bg-yellow-500 text-white">On Break</Badge>;
      case "clocked_out":
        return <Badge className="bg-gray-500 text-white">Clocked Out</Badge>;
      default:
        return <Badge className="bg-gray-400 text-white">Unknown</Badge>;
    }
  };

  const filteredStaff = staff.filter(member => {
    if (statusFilter === "all") return true;
    return member.status === statusFilter;
  });

  const clockedInCount = staff.filter(s => s.status === "clocked_in").length;
  const onBreakCount = staff.filter(s => s.status === "on_break").length;

  if (staffLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-yellow-400 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-yellow-400">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 relative">
      {/* Elegant Border Frame */}
      <div className="absolute inset-0 border-8 border-double border-yellow-400 m-4 pointer-events-none"></div>
      <div className="absolute inset-0 border-4 border-yellow-500/30 m-8 pointer-events-none"></div>
      
      {/* Header */}
      <div className="bg-black/90 backdrop-blur shadow-xl border-b-2 border-yellow-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={logoPath} 
                alt="VIP Elite K9s" 
                className="h-12 w-12 rounded-full object-cover border-3 border-yellow-400 shadow-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-yellow-400">👑 Admin Dashboard</h1>
                <p className="text-sm text-gray-300">Staff Management Center</p>
              </div>
            </div>
            
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 font-semibold"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Homepage
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 relative z-10">
        {/* Staff Overview Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-400 text-sm font-medium">Total Staff</p>
                  <p className="text-3xl font-bold text-white">{staff.length}</p>
                </div>
                <Users className="w-8 h-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-2 border-green-400">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 text-sm font-medium">Clocked In</p>
                  <p className="text-3xl font-bold text-white">{clockedInCount}</p>
                </div>
                <UserCheck className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-2 border-yellow-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-500 text-sm font-medium">On Break</p>
                  <p className="text-3xl font-bold text-white">{onBreakCount}</p>
                </div>
                <Coffee className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
            <CardContent className="p-6">
              <Dialog open={isAddingStaff} onOpenChange={setIsAddingStaff}>
                <DialogTrigger asChild>
                  <Button className="w-full h-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-bold">
                    <UserPlus className="w-6 h-6 mr-2" />
                    Add New Staff
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-black/90 border-2 border-yellow-400 text-white">
                  <DialogHeader>
                    <DialogTitle className="text-yellow-400">Add New Staff Member</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name" className="text-gray-300">Full Name</Label>
                      <Input
                        id="name"
                        value={newStaff.name}
                        onChange={(e) => setNewStaff({...newStaff, name: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="Enter full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="role" className="text-gray-300">Role</Label>
                      <Select onValueChange={(value) => setNewStaff({...newStaff, role: value})}>
                        <SelectTrigger className="bg-black/60 border-yellow-400/50 text-white">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent className="bg-black border-yellow-400">
                          <SelectItem value="trainer">Trainer</SelectItem>
                          <SelectItem value="caretaker">Caretaker</SelectItem>
                          <SelectItem value="manager">Manager</SelectItem>
                          <SelectItem value="receptionist">Receptionist</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="pin" className="text-gray-300">4-Digit PIN</Label>
                      <Input
                        id="pin"
                        value={newStaff.pin}
                        onChange={(e) => setNewStaff({...newStaff, pin: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="0000"
                        maxLength={4}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-gray-300">Phone (Optional)</Label>
                      <Input
                        id="phone"
                        value={newStaff.phone}
                        onChange={(e) => setNewStaff({...newStaff, phone: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="(555) 123-4567"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="text-gray-300">Email (Optional)</Label>
                      <Input
                        id="email"
                        value={newStaff.email}
                        onChange={(e) => setNewStaff({...newStaff, email: e.target.value})}
                        className="bg-black/60 border-yellow-400/50 text-white"
                        placeholder="email@example.com"
                      />
                    </div>
                    <Button 
                      onClick={handleAddStaff}
                      disabled={addStaffMutation.isPending}
                      className="w-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-bold"
                    >
                      {addStaffMutation.isPending ? "Adding..." : "Add Staff Member"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>

        {/* Staff Management Section */}
        <Card className="bg-black/80 backdrop-blur border-2 border-yellow-400">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-yellow-400 text-xl">Staff Management</CardTitle>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48 bg-black/60 border-yellow-400/50 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black border-yellow-400">
                  <SelectItem value="all">All Staff</SelectItem>
                  <SelectItem value="clocked_in">Clocked In Only</SelectItem>
                  <SelectItem value="on_break">On Break Only</SelectItem>
                  <SelectItem value="clocked_out">Clocked Out Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {filteredStaff.map((member) => (
                <div key={member.id} className="bg-black/60 border border-yellow-400/30 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-black font-bold text-lg">
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-white font-semibold">{member.name}</h3>
                        <p className="text-gray-400 capitalize">{member.role}</p>
                        <p className="text-gray-500 text-sm">PIN: {member.pin}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {getStatusBadge(member.status)}
                      
                      <div className="flex space-x-2">
                        {member.status === "clocked_out" && (
                          <Button
                            size="sm"
                            onClick={() => handleStatusUpdate(member.id, "clock-in")}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <Clock className="w-4 h-4 mr-1" />
                            Clock In
                          </Button>
                        )}
                        
                        {member.status === "clocked_in" && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "break-start")}
                              className="bg-yellow-600 hover:bg-yellow-700 text-white"
                            >
                              <Coffee className="w-4 h-4 mr-1" />
                              Break
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "clock-out")}
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <LogOut className="w-4 h-4 mr-1" />
                              Clock Out
                            </Button>
                          </>
                        )}
                        
                        {member.status === "on_break" && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "break-end")}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <UserCheck className="w-4 h-4 mr-1" />
                              Return
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleStatusUpdate(member.id, "clock-out")}
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <LogOut className="w-4 h-4 mr-1" />
                              Clock Out
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {filteredStaff.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  {statusFilter === "all" 
                    ? "No staff members added yet. Click 'Add New Staff' to get started."
                    : `No staff members with status: ${statusFilter}`
                  }
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Client & Dog Management Section */}
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          {/* Client Management */}
          <Card className="bg-black/80 backdrop-blur border-2 border-blue-400">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-blue-400 text-xl">Client Management</CardTitle>
                <Dialog open={isAddingClient} onOpenChange={setIsAddingClient}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 text-white font-bold">
                      Add Client
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black/90 border-2 border-blue-400 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="text-blue-400">Add New Client - Boarding Information</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-6">
                      {/* Basic Information */}
                      <div>
                        <h3 className="text-lg font-semibold text-blue-400 mb-3">Basic Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="clientName" className="text-gray-300">Full Name *</Label>
                            <Input
                              id="clientName"
                              value={newClient.name}
                              onChange={(e) => setNewClient({...newClient, name: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="Enter client name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="clientEmail" className="text-gray-300">Email *</Label>
                            <Input
                              id="clientEmail"
                              value={newClient.email}
                              onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="client@example.com"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 mt-4">
                          <div>
                            <Label htmlFor="clientPhone" className="text-gray-300">Phone Number</Label>
                            <Input
                              id="clientPhone"
                              value={newClient.phone}
                              onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="(555) 123-4567"
                            />
                          </div>
                          <div>
                            <Label htmlFor="clientPassword" className="text-gray-300">Password *</Label>
                            <Input
                              id="clientPassword"
                              type="password"
                              value={newClient.password}
                              onChange={(e) => setNewClient({...newClient, password: e.target.value})}
                              className="bg-black/60 border-blue-400/50 text-white"
                              placeholder="Enter password"
                            />
                          </div>
                        </div>
                        <div className="mt-4">
                          <Label htmlFor="clientAddress" className="text-gray-300">Home Address</Label>
                          <Input
                            id="clientAddress"
                            value={newClient.address}
                            onChange={(e) => setNewClient({...newClient, address: e.target.value})}
                            className="bg-black/60 border-blue-400/50 text-white"
                            placeholder="123 Main Street, City, State, ZIP"
                          />
                        </div>
                      </div>

                      {/* Emergency Contact */}
                      <div>
                        <h3 className="text-lg font-semibold text-yellow-400 mb-3">Emergency Contact</h3>
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <Label htmlFor="emergencyName" className="text-gray-300">Contact Name</Label>
                            <Input
                              id="emergencyName"
                              value={newClient.emergencyContactName}
                              onChange={(e) => setNewClient({...newClient, emergencyContactName: e.target.value})}
                              className="bg-black/60 border-yellow-400/50 text-white"
                              placeholder="Emergency contact name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="emergencyPhone" className="text-gray-300">Contact Phone</Label>
                            <Input
                              id="emergencyPhone"
                              value={newClient.emergencyContactPhone}
                              onChange={(e) => setNewClient({...newClient, emergencyContactPhone: e.target.value})}
                              className="bg-black/60 border-yellow-400/50 text-white"
                              placeholder="(555) 987-6543"
                            />
                          </div>
                          <div>
                            <Label htmlFor="emergencyRelationship" className="text-gray-300">Relationship</Label>
                            <Input
                              id="emergencyRelationship"
                              value={newClient.emergencyContactRelationship}
                              onChange={(e) => setNewClient({...newClient, emergencyContactRelationship: e.target.value})}
                              className="bg-black/60 border-yellow-400/50 text-white"
                              placeholder="Spouse, Parent, etc."
                            />
                          </div>
                        </div>
                      </div>

                      {/* Veterinarian Information */}
                      <div>
                        <h3 className="text-lg font-semibold text-green-400 mb-3">Veterinarian Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="vetName" className="text-gray-300">Vet Clinic Name</Label>
                            <Input
                              id="vetName"
                              value={newClient.vetName}
                              onChange={(e) => setNewClient({...newClient, vetName: e.target.value})}
                              className="bg-black/60 border-green-400/50 text-white"
                              placeholder="Animal Hospital Name"
                            />
                          </div>
                          <div>
                            <Label htmlFor="vetPhone" className="text-gray-300">Vet Phone Number</Label>
                            <Input
                              id="vetPhone"
                              value={newClient.vetPhone}
                              onChange={(e) => setNewClient({...newClient, vetPhone: e.target.value})}
                              className="bg-black/60 border-green-400/50 text-white"
                              placeholder="(555) 111-2222"
                            />
                          </div>
                        </div>
                        <div className="mt-4">
                          <Label htmlFor="vetAddress" className="text-gray-300">Vet Clinic Address</Label>
                          <Input
                            id="vetAddress"
                            value={newClient.vetAddress}
                            onChange={(e) => setNewClient({...newClient, vetAddress: e.target.value})}
                            className="bg-black/60 border-green-400/50 text-white"
                            placeholder="Veterinary clinic address"
                          />
                        </div>
                      </div>

                      <Button 
                        onClick={handleAddClient}
                        disabled={addClientMutation.isPending}
                        className="w-full bg-gradient-to-r from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 text-white font-bold py-3"
                      >
                        {addClientMutation.isPending ? "Adding Client..." : "Add Client with Boarding Info"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {clients.slice(0, 5).map((client: any) => (
                  <div key={client.id} className="bg-black/60 border border-blue-400/30 rounded-lg p-3 hover:border-blue-400 hover:bg-black/80 transition-all">
                    <div className="flex items-center justify-between">
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => setViewingClient(client)}
                      >
                        <h4 className="text-white font-medium">{client.name}</h4>
                        <p className="text-gray-400 text-sm">{client.email}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className="bg-blue-500 text-white">
                          {dogs.filter((dog: any) => dog.clientId === client.id).length} dogs
                        </Badge>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (window.confirm(`Are you sure you want to remove ${client.name}? This will also remove all their dogs and cannot be undone.`)) {
                              deleteClientMutation.mutate(client.id);
                            }
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {clients.length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    No clients added yet. Click 'Add Client' to get started.
                  </div>
                )}
                {clients.length > 5 && (
                  <div className="text-center text-blue-400 text-sm">
                    + {clients.length - 5} more clients
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Dog Management */}
          <Card className="bg-black/80 backdrop-blur border-2 border-purple-400">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-purple-400 text-xl">Dog Management</CardTitle>
                <Dialog open={isAddingDog} onOpenChange={setIsAddingDog}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white font-bold">
                      Add Dog
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="text-purple-400">Add New Dog</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="dogName" className="text-gray-300">Dog Name</Label>
                          <Input
                            id="dogName"
                            value={newDog.name}
                            onChange={(e) => setNewDog({...newDog, name: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="Enter dog name"
                          />
                        </div>
                        <div>
                          <Label htmlFor="dogBreed" className="text-gray-300">Breed</Label>
                          <Input
                            id="dogBreed"
                            value={newDog.breed}
                            onChange={(e) => setNewDog({...newDog, breed: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="Golden Retriever"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="dogAge" className="text-gray-300">Age (years)</Label>
                          <Input
                            id="dogAge"
                            value={newDog.age}
                            onChange={(e) => setNewDog({...newDog, age: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="3"
                          />
                        </div>
                        <div>
                          <Label htmlFor="dogWeight" className="text-gray-300">Weight</Label>
                          <div className="flex gap-2">
                            <Input
                              id="dogWeight"
                              value={newDog.weight}
                              onChange={(e) => setNewDog({...newDog, weight: e.target.value})}
                              className="bg-black/60 border-purple-400/50 text-white flex-1"
                              placeholder="65"
                            />
                            <Select value={newDog.weightUnit} onValueChange={(value) => setNewDog({...newDog, weightUnit: value})}>
                              <SelectTrigger className="w-20 bg-black/60 border-purple-400/50 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-black border-purple-400">
                                <SelectItem value="lbs" className="text-white hover:bg-purple-600 focus:bg-purple-600">lbs</SelectItem>
                                <SelectItem value="kg" className="text-white hover:bg-purple-600 focus:bg-purple-600">kg</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="dogClient" className="text-gray-300">Owner</Label>
                          <Select onValueChange={(value) => setNewDog({...newDog, clientId: parseInt(value)})}>
                            <SelectTrigger className="bg-black/60 border-purple-400/50 text-white">
                              <SelectValue placeholder="Select owner" />
                            </SelectTrigger>
                            <SelectContent className="bg-black border-purple-400">
                              {clients.map((client: any) => (
                                <SelectItem key={client.id} value={client.id.toString()} className="text-white hover:bg-purple-600 focus:bg-purple-600">
                                  {client.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="foodType" className="text-gray-300">Food Type</Label>
                          <Select value={newDog.foodType} onValueChange={(value) => setNewDog({...newDog, foodType: value})}>
                            <SelectTrigger className="bg-black/60 border-purple-400/50 text-white">
                              <SelectValue placeholder="Select food type" />
                            </SelectTrigger>
                            <SelectContent className="bg-black border-purple-400">
                              <SelectItem value="raw" className="text-white hover:bg-purple-600 focus:bg-purple-600">Raw Diet</SelectItem>
                              <SelectItem value="dry" className="text-white hover:bg-purple-600 focus:bg-purple-600">Dry Kibble</SelectItem>
                              <SelectItem value="wet" className="text-white hover:bg-purple-600 focus:bg-purple-600">Wet/Canned</SelectItem>
                              <SelectItem value="freeze-dried" className="text-white hover:bg-purple-600 focus:bg-purple-600">Freeze-Dried</SelectItem>
                              <SelectItem value="homemade" className="text-white hover:bg-purple-600 focus:bg-purple-600">Homemade</SelectItem>
                              <SelectItem value="prescription" className="text-white hover:bg-purple-600 focus:bg-purple-600">Prescription Diet</SelectItem>
                              <SelectItem value="mixed" className="text-white hover:bg-purple-600 focus:bg-purple-600">Mixed Diet</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="feedingInstructions" className="text-gray-300">Feeding Instructions</Label>
                          <Input
                            id="feedingInstructions"
                            value={newDog.feedingInstructions}
                            onChange={(e) => setNewDog({...newDog, feedingInstructions: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="2 cups twice daily"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="exerciseRequirements" className="text-gray-300">Exercise Requirements</Label>
                        <Input
                          id="exerciseRequirements"
                          value={newDog.exerciseRequirements}
                          onChange={(e) => setNewDog({...newDog, exerciseRequirements: e.target.value})}
                          className="bg-black/60 border-purple-400/50 text-white"
                          placeholder="2 walks daily, 30 minutes each"
                        />
                      </div>

                      <div>
                        <Label htmlFor="behaviorNotes" className="text-gray-300">Behavior Notes</Label>
                        <Input
                          id="behaviorNotes"
                          value={newDog.behaviorNotes}
                          onChange={(e) => setNewDog({...newDog, behaviorNotes: e.target.value})}
                          className="bg-black/60 border-purple-400/50 text-white"
                          placeholder="Friendly, good with children"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="allergies" className="text-gray-300">Allergies</Label>
                          <Input
                            id="allergies"
                            value={newDog.allergies}
                            onChange={(e) => setNewDog({...newDog, allergies: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="None known"
                          />
                        </div>
                        <div>
                          <Label htmlFor="medication" className="text-gray-300">Medication</Label>
                          <Input
                            id="medication"
                            value={newDog.medication}
                            onChange={(e) => setNewDog({...newDog, medication: e.target.value})}
                            className="bg-black/60 border-purple-400/50 text-white"
                            placeholder="None"
                          />
                        </div>
                      </div>

                      <Button 
                        onClick={handleAddDog}
                        disabled={addDogMutation.isPending}
                        className="w-full bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white font-bold"
                      >
                        {addDogMutation.isPending ? "Adding..." : "Add Dog"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dogs.slice(0, 5).map((dog: any) => (
                  <div key={dog.id} className="bg-black/60 border border-purple-400/30 rounded-lg p-3 hover:border-purple-400 hover:bg-black/80 transition-all">
                    <div className="flex items-center justify-between">
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => setViewingDog(dog)}
                      >
                        <h4 className="text-white font-medium">{dog.name}</h4>
                        <p className="text-gray-400 text-sm">{dog.breed} • {dog.age ? `${dog.age} years` : 'Age unknown'}</p>
                        <p className="text-gray-500 text-xs">
                          Owner: {clients.find((c: any) => c.id === dog.clientId)?.name || 'Unknown'}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-right">
                          <Badge className="bg-purple-500 text-white">
                            {dog.weight || 'Weight unknown'}
                          </Badge>
                          {dog.medication && (
                            <div className="text-xs text-yellow-400 mt-1">Medication</div>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (window.confirm(`Are you sure you want to remove ${dog.name} from the system? This cannot be undone.`)) {
                              deleteDogMutation.mutate(dog.id);
                            }
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {dogs.length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    No dogs added yet. Click 'Add Dog' to get started.
                  </div>
                )}
                {dogs.length > 5 && (
                  <div className="text-center text-purple-400 text-sm">
                    + {dogs.length - 5} more dogs
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Client Detail Modal */}
        <Dialog open={!!viewingClient} onOpenChange={() => setViewingClient(null)}>
          <DialogContent className="bg-black/90 border-2 border-blue-400 text-white max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-blue-400 text-xl">Client Profile: {viewingClient?.name}</DialogTitle>
            </DialogHeader>
            {viewingClient && (
              <div className="space-y-6">
                <div className="flex items-center space-x-6">
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-black font-bold text-2xl">
                    {viewingClient.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-white">{viewingClient.name}</h2>
                    <p className="text-blue-400">{viewingClient.email}</p>
                    <p className="text-gray-400">{viewingClient.phone || 'No phone number'}</p>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                    📷 Add Photo
                  </Button>
                </div>

                {/* Basic Information */}
                <div className="border-b border-blue-400/30 pb-4">
                  <h3 className="text-blue-400 font-semibold mb-3">📋 Basic Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Email Address</Label>
                      <div className="bg-black/60 border border-blue-400/30 rounded p-2 text-white">
                        {viewingClient.email}
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Phone Number</Label>
                      <div className="bg-black/60 border border-blue-400/30 rounded p-2 text-white">
                        {viewingClient.phone || 'Not provided'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Label className="text-gray-300">Address</Label>
                    <div className="bg-black/60 border border-blue-400/30 rounded p-2 text-white">
                      {viewingClient.address || 'No address provided'}
                    </div>
                  </div>
                </div>

                {/* Emergency Contact */}
                <div className="border-b border-yellow-400/30 pb-4">
                  <h3 className="text-yellow-400 font-semibold mb-3">🚨 Emergency Contact</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Contact Name</Label>
                      <div className="bg-black/60 border border-yellow-400/30 rounded p-2 text-white">
                        {viewingClient.emergencyContactName || 'Not provided'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Contact Phone</Label>
                      <div className="bg-black/60 border border-yellow-400/30 rounded p-2 text-white">
                        {viewingClient.emergencyContactPhone || 'Not provided'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Label className="text-gray-300">Relationship</Label>
                    <div className="bg-black/60 border border-yellow-400/30 rounded p-2 text-white">
                      {viewingClient.emergencyContactRelationship || 'Not specified'}
                    </div>
                  </div>
                </div>

                {/* Veterinarian Information */}
                <div className="border-b border-green-400/30 pb-4">
                  <h3 className="text-green-400 font-semibold mb-3">🏥 Veterinarian Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Vet Clinic Name</Label>
                      <div className="bg-black/60 border border-green-400/30 rounded p-2 text-white">
                        {viewingClient.vetName || 'Not provided'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-300">Vet Phone</Label>
                      <div className="bg-black/60 border border-green-400/30 rounded p-2 text-white">
                        {viewingClient.vetPhone || 'Not provided'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Label className="text-gray-300">Vet Address</Label>
                    <div className="bg-black/60 border border-green-400/30 rounded p-2 text-white">
                      {viewingClient.vetAddress || 'No address provided'}
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Their Dogs</Label>
                  <div className="space-y-2 mt-2">
                    {dogs.filter((dog: any) => dog.clientId === viewingClient.id).map((dog: any) => (
                      <div key={dog.id} className="bg-black/60 border border-purple-400/30 rounded-lg p-3 flex justify-between items-center">
                        <div>
                          <h4 className="text-white font-medium">{dog.name}</h4>
                          <p className="text-gray-400 text-sm">{dog.breed} • {dog.age ? `${dog.age} years` : 'Age unknown'}</p>
                        </div>
                        <Button 
                          size="sm"
                          onClick={() => setViewingDog(dog)}
                          className="bg-purple-600 hover:bg-purple-700 text-white"
                        >
                          View Details
                        </Button>
                      </div>
                    ))}
                    {dogs.filter((dog: any) => dog.clientId === viewingClient.id).length === 0 && (
                      <p className="text-gray-400 text-center py-4">No dogs registered yet</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Dog Detail Modal */}
        <Dialog open={!!viewingDog} onOpenChange={() => setViewingDog(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400 text-xl">Dog Profile: {viewingDog?.name}</DialogTitle>
            </DialogHeader>
            {viewingDog && (
              <div className="space-y-6">
                <div className="flex items-center space-x-6">
                  <div className="w-32 h-32 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center text-black font-bold text-3xl">
                    🐕
                  </div>
                  <div className="flex-1">
                    <h2 className="text-3xl font-bold text-white">{viewingDog.name}</h2>
                    <p className="text-purple-400 text-lg">{viewingDog.breed}</p>
                    <p className="text-gray-400">
                      Owner: {clients.find((c: any) => c.id === viewingDog.clientId)?.name || 'Unknown'}
                    </p>
                    <div className="flex space-x-3 mt-2">
                      <Badge className="bg-purple-500 text-white">
                        {viewingDog.age ? `${viewingDog.age} years` : 'Age unknown'}
                      </Badge>
                      <Badge className="bg-purple-500 text-white">
                        {viewingDog.weight || 'Weight unknown'}
                      </Badge>
                    </div>
                  </div>
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    📷 Add Photo
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Feeding Instructions</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.feedingInstructions || 'No feeding instructions provided'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Exercise Requirements</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.exerciseRequirements || 'No exercise requirements provided'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Behavior Notes</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.behaviorNotes || 'No behavior notes provided'}
                    </div>
                  </div>
                  <div>
                    <Label className="text-gray-300">Allergies</Label>
                    <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                      {viewingDog.allergies || 'No known allergies'}
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Medication</Label>
                  <div className="bg-black/60 border border-purple-400/30 rounded p-3 text-white min-h-[60px]">
                    {viewingDog.medication || 'No medication required'}
                  </div>
                </div>

                <div className="flex justify-end space-x-3">
                  <Button 
                    variant="outline"
                    className="border-purple-400 text-purple-400 hover:bg-purple-400/10"
                    onClick={() => setViewingDog(null)}
                  >
                    Close
                  </Button>
                  <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                    Edit Profile
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Kennel Management Section */}
        <div className="mt-6">
          <Card className="bg-black/90 border-2 border-purple-400">
            <CardHeader>
              <CardTitle className="text-purple-400 text-xl flex items-center">
                🏠 Kennel Management (20 Kennels)
                <Badge className="ml-auto bg-purple-600 text-white">
                  {kennels.filter((k: any) => k.status === 'occupied').length} Occupied
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {kennelsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-purple-400 border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <div className="grid grid-cols-5 gap-3">
                  {Array.from({ length: 20 }, (_, i) => {
                    const kennelNumber = i + 1;
                    const kennel = kennels.find((k: any) => k.number === kennelNumber);
                    
                    // Enhanced: Support multiple dogs
                    const assignedDogIds = kennel?.dogIds || (kennel?.dogId ? [kennel.dogId] : []);
                    const assignedDogs = assignedDogIds.map((dogId: number) => 
                      dogs.find((d: any) => d.id === dogId)
                    ).filter(Boolean);
                    
                    // Enhanced: Color coding based on occupancy
                    const dogCount = assignedDogs.length;
                    const getKennelStyle = () => {
                      if (kennel?.status === 'cleaning') return 'border-yellow-400 bg-yellow-900/20';
                      if (dogCount === 0) return 'border-green-400 bg-green-900/20 hover:bg-green-800/30';
                      if (dogCount === 1) return 'border-red-400 bg-red-900/20';
                      if (dogCount === 2) return 'border-orange-400 bg-orange-900/20';
                      return 'border-gray-400 bg-gray-900/20';
                    };

                    const getStatusText = () => {
                      if (kennel?.status === 'cleaning') return 'Cleaning';
                      if (dogCount === 0) return 'Available';
                      if (dogCount === 1) return 'Occupied';
                      if (dogCount === 2) return '2 Dogs Sharing';
                      return 'Full';
                    };

                    const getStatusColor = () => {
                      if (kennel?.status === 'cleaning') return 'text-yellow-300';
                      if (dogCount === 0) return 'text-green-300';
                      if (dogCount === 1) return 'text-red-300';
                      if (dogCount === 2) return 'text-orange-300';
                      return 'text-gray-300';
                    };
                    
                    return (
                      <div
                        key={kennelNumber}
                        className={`
                          relative border-2 rounded-lg p-2 h-28 cursor-pointer transition-all hover:scale-105
                          ${getKennelStyle()}
                        `}
                        onClick={() => handleKennelClick(kennel)}
                      >
                        <div className="text-center h-full flex flex-col justify-between">
                          <div className="text-white font-bold text-sm">#{kennelNumber}</div>
                          <div className={`text-xs font-medium ${getStatusColor()}`}>
                            {getStatusText()}
                          </div>
                          
                          {/* Display assigned dogs */}
                          {assignedDogs.length > 0 && (
                            <div className="text-white text-xs space-y-0.5">
                              {assignedDogs.slice(0, 2).map((dog: any, idx: number) => (
                                <div key={dog.id} className="truncate">
                                  {dog.name}
                                  {assignedDogs.length > 1 && idx === 0 && (
                                    <span className="text-gray-400"> & </span>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Unassign button for occupied kennels */}
                          {assignedDogs.length > 0 && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleUnassignKennel(kennel.id);
                              }}
                              className="absolute top-1 right-1 w-4 h-4 bg-red-500 hover:bg-red-600 text-white text-xs rounded-full flex items-center justify-center"
                              title="Unassign dogs"
                            >
                              ×
                            </button>
                          )}
                        </div>
                        
                        {/* Enhanced status indicator */}
                        <div className={`absolute bottom-1 right-1 w-2 h-2 rounded-full ${
                          kennel?.status === 'cleaning' ? 'bg-yellow-400' :
                          dogCount === 0 ? 'bg-green-400' :
                          dogCount === 1 ? 'bg-red-400' :
                          dogCount === 2 ? 'bg-orange-400' :
                          kennel?.status === 'cleaning' ? 'bg-yellow-400' :
                          'bg-green-400'
                        }`}></div>
                      </div>
                    );
                  })}
                </div>
              )}
              
              <div className="flex justify-between items-center mt-4 pt-4 border-t border-purple-400/30">
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
                    <span className="text-green-300">Available ({kennels.filter((k: any) => k.status === 'available').length})</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-400 rounded-full mr-2"></div>
                    <span className="text-red-300">Occupied ({kennels.filter((k: any) => k.status === 'occupied').length})</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-yellow-400 rounded-full mr-2"></div>
                    <span className="text-yellow-300">Cleaning ({kennels.filter((k: any) => k.status === 'cleaning').length})</span>
                  </div>
                </div>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                  🐕 Assign Dog to Kennel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dog Assignment Dialog */}
        <Dialog open={!!assigningKennel} onOpenChange={() => setAssigningKennel(null)}>
          <DialogContent className="bg-black/90 border-2 border-purple-400 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="text-purple-400 text-xl">
                🐕 Assign Dog to Kennel #{assigningKennel?.number}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Select Dog</Label>
                <Select value={selectedDogForKennel.toString()} onValueChange={(value) => setSelectedDogForKennel(parseInt(value))}>
                  <SelectTrigger className="bg-black/60 border-purple-400/50 text-white">
                    <SelectValue placeholder="Choose a dog to check in" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-purple-400">
                    {dogs.filter((dog: any) => !kennels.some((k: any) => k.dogId === dog.id)).map((dog: any) => (
                      <SelectItem key={dog.id} value={dog.id.toString()} className="text-white hover:bg-purple-600 focus:bg-purple-600">
                        {dog.name} ({dog.breed}) - Owner: {clients.find((c: any) => c.id === dog.clientId)?.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Check-In Date</Label>
                  <Input
                    type="date"
                    value={checkInDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                    className="bg-black/60 border-purple-400/50 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Check-Out Date</Label>
                  <Input
                    type="date"
                    value={checkOutDate}
                    onChange={(e) => setCheckOutDate(e.target.value)}
                    className="bg-black/60 border-purple-400/50 text-white"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setAssigningKennel(null)}
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleAssignDog}
                  disabled={assignDogToKennelMutation.isPending}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                >
                  {assignDogToKennelMutation.isPending ? "Assigning..." : "Check In Dog"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Heart, Calendar, FileText, Plus, User } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { VIPHeader } from "@/components/vip-header";
import { ErrorBoundary, LoadingSpinner } from "@/components/error-boundary";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/utils";

export default function ClientPortal() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddPet, setShowAddPet] = useState(false);

  // Fetch client-specific data
  const { data: myDogs = [], isLoading: dogsLoading } = useQuery({
    queryKey: ["/api/client/my-dogs"],
  });

  const { data: myBookings = [], isLoading: bookingsLoading } = useQuery({
    queryKey: ["/api/client/my-bookings"],
  });

  const { data: myInvoices = [], isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/client/my-invoices"],
  });

  const { data: dailyReports = [], isLoading: reportsLoading } = useQuery({
    queryKey: ["/api/client/daily-reports"],
  });

  if (dogsLoading || bookingsLoading || invoicesLoading || reportsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner message="Loading your VIP Elite K9s portal..." />
      </div>
    );
  }

  const activeBookings = myBookings.filter((booking: any) => booking.status === 'active');
  const pendingInvoices = myInvoices.filter((invoice: any) => invoice.status === 'pending');

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        <VIPHeader 
          title={`Welcome, ${user?.name || 'Valued Client'}`}
          subtitle="Your VIP Elite K9s Client Portal"
          showNavigation={false}
        />

        <div className="container mx-auto px-6 py-8">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">My Dogs</CardTitle>
                <Heart className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-500">{myDogs.length}</div>
                <p className="text-xs text-muted-foreground">Registered pets</p>
              </CardContent>
            </Card>

            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Bookings</CardTitle>
                <Calendar className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{activeBookings.length}</div>
                <p className="text-xs text-muted-foreground">Current services</p>
              </CardContent>
            </Card>

            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Invoices</CardTitle>
                <FileText className="h-4 w-4 text-amber-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">{pendingInvoices.length}</div>
                <p className="text-xs text-muted-foreground">Awaiting payment</p>
              </CardContent>
            </Card>

            <Card className="vip-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Daily Reports</CardTitle>
                <User className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{dailyReports.length}</div>
                <p className="text-xs text-muted-foreground">Available reports</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* My Dogs */}
            <Card className="vip-card">
              <CardHeader className="vip-header">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">My Dogs</CardTitle>
                    <CardDescription className="text-blue-100">
                      Manage your beloved pets
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => setShowAddPet(true)}
                    className="vip-button-gold"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Pet
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                  {myDogs.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No pets registered yet
                    </div>
                  ) : (
                    myDogs.map((dog: any) => (
                      <div
                        key={dog.id}
                        className="p-4 border rounded-lg space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-lg">{dog.name}</h4>
                          <Badge variant="outline">{dog.breed}</Badge>
                        </div>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p><strong>Age:</strong> {dog.age} years old</p>
                          <p><strong>Weight:</strong> {dog.weight}</p>
                          {dog.allergies && (
                            <p><strong>Allergies:</strong> {dog.allergies}</p>
                          )}
                          {dog.medication && (
                            <p><strong>Medication:</strong> {dog.medication}</p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Recent Bookings */}
            <Card className="vip-card">
              <CardHeader className="vip-header">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">My Bookings</CardTitle>
                    <CardDescription className="text-blue-100">
                      Your service history and upcoming visits
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => window.location.href = '/booking'}
                    className="vip-button-gold"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Book Service
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                  {myBookings.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No bookings yet
                    </div>
                  ) : (
                    myBookings.map((booking: any) => (
                      <div
                        key={booking.id}
                        className="p-4 border rounded-lg space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{booking.serviceType}</span>
                          <Badge variant={
                            booking.status === 'active' ? 'default' :
                            booking.status === 'completed' ? 'secondary' :
                            'outline'
                          }>
                            {booking.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p><strong>Date:</strong> {formatDate(booking.startDate)}</p>
                          <p><strong>Dog:</strong> {booking.dogName}</p>
                          <p><strong>Amount:</strong> {formatCurrency(booking.totalAmount)}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Invoices & Reports Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            {/* My Invoices */}
            <Card className="vip-card">
              <CardHeader className="vip-header">
                <CardTitle className="text-white">Recent Invoices</CardTitle>
                <CardDescription className="text-blue-100">
                  Billing and payment history
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-64 overflow-y-auto custom-scrollbar">
                  {myInvoices.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No invoices yet
                    </div>
                  ) : (
                    myInvoices.slice(0, 5).map((invoice: any) => (
                      <div
                        key={invoice.id}
                        className="flex items-center justify-between p-3 border rounded"
                      >
                        <div>
                          <p className="font-medium">{formatCurrency(invoice.amount)}</p>
                          <p className="text-sm text-gray-500">
                            Due: {formatDate(invoice.dueDate)}
                          </p>
                        </div>
                        <Badge variant={
                          invoice.status === 'paid' ? 'default' :
                          invoice.status === 'pending' ? 'secondary' :
                          'destructive'
                        }>
                          {invoice.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Daily Reports */}
            <Card className="vip-card">
              <CardHeader className="vip-header">
                <CardTitle className="text-white">Daily Reports</CardTitle>
                <CardDescription className="text-blue-100">
                  Updates on your dog's care
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-64 overflow-y-auto custom-scrollbar">
                  {dailyReports.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No reports available
                    </div>
                  ) : (
                    dailyReports.slice(0, 3).map((report: any) => (
                      <div
                        key={report.id}
                        className="p-4 border rounded-lg space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">{report.dogName}</span>
                          <span className="text-sm text-gray-500">
                            {formatDate(report.date)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">
                          {report.staffNotes || "Had a wonderful day! Ate well and enjoyed playtime."}
                        </p>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {report.overallWellbeing || "Excellent"}
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}
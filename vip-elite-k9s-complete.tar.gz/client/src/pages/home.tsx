import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Users, Calendar, Heart } from "lucide-react";
import { useLocation } from "wouter";
import logoPath from "@assets/LOGO JPEG.jpg";

export default function Home() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("home");

  const handleTabClick = (tab: string, path: string) => {
    setActiveTab(tab);
    setLocation(path);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 relative">
      {/* Elegant Border Frame */}
      <div className="absolute inset-0 border-8 border-double border-yellow-400 m-4 pointer-events-none"></div>
      <div className="absolute inset-0 border-4 border-yellow-500/30 m-8 pointer-events-none"></div>
      
      {/* Navigation Header */}
      <div className="bg-black/90 backdrop-blur shadow-xl border-b-2 border-yellow-400 relative z-10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <img 
                src={logoPath} 
                alt="VIP Elite K9s" 
                className="h-12 w-12 rounded-full object-cover border-3 border-yellow-400 shadow-lg"
              />
              <div>
                <h1 className="text-2xl font-bold text-yellow-400">VIP Elite K9s</h1>
                <p className="text-sm text-gray-300">Premium Dog Care Services</p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex space-x-1 bg-gray-800 rounded-lg p-1 border-2 border-yellow-400">
              <Button
                variant={activeTab === "home" ? "default" : "ghost"}
                onClick={() => setActiveTab("home")}
                className={`px-6 py-2 ${
                  activeTab === "home" 
                    ? "bg-yellow-400 text-black font-semibold" 
                    : "text-yellow-400 hover:bg-gray-700"
                }`}
              >
                <Crown className="w-4 h-4 mr-2" />
                Home
              </Button>
              <Button
                variant={activeTab === "admin" ? "default" : "ghost"}
                onClick={() => handleTabClick("admin", "/admin")}
                className={`px-6 py-2 ${
                  activeTab === "admin" 
                    ? "bg-yellow-400 text-black font-semibold" 
                    : "text-yellow-400 hover:bg-gray-700"
                }`}
              >
                <Users className="w-4 h-4 mr-2" />
                Admin
              </Button>
              <Button
                variant={activeTab === "staff" ? "default" : "ghost"}
                onClick={() => handleTabClick("staff", "/staff")}
                className={`px-6 py-2 ${
                  activeTab === "staff" 
                    ? "bg-yellow-400 text-black font-semibold" 
                    : "text-yellow-400 hover:bg-gray-700"
                }`}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Staff
              </Button>
              <Button
                variant={activeTab === "clients" ? "default" : "ghost"}
                onClick={() => handleTabClick("clients", "/client")}
                className={`px-6 py-2 ${
                  activeTab === "clients" 
                    ? "bg-yellow-400 text-black font-semibold" 
                    : "text-yellow-400 hover:bg-gray-700"
                }`}
              >
                <Heart className="w-4 h-4 mr-2" />
                Dog Owners
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="mb-8">
            <img 
              src={logoPath} 
              alt="VIP Elite K9s Logo" 
              className="h-32 w-32 mx-auto rounded-full object-cover border-4 border-yellow-400 shadow-2xl shadow-yellow-400/30"
            />
          </div>
          <h1 className="text-5xl font-bold text-yellow-400 mb-4 drop-shadow-lg">
            Welcome to VIP Elite K9s
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Where your beloved companions receive the royal treatment they deserve. 
            Our premium dog care services ensure your pets are happy, healthy, and loved.
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12 relative z-10">
          <Card className="bg-black/80 backdrop-blur border-4 border-double border-yellow-400 hover:border-yellow-300 transition-all duration-300 hover:shadow-2xl hover:shadow-yellow-400/20 relative">
            <div className="absolute inset-2 border border-yellow-500/30 pointer-events-none"></div>
            <CardContent className="p-8 text-center relative">
              <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Users className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-yellow-400 mb-3">Expert Staff</h3>
              <p className="text-gray-300">
                Our trained professionals provide personalized care for every dog, 
                ensuring they feel safe and loved.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-4 border-double border-yellow-400 hover:border-yellow-300 transition-all duration-300 hover:shadow-2xl hover:shadow-yellow-400/20 relative">
            <div className="absolute inset-2 border border-yellow-500/30 pointer-events-none"></div>
            <CardContent className="p-8 text-center relative">
              <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Crown className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-yellow-400 mb-3">Premium Services</h3>
              <p className="text-gray-300">
                From luxury boarding to professional training, we offer the finest 
                services for your cherished companions.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-black/80 backdrop-blur border-4 border-double border-yellow-400 hover:border-yellow-300 transition-all duration-300 hover:shadow-2xl hover:shadow-yellow-400/20 relative">
            <div className="absolute inset-2 border border-yellow-500/30 pointer-events-none"></div>
            <CardContent className="p-8 text-center relative">
              <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Heart className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-yellow-400 mb-3">Loving Care</h3>
              <p className="text-gray-300">
                Every dog receives individual attention and affection, making their 
                stay a happy and comfortable experience.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <div className="text-center relative z-10">
          <div className="bg-black/80 backdrop-blur border-4 border-double border-yellow-400 rounded-lg p-8 mb-8 relative">
            <div className="absolute inset-2 border border-yellow-500/30 pointer-events-none"></div>
            <h2 className="text-3xl font-bold text-yellow-400 mb-6 relative">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-gray-300 mb-8 relative">
              Choose your role above to access your personalized dashboard
            </p>
            <div className="flex justify-center space-x-4 relative">
              <Button 
                onClick={() => handleTabClick("admin", "/admin")}
                className="bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black px-8 py-3 text-lg font-semibold border-2 border-yellow-300 shadow-lg"
              >
                Admin Access
              </Button>
              <Button 
                onClick={() => handleTabClick("staff", "/staff")}
                variant="outline" 
                className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 px-8 py-3 text-lg font-semibold"
              >
                Staff Portal
              </Button>
              <Button 
                onClick={() => handleTabClick("clients", "/client")}
                variant="outline" 
                className="border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400/10 px-8 py-3 text-lg font-semibold"
              >
                Dog Owner Portal
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-black/90 backdrop-blur text-yellow-400 py-8 mt-16 border-t-4 border-double border-yellow-400 relative z-10">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-yellow-300">
            © 2024 VIP Elite K9s - Where Every Dog is Treated Like Royalty
          </p>
        </div>
      </div>
    </div>
  );
}
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Clock, Coffee, LogOut, CheckCircle, MapPin, Dog, AlertCircle } from "lucide-react";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function StaffDashboard() {
  const { staff, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [jobNotes, setJobNotes] = useState<Record<number, string>>({});

  // Redirect if not logged in
  if (!staff) {
    setLocation("/staff");
    return null;
  }

  const { data: jobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs", { staffId: staff.id }],
    queryFn: () => 
      fetch(`/api/jobs?staffId=${staff.id}`, { credentials: "include" }).then(res => res.json())
  });

  const statusMutation = useMutation({
    mutationFn: async (newStatus: string) => {
      return apiRequest("PATCH", `/api/staff/${staff.id}/status`, { status: newStatus });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/staff"] });
      toast({
        title: "Status updated",
        description: "Your status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update status. Please try again.",
        variant: "destructive",
      });
    }
  });

  const jobMutation = useMutation({
    mutationFn: async ({ jobId, updates }: { jobId: number; updates: any }) => {
      return apiRequest("PATCH", `/api/jobs/${jobId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      toast({
        title: "Job updated",
        description: "Job status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update job. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleStatusChange = (newStatus: string) => {
    statusMutation.mutate(newStatus);
  };

  const handleLogout = () => {
    handleStatusChange("clocked_out");
    logout();
    setLocation("/staff");
  };

  const completeJob = (jobId: number) => {
    const notes = jobNotes[jobId] || "";
    jobMutation.mutate({
      jobId,
      updates: {
        status: "completed",
        notes,
        completedAt: new Date().toISOString()
      }
    });
  };

  const updateJobNotes = (jobId: number, notes: string) => {
    setJobNotes(prev => ({ ...prev, [jobId]: notes }));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "clocked_in":
        return <Badge className="bg-green-500 text-white">On Duty</Badge>;
      case "on_break":
        return <Badge className="bg-yellow-500 text-white">On Break</Badge>;
      case "clocked_out":
        return <Badge className="bg-gray-400 text-white">Clocked Out</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getJobTypeIcon = (type: string) => {
    switch (type) {
      case "walk":
        return <MapPin className="h-4 w-4" />;
      case "training":
        return <Dog className="h-4 w-4" />;
      case "feeding":
        return <Coffee className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-royal-blue text-white p-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold">{staff.name}</h2>
              <p className="text-blue-200">{staff.role}</p>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusBadge(staff.status)}
              <div className="flex gap-2">
                {staff.status === "clocked_in" && (
                  <Button 
                    className="bg-gold hover:bg-yellow-500"
                    onClick={() => handleStatusChange("on_break")}
                    disabled={statusMutation.isPending}
                  >
                    <Coffee className="mr-2 h-4 w-4" />
                    Take Break
                  </Button>
                )}
                {staff.status === "on_break" && (
                  <Button 
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => handleStatusChange("clocked_in")}
                    disabled={statusMutation.isPending}
                  >
                    <Clock className="mr-2 h-4 w-4" />
                    Return from Break
                  </Button>
                )}
                <Button 
                  className="bg-red-600 hover:bg-red-700"
                  onClick={handleLogout}
                  disabled={statusMutation.isPending}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Clock Out
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Today's Jobs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center">
                <CheckCircle className="mr-2 h-5 w-5" />
                Today's Jobs
              </CardTitle>
            </CardHeader>
            <CardContent>
              {jobsLoading ? (
                <div className="text-center py-4">Loading jobs...</div>
              ) : jobs.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No jobs assigned for today.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {jobs.map((job: any) => (
                    <Card key={job.id} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3">
                            <div className="p-2 bg-blue-100 rounded-lg">
                              {getJobTypeIcon(job.type)}
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium capitalize">{job.type}</h4>
                              <p className="text-sm text-muted-foreground">{job.description}</p>
                              {job.scheduledTime && (
                                <p className="text-xs text-muted-foreground">Time: {job.scheduledTime}</p>
                              )}
                              <Badge 
                                variant={job.status === "completed" ? "default" : "secondary"}
                                className="mt-2"
                              >
                                {job.status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        
                        {job.status !== "completed" && (
                          <div className="mt-4 space-y-3">
                            <Textarea
                              placeholder="Add notes about this job..."
                              value={jobNotes[job.id] || ""}
                              onChange={(e) => updateJobNotes(job.id, e.target.value)}
                              className="min-h-[60px]"
                            />
                            <Button 
                              onClick={() => completeJob(job.id)}
                              disabled={jobMutation.isPending}
                              className="w-full bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="mr-2 h-4 w-4" />
                              Mark as Completed
                            </Button>
                          </div>
                        )}
                        
                        {job.notes && (
                          <div className="mt-3 p-3 bg-muted rounded-lg">
                            <p className="text-sm"><strong>Notes:</strong> {job.notes}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Boarding Tasks */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center">
                <Dog className="mr-2 h-5 w-5" />
                Boarding Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <p className="text-muted-foreground">Boarding management coming soon.</p>
                <p className="text-muted-foreground text-sm mt-2">This will show kennel duties and daily care tasks.</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <CheckCircle className="h-6 w-6" />
                <span>View All Jobs</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <Dog className="h-6 w-6" />
                <span>Kennel Management</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                <Clock className="h-6 w-6" />
                <span>Time Tracking</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, MapPin, User } from "lucide-react";

export default function StaffPage() {
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["/api/jobs"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-lg text-blue-700">Loading your jobs...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-blue-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-center">
            🐕 VIP Elite K9s - Staff Portal
          </h1>
          <p className="text-center text-blue-200 mt-2">Your Daily Job Assignments</p>
        </div>
      </div>

      {/* Jobs List */}
      <div className="max-w-4xl mx-auto p-6">
        <div className="grid gap-4">
          {jobs.length === 0 ? (
            <Card className="border-2 border-blue-200">
              <CardContent className="p-8 text-center">
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No Jobs Assigned</h3>
                <p className="text-gray-500">Check back later for new assignments!</p>
              </CardContent>
            </Card>
          ) : (
            jobs.map((job: any) => (
              <Card key={job.id} className="border-2 border-blue-200 hover:border-blue-400 transition-colors">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl text-blue-900">
                        {job.type === 'walk' ? '🚶 Dog Walk' : 
                         job.type === 'feed' ? '🍽️ Feeding' : 
                         job.type === 'training' ? '🎯 Training' : 
                         job.type === 'cleaning' ? '🧹 Cleaning' : job.type}
                      </CardTitle>
                      <CardDescription className="text-gray-600 mt-2">
                        {job.description}
                      </CardDescription>
                    </div>
                    <Badge 
                      variant={job.status === 'completed' ? 'default' : 
                              job.status === 'in_progress' ? 'secondary' : 'outline'}
                      className="ml-4"
                    >
                      {job.status === 'completed' ? '✅ Done' : 
                       job.status === 'in_progress' ? '⏳ In Progress' : '📋 Pending'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{new Date(job.scheduledTime).toLocaleDateString()} at {new Date(job.scheduledTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                    {job.location && (
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{job.location}</span>
                      </div>
                    )}
                  </div>
                  
                  {job.status === 'pending' && (
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Start Job
                    </Button>
                  )}
                  
                  {job.status === 'in_progress' && (
                    <Button variant="outline" className="border-green-500 text-green-600 hover:bg-green-50">
                      Mark Complete
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line, 
  ResponsiveContainer 
} from "recharts";
import { 
  TrendingUp, 
  Users, 
  Clock, 
  DollarSign,
  Calendar,
  Star,
  Activity,
  Target,
  Download,
  Filter,
  BarChart3,
  PieChart as PieChartIcon,
  LineChartIcon
} from "lucide-react";
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";

export default function ReportingPage() {
  const [dateRange, setDateRange] = useState("30days");
  const [selectedMetric, setSelectedMetric] = useState("revenue");

  // Colors for charts
  const chartColors = ['#1e40af', '#059669', '#dc2626', '#7c3aed', '#ea580c'];

  // Get all data for analytics
  const { data: staff = [] } = useQuery({
    queryKey: ["/api/staff"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/staff");
      return response.json();
    },
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ["/api/jobs"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/jobs");
      return response.json();
    },
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["/api/bookings"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/bookings");
      return response.json();
    },
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ["/api/invoices"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/invoices");
      return response.json();
    },
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["/api/clients"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/clients");
      return response.json();
    },
  });

  const { data: dogs = [] } = useQuery({
    queryKey: ["/api/dogs"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/dogs");
      return response.json();
    },
  });

  // Calculate key metrics
  const totalRevenue = invoices.reduce((sum: number, inv: any) => 
    inv.status === "paid" ? sum + inv.amount : sum, 0);
  
  const pendingRevenue = invoices.reduce((sum: number, inv: any) => 
    inv.status === "pending" ? sum + inv.amount : sum, 0);

  const completedJobs = jobs.filter((job: any) => job.status === "completed").length;
  const totalJobs = jobs.length;
  const jobCompletionRate = totalJobs > 0 ? (completedJobs / totalJobs * 100) : 0;

  const activeStaff = staff.filter((s: any) => s.status === "clocked_in").length;
  const confirmedBookings = bookings.filter((b: any) => b.status === "confirmed").length;

  // Service popularity data
  const serviceStats = bookings.reduce((acc: any, booking: any) => {
    acc[booking.serviceType] = (acc[booking.serviceType] || 0) + 1;
    return acc;
  }, {});

  const serviceData = Object.entries(serviceStats).map(([service, count]) => ({
    name: service.charAt(0).toUpperCase() + service.slice(1),
    value: count,
    revenue: bookings.filter((b: any) => b.serviceType === service)
      .reduce((sum: number, b: any) => sum + (b.totalAmount || 0), 0)
  }));

  // Revenue trend data (last 7 days)
  const revenueTrendData = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayRevenue = invoices
      .filter((inv: any) => inv.status === "paid" && 
        format(new Date(inv.paidDate || inv.issueDate), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd'))
      .reduce((sum: number, inv: any) => sum + inv.amount, 0);
    
    return {
      date: format(date, 'MMM dd'),
      revenue: dayRevenue,
      bookings: bookings.filter((b: any) => 
        format(new Date(b.startDate), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')).length
    };
  });

  // Staff performance data
  const staffPerformanceData = staff.map((s: any) => {
    const staffJobs = jobs.filter((j: any) => j.assignedStaffId === s.id);
    const completedStaffJobs = staffJobs.filter((j: any) => j.status === "completed");
    
    return {
      name: s.name,
      role: s.role,
      totalJobs: staffJobs.length,
      completedJobs: completedStaffJobs.length,
      completionRate: staffJobs.length > 0 ? (completedStaffJobs.length / staffJobs.length * 100) : 0,
      status: s.status
    };
  });

  // Monthly revenue comparison
  const currentMonth = new Date();
  const lastMonth = subDays(currentMonth, 30);
  
  const currentMonthRevenue = invoices
    .filter((inv: any) => inv.status === "paid" && 
      new Date(inv.paidDate || inv.issueDate) >= startOfMonth(currentMonth))
    .reduce((sum: number, inv: any) => sum + inv.amount, 0);

  const lastMonthRevenue = invoices
    .filter((inv: any) => inv.status === "paid" && 
      new Date(inv.paidDate || inv.issueDate) >= startOfMonth(lastMonth) &&
      new Date(inv.paidDate || inv.issueDate) < startOfMonth(currentMonth))
    .reduce((sum: number, inv: any) => sum + inv.amount, 0);

  const revenueGrowth = lastMonthRevenue > 0 ? 
    ((currentMonthRevenue - lastMonthRevenue) / lastMonthRevenue * 100) : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-royal-blue to-blue-600 text-white p-6">
        <div className="container mx-auto">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold mb-2">Business Analytics</h1>
              <p className="text-blue-100">Comprehensive insights and performance metrics</p>
            </div>
            <div className="flex gap-3">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-40 bg-white text-royal-blue">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 Days</SelectItem>
                  <SelectItem value="30days">Last 30 Days</SelectItem>
                  <SelectItem value="90days">Last 90 Days</SelectItem>
                  <SelectItem value="year">This Year</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="bg-white text-royal-blue hover:bg-gray-100">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Key Performance Indicators */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="border-l-4 border-l-green-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                  <p className="text-3xl font-bold text-green-600">${totalRevenue.toFixed(2)}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-600">+{revenueGrowth.toFixed(1)}% vs last month</span>
                  </div>
                </div>
                <DollarSign className="h-12 w-12 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Clients</p>
                  <p className="text-3xl font-bold text-blue-600">{clients.length}</p>
                  <p className="text-sm text-muted-foreground mt-2">{dogs.length} pets total</p>
                </div>
                <Users className="h-12 w-12 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Job Completion</p>
                  <p className="text-3xl font-bold text-purple-600">{jobCompletionRate.toFixed(1)}%</p>
                  <p className="text-sm text-muted-foreground mt-2">{completedJobs}/{totalJobs} jobs done</p>
                </div>
                <Target className="h-12 w-12 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-orange-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Staff On Duty</p>
                  <p className="text-3xl font-bold text-orange-600">{activeStaff}</p>
                  <p className="text-sm text-muted-foreground mt-2">of {staff.length} total staff</p>
                </div>
                <Clock className="h-12 w-12 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="staff">Staff Performance</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Revenue Trend */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <LineChartIcon className="h-5 w-5" />
                    Revenue Trend (Last 7 Days)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={revenueTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip formatter={(value: any, name: string) => 
                        name === 'revenue' ? [`$${value}`, 'Revenue'] : [value, 'Bookings']
                      } />
                      <Legend />
                      <Line type="monotone" dataKey="revenue" stroke="#1e40af" strokeWidth={3} />
                      <Line type="monotone" dataKey="bookings" stroke="#059669" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Service Popularity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChartIcon className="h-5 w-5" />
                    Popular Services
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={serviceData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {serviceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{confirmedBookings}</p>
                    <p className="text-sm text-muted-foreground">Confirmed Bookings</p>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">${pendingRevenue.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">Pending Revenue</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">{jobs.filter((j: any) => j.status === "pending").length}</p>
                    <p className="text-sm text-muted-foreground">Pending Jobs</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Revenue Tab */}
          <TabsContent value="revenue" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Monthly Revenue Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={[
                      { month: 'Last Month', revenue: lastMonthRevenue, invoices: invoices.filter((inv: any) => 
                        new Date(inv.issueDate) >= startOfMonth(lastMonth) &&
                        new Date(inv.issueDate) < startOfMonth(currentMonth)).length },
                      { month: 'This Month', revenue: currentMonthRevenue, invoices: invoices.filter((inv: any) => 
                        new Date(inv.issueDate) >= startOfMonth(currentMonth)).length }
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value: any, name: string) => 
                        name === 'revenue' ? [`$${value}`, 'Revenue'] : [value, 'Invoices']
                      } />
                      <Legend />
                      <Bar dataKey="revenue" fill="#1e40af" />
                      <Bar dataKey="invoices" fill="#059669" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Revenue Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {serviceData.map((service, index) => (
                    <div key={service.name} className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: chartColors[index % chartColors.length] }}
                        />
                        <span className="font-medium">{service.name}</span>
                      </div>
                      <span className="text-lg font-bold">${service.revenue.toFixed(2)}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Service Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={serviceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" fill="#1e40af" name="Bookings" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Service Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {serviceData.map((service, index) => (
                      <div key={service.name} className="border rounded-lg p-4">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-semibold">{service.name}</h4>
                          <Badge variant="outline">{service.value} bookings</Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Revenue</p>
                            <p className="font-semibold">${service.revenue.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Avg per booking</p>
                            <p className="font-semibold">
                              ${service.value > 0 ? (service.revenue / service.value).toFixed(2) : '0.00'}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Staff Performance Tab */}
          <TabsContent value="staff" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Staff Performance Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Staff Member</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Total Jobs</TableHead>
                      <TableHead>Completed</TableHead>
                      <TableHead>Completion Rate</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {staffPerformanceData.map((staff: any) => (
                      <TableRow key={staff.name}>
                        <TableCell className="font-medium">{staff.name}</TableCell>
                        <TableCell>{staff.role}</TableCell>
                        <TableCell>
                          <Badge 
                            className={
                              staff.status === "clocked_in" ? "bg-green-500" :
                              staff.status === "on_break" ? "bg-yellow-500" : "bg-gray-500"
                            }
                          >
                            {staff.status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>{staff.totalJobs}</TableCell>
                        <TableCell>{staff.completedJobs}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-royal-blue h-2 rounded-full" 
                                style={{ width: `${staff.completionRate}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium">{staff.completionRate.toFixed(0)}%</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Clock, CheckCircle, Calendar, MapPin } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { VIPHeader } from "@/components/vip-header";
import { ErrorBoundary, LoadingSpinner } from "@/components/error-boundary";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function StaffDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOnBreak, setIsOnBreak] = useState(false);

  // Fetch staff-specific data
  const { data: myJobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/staff/my-jobs"],
  });

  const { data: myKennels = [], isLoading: kennelsLoading } = useQuery({
    queryKey: ["/api/staff/my-kennels"],
  });

  const { data: timeEntry, isLoading: timeLoading } = useQuery({
    queryKey: ["/api/staff/current-shift"],
  });

  // Break management mutation
  const breakMutation = useMutation({
    mutationFn: async (action: 'start' | 'end') => {
      const response = await apiRequest("PATCH", `/api/staff/break`, { action });
      return response.json();
    },
    onSuccess: (data) => {
      setIsOnBreak(data.status === 'on_break');
      queryClient.invalidateQueries({ queryKey: ["/api/staff/current-shift"] });
      toast({
        title: isOnBreak ? "Break ended" : "Break started",
        description: isOnBreak ? "Welcome back! Ready to continue your shift." : "Enjoy your break!",
      });
    },
  });

  // Clock out mutation
  const clockOutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PATCH", "/api/staff/clock-out");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Clocked out successfully",
        description: "Have a great rest of your day!",
      });
      // Redirect to staff login
      window.location.href = "/staff-login";
    },
  });

  // Job completion mutation
  const completeJobMutation = useMutation({
    mutationFn: async (jobId: number) => {
      const response = await apiRequest("PATCH", `/api/staff/jobs/${jobId}/complete`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/staff/my-jobs"] });
      toast({
        title: "Job completed!",
        description: "Great work! The job has been marked as complete.",
      });
    },
  });

  if (jobsLoading || kennelsLoading || timeLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner message="Loading your VIP Elite K9s dashboard..." />
      </div>
    );
  }

  const todayJobs = myJobs.filter((job: any) => {
    const today = new Date().toDateString();
    return new Date(job.scheduledDate).toDateString() === today;
  });

  const pendingJobs = todayJobs.filter((job: any) => job.status === 'pending');
  const completedJobs = todayJobs.filter((job: any) => job.status === 'completed');

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        <VIPHeader 
          title={`Welcome, ${user?.name || 'Staff Member'}`}
          subtitle="Your VIP Elite K9s Dashboard"
          showNavigation={false}
        />

        <div className="container mx-auto px-6 py-8">
          {/* Time Tracking Card */}
          <Card className="vip-card mb-8">
            <CardHeader className="vip-header">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-white">Current Shift</CardTitle>
                  <CardDescription className="text-blue-100">
                    {timeEntry?.clockIn ? 
                      `Started at ${new Date(timeEntry.clockIn).toLocaleTimeString()}` :
                      'Not clocked in'
                    }
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  {timeEntry?.clockIn && (
                    <>
                      <Button
                        onClick={() => breakMutation.mutate(isOnBreak ? 'end' : 'start')}
                        disabled={breakMutation.isPending}
                        className={isOnBreak ? "vip-button" : "vip-button-gold"}
                      >
                        <Clock className="h-4 w-4 mr-2" />
                        {isOnBreak ? 'End Break' : 'Take Break'}
                      </Button>
                      <Button
                        onClick={() => clockOutMutation.mutate()}
                        disabled={clockOutMutation.isPending}
                        variant="destructive"
                      >
                        Clock Out
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {timeEntry?.clockIn ? 
                      Math.floor((Date.now() - new Date(timeEntry.clockIn).getTime()) / (1000 * 60 * 60)) :
                      0
                    }h
                  </div>
                  <p className="text-sm text-gray-600">Hours worked today</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{completedJobs.length}</div>
                  <p className="text-sm text-gray-600">Jobs completed</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-amber-600">{pendingJobs.length}</div>
                  <p className="text-sm text-gray-600">Jobs pending</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* My Jobs */}
            <Card className="vip-card">
              <CardHeader className="vip-header">
                <CardTitle className="text-white">My Jobs Today</CardTitle>
                <CardDescription className="text-blue-100">
                  Your assigned tasks for {new Date().toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                  {todayJobs.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No jobs assigned for today
                    </div>
                  ) : (
                    todayJobs.map((job: any) => (
                      <div
                        key={job.id}
                        className="p-4 border rounded-lg space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant={job.status === 'completed' ? 'default' : 'secondary'}>
                              {job.status}
                            </Badge>
                            <span className="font-semibold">{job.type}</span>
                          </div>
                          <span className="text-sm text-gray-500">{job.scheduledTime}</span>
                        </div>
                        <p className="text-sm text-gray-600">{job.description}</p>
                        {job.status === 'pending' && (
                          <Button
                            onClick={() => completeJobMutation.mutate(job.id)}
                            disabled={completeJobMutation.isPending}
                            size="sm"
                            className="vip-button"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Mark Complete
                          </Button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* My Kennels */}
            <Card className="vip-card">
              <CardHeader className="vip-header">
                <CardTitle className="text-white">My Kennel Assignments</CardTitle>
                <CardDescription className="text-blue-100">
                  Dogs under your care today
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                  {myKennels.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No kennel assignments today
                    </div>
                  ) : (
                    myKennels.map((kennel: any) => (
                      <div
                        key={kennel.id}
                        className="p-4 border rounded-lg space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-blue-600" />
                            <span className="font-semibold">Kennel {kennel.number}</span>
                          </div>
                          <Badge variant={kennel.status === 'occupied' ? 'default' : 'secondary'}>
                            {kennel.status}
                          </Badge>
                        </div>
                        {kennel.dog && (
                          <div className="text-sm text-gray-600">
                            <p><strong>{kennel.dog.name}</strong> - {kennel.dog.breed}</p>
                            <p>Special needs: {kennel.dog.behaviorNotes || 'None'}</p>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage-clean";
import { securityMiddleware } from "./security";
import { insertStaffSchema, insertClientSchema, insertDogSchema, insertJobSchema, insertBookingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Temporarily disable strict auth for demo - will re-enable after login flow is complete
  // app.use("/api/admin", securityMiddleware.validateAuth(["admin"]));
  // app.use("/api/staff", securityMiddleware.validateAuth(["staff"])); 
  // app.use("/api/client", securityMiddleware.validateAuth(["client"]));

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Create role-based token
      const userData = { id: user.id, username: user.username, role: user.role };
      const token = Buffer.from(JSON.stringify(userData)).toString('base64');
      
      res.json({ 
        user: userData,
        token,
        redirectTo: "/admin"
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/staff-login", async (req, res) => {
    try {
      const { pin } = req.body;
      const staff = await storage.getStaffByPin(pin);
      
      if (!staff) {
        return res.status(401).json({ message: "Invalid PIN" });
      }
      
      const now = new Date();
      const today = new Date().toISOString().split('T')[0];
      
      // Create a new time entry for this clock-in
      const timeEntry = await storage.createTimeEntry({
        staffId: staff.id,
        clockInTime: now,
        date: new Date(today),
        notes: "Clocked in via PIN login"
      });
      
      // Update staff status
      const updatedStaff = await storage.updateStaff(staff.id, {
        status: "clocked_in",
        clockInTime: now,
        breakStartTime: null // Clear any previous break time
      });
      
      res.json({ 
        staff: updatedStaff,
        timeEntry,
        message: "Successfully clocked in"
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Staff routes (temporarily accessible for dashboard demo)
  app.get("/api/staff", async (req, res) => {
    // Bypass auth check for demo
    res.setHeader('Access-Control-Allow-Origin', '*');
    try {
      const staff = await storage.getAllStaff();
      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/staff", async (req, res) => {
    try {
      const validatedData = insertStaffSchema.parse(req.body);
      const staff = await storage.createStaff(validatedData);
      res.json(staff);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/staff/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status, notes } = req.body;
      const staffId = parseInt(id);
      const now = new Date();
      
      // Get current staff to check their current status
      const currentStaff = await storage.getStaff(staffId);
      if (!currentStaff) {
        return res.status(404).json({ message: "Staff member not found" });
      }

      const updates: any = { status };
      let timeEntryUpdate = null;

      if (status === "on_break") {
        // Starting a break
        updates.breakStartTime = now;
        
        // Find current open time entry and update it
        const today = new Date().toISOString().split('T')[0];
        const todayEntries = await storage.getTimeEntriesByStaff(staffId);
        const currentEntry = todayEntries.find(entry => 
          entry.date.toISOString().split('T')[0] === today && !entry.clockOutTime
        );
        
        if (currentEntry) {
          timeEntryUpdate = await storage.updateTimeEntry(currentEntry.id, {
            breakStartTime: now
          });
        }
        
      } else if (status === "clocked_in") {
        // Returning from break or clocking in
        if (currentStaff.status === "on_break" && currentStaff.breakStartTime) {
          // Calculate break duration
          const breakDuration = Math.floor((now.getTime() - currentStaff.breakStartTime.getTime()) / (1000 * 60));
          
          // Update time entry with break end
          const today = new Date().toISOString().split('T')[0];
          const todayEntries = await storage.getTimeEntriesByStaff(staffId);
          const currentEntry = todayEntries.find(entry => 
            entry.date.toISOString().split('T')[0] === today && !entry.clockOutTime
          );
          
          if (currentEntry) {
            const totalBreakTime = (currentEntry.totalBreakTime || 0) + breakDuration;
            timeEntryUpdate = await storage.updateTimeEntry(currentEntry.id, {
              breakEndTime: now,
              totalBreakTime
            });
          }
        }
        
        updates.clockInTime = currentStaff.clockInTime || now;
        updates.breakStartTime = null;
        
      } else if (status === "clocked_out") {
        // Clocking out
        updates.lastClockOut = now;
        updates.clockInTime = null;
        updates.breakStartTime = null;
        
        // Complete the current time entry
        const today = new Date().toISOString().split('T')[0];
        const todayEntries = await storage.getTimeEntriesByStaff(staffId);
        const currentEntry = todayEntries.find(entry => 
          entry.date.toISOString().split('T')[0] === today && !entry.clockOutTime
        );
        
        if (currentEntry) {
          let totalBreakTime = currentEntry.totalBreakTime || 0;
          
          // If they're on break when clocking out, add current break time
          if (currentStaff.status === "on_break" && currentStaff.breakStartTime) {
            const currentBreakDuration = Math.floor((now.getTime() - currentStaff.breakStartTime.getTime()) / (1000 * 60));
            totalBreakTime += currentBreakDuration;
          }
          
          timeEntryUpdate = await storage.updateTimeEntry(currentEntry.id, {
            clockOutTime: now,
            totalBreakTime,
            notes: notes || "Clocked out"
          });
        }
      }
      
      const staff = await storage.updateStaff(staffId, updates);
      
      res.json({ 
        staff, 
        timeEntry: timeEntryUpdate,
        message: `Successfully ${status.replace('_', ' ')}`
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client authentication routes
  app.post("/api/auth/client-login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const client = await storage.getClientByEmail(email);
      
      if (!client || client.password !== password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      res.json({ 
        client: {
          id: client.id,
          name: client.name,
          email: client.email,
          phone: client.phone,
          address: client.address
        },
        message: "Login successful"
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client routes
  app.get("/api/clients", async (req, res) => {
    try {
      const clients = await storage.getAllClients();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/clients", async (req, res) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(validatedData);
      res.json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dog routes
  app.get("/api/dogs", async (req, res) => {
    try {
      const dogs = await storage.getAllDogs();
      res.json(dogs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/dogs/client/:clientId", async (req, res) => {
    try {
      const { clientId } = req.params;
      const dogs = await storage.getDogsByClient(parseInt(clientId));
      res.json(dogs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/dogs", async (req, res) => {
    try {
      const validatedData = insertDogSchema.parse(req.body);
      const dog = await storage.createDog(validatedData);
      res.json(dog);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Delete client route
  app.delete("/api/clients/:id", async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      
      // First delete all dogs belonging to this client
      const clientDogs = await storage.getDogsByClient(clientId);
      for (const dog of clientDogs) {
        await storage.deleteDog(dog.id);
      }
      
      // Then delete the client
      const success = await storage.deleteClient(clientId);
      if (success) {
        res.json({ message: "Client and associated dogs deleted successfully" });
      } else {
        res.status(404).json({ message: "Client not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Delete dog route
  app.delete("/api/dogs/:id", async (req, res) => {
    try {
      const dogId = parseInt(req.params.id);
      const success = await storage.deleteDog(dogId);
      if (success) {
        res.json({ message: "Dog deleted successfully" });
      } else {
        res.status(404).json({ message: "Dog not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Kennel routes
  app.get("/api/kennels", async (req, res) => {
    try {
      const kennels = await storage.getAllKennels();
      res.json(kennels);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/kennels/assign", async (req, res) => {
    console.log("🚀 ENHANCED KENNEL ASSIGNMENT STARTED");
    try {
      const { kennelIds, dogIds, checkInDate, checkOutDate } = req.body;
      
      console.log("📝 Request data:", { kennelIds, dogIds, checkInDate, checkOutDate });

      if (!Array.isArray(kennelIds) || !Array.isArray(dogIds)) {
        return res.status(400).json({ message: "Invalid kennel or dog selection" });
      }

      if (kennelIds.length !== 1) {
        return res.status(400).json({ message: "Can only assign to one kennel at a time" });
      }

      if (dogIds.length > 2) {
        return res.status(400).json({ message: "Maximum 2 dogs per kennel allowed" });
      }

      const kennelId = kennelIds[0];
      const kennel = await storage.getKennel(kennelId);
      
      if (!kennel) {
        return res.status(404).json({ message: "Kennel not found" });
      }

      // Check if kennel already has dogs
      const currentDogIds = kennel.dogIds || [];
      const totalDogsAfterAssignment = currentDogIds.length + dogIds.length;
      
      if (totalDogsAfterAssignment > 2) {
        return res.status(400).json({ message: "Cannot exceed 2 dogs per kennel" });
      }

      // Family validation: if adding to occupied kennel, check same client
      if (currentDogIds.length > 0 && dogIds.length > 0) {
        const existingDog = await storage.getDog(currentDogIds[0]);
        const newDog = await storage.getDog(dogIds[0]);
        
        if (existingDog && newDog && existingDog.clientId !== newDog.clientId) {
          return res.status(400).json({ 
            message: "Only dogs from the same household may share kennels" 
          });
        }
      }

      // Merge dog IDs (existing + new)
      const allDogIds = [...currentDogIds, ...dogIds];
      
      const updated = await storage.updateKennel(kennelId, {
        dogId: dogIds[0], // Keep backward compatibility
        dogIds: allDogIds,
        status: "occupied",
        checkInDate: new Date(checkInDate),
        checkOutDate: new Date(checkOutDate),
      });

      console.log("✅ Enhanced assignment complete:", updated);
      res.json({ message: "Dogs assigned successfully", kennel: updated });
    } catch (error) {
      console.error("💥 Error in enhanced assignment:", error);
      res.status(500).json({ message: "Failed to assign kennels" });
    }
  });

  // Unassign dogs from kennel
  app.patch("/api/kennels/:id/unassign", async (req, res) => {
    try {
      const kennelId = parseInt(req.params.id);
      
      const updated = await storage.updateKennel(kennelId, {
        dogId: null,
        dogIds: [],
        status: "available",
        checkInDate: null,
        checkOutDate: null,
      });

      if (!updated) {
        return res.status(404).json({ message: "Kennel not found" });
      }

      res.json({ message: "Kennel unassigned successfully", kennel: updated });
    } catch (error) {
      console.error("Error unassigning kennel:", error);
      res.status(500).json({ message: "Failed to unassign kennel" });
    }
  });

  app.get("/api/kennels/availability", async (req, res) => {
    try {
      const { start, end } = req.query;

      if (!start || !end) {
        return res.status(400).json({ message: "Missing date range" });
      }

      const startDate = new Date(start as string);
      const endDate = new Date(end as string);

      const kennels = await storage.getAllKennels();

      const availability: Record<string, Record<number, boolean>> = {};

      for (
        let d = new Date(startDate);
        d <= endDate;
        d.setDate(d.getDate() + 1)
      ) {
        const dateKey = d.toISOString().split("T")[0];
        availability[dateKey] = {};

        kennels.forEach((k) => {
          if (
            k.checkInDate &&
            k.checkOutDate &&
            d >= new Date(k.checkInDate) &&
            d <= new Date(k.checkOutDate)
          ) {
            availability[dateKey][k.number] = false;
          } else {
            availability[dateKey][k.number] = true;
          }
        });
      }

      res.json(availability);
    } catch (error) {
      console.error("Error generating availability:", error);
      res.status(500).json({ message: "Failed to fetch availability" });
    }
  });

  // Kennel routes
  app.get("/api/kennels", async (req, res) => {
    try {
      const kennels = await storage.getAllKennels();
      
      // Get dog information for occupied kennels
      const kennelsWithDogs = await Promise.all(
        kennels.map(async (kennel) => {
          if (kennel.dogId) {
            const dog = await storage.getDog(kennel.dogId);
            return { ...kennel, dog };
          }
          return kennel;
        })
      );
      
      res.json(kennelsWithDogs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/kennels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const kennel = await storage.updateKennel(parseInt(id), updates);
      if (!kennel) {
        return res.status(404).json({ message: "Kennel not found" });
      }
      
      res.json(kennel);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Job routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const { staffId, date } = req.query;
      
      let jobs;
      if (staffId) {
        jobs = await storage.getJobsByStaff(parseInt(staffId as string));
      } else if (date) {
        jobs = await storage.getJobsByDate(date as string);
      } else {
        jobs = await storage.getAllJobs();
      }
      
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const validatedData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(validatedData);
      res.json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/jobs/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      if (updates.status === "completed" && !updates.completedAt) {
        updates.completedAt = new Date();
      }
      
      const job = await storage.updateJob(parseInt(id), updates);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Booking routes
  app.get("/api/bookings", async (req, res) => {
    try {
      const { clientId } = req.query;
      
      let bookings;
      if (clientId) {
        bookings = await storage.getBookingsByClient(parseInt(clientId as string));
      } else {
        bookings = await storage.getAllBookings();
      }
      
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      res.json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const staff = await storage.getAllStaff();
      const kennels = await storage.getAllKennels();
      const today = new Date().toISOString().split('T')[0];
      const todaysJobs = await storage.getJobsByDate(today);
      
      const staffOnDuty = staff.filter(s => s.status === "clocked_in" || s.status === "on_break").length;
      const dogsBoarding = kennels.filter(k => k.status === "occupied").length;
      const todaysJobCount = todaysJobs.length;
      
      // Mock revenue calculation
      const revenue = todaysJobCount * 20; // £20 per job average
      
      res.json({
        staffOnDuty,
        dogsBoarding,
        todaysJobs: todaysJobCount,
        revenue: `£${revenue}`
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dev-only database reset endpoint
  if (process.env.NODE_ENV === "development") {
    app.post("/api/dev/reset-database", async (req, res) => {
      try {
        if (storage.resetDatabase) {
          await storage.resetDatabase();
          res.json({ message: "Database reset successfully" });
        } else {
          res.status(501).json({ message: "Reset not implemented" });
        }
      } catch (error) {
        console.error("Error resetting database:", error);
        res.status(500).json({ message: "Failed to reset database" });
      }
    });
  }

  const httpServer = createServer(app);
  return httpServer;
}

import {
  users, staff, clients, dogs, kennels, jobs, bookings, dailyReports, invoices, timeEntries, kennelLogs,
  type User, type Staff, type Client, type Dog, type Kennel, type Job, type Booking, type DailyReport, type Invoice, type TimeEntry, type KennelLog,
  type InsertUser, type InsertStaff, type InsertClient, type InsertDog, type InsertKennel, type InsertJob, type InsertBooking, type InsertDailyReport, type InsertInvoice, type InsertTimeEntry, type InsertKennelLog
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Staff
  getAllStaff(): Promise<Staff[]>;
  getStaff(id: number): Promise<Staff | undefined>;
  getStaffByPin(pin: string): Promise<Staff | undefined>;
  createStaff(staff: InsertStaff): Promise<Staff>;
  updateStaff(id: number, updates: Partial<Staff>): Promise<Staff | undefined>;

  // Clients
  getAllClients(): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  getClientByEmail(email: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  deleteClient(id: number): Promise<boolean>;

  // Dogs
  getAllDogs(): Promise<Dog[]>;
  getDog(id: number): Promise<Dog | undefined>;
  getDogsByClient(clientId: number): Promise<Dog[]>;
  createDog(dog: InsertDog): Promise<Dog>;
  updateDog(id: number, updates: Partial<Dog>): Promise<Dog | undefined>;
  deleteDog(id: number): Promise<boolean>;

  // Kennels
  getAllKennels(): Promise<Kennel[]>;
  getKennel(id: number): Promise<Kennel | undefined>;
  getKennelByNumber(number: number): Promise<Kennel | undefined>;
  createKennel(kennel: InsertKennel): Promise<Kennel>;
  updateKennel(id: number | string, updates: Partial<Kennel>): Promise<Kennel | undefined>;

  // Jobs
  getAllJobs(): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  getJobsByStaff(staffId: number): Promise<Job[]>;
  getJobsByDate(date: string): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined>;

  // Bookings
  getAllBookings(): Promise<Booking[]>;
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingsByClient(clientId: number): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: number, updates: Partial<Booking>): Promise<Booking | undefined>;

  // Daily Reports
  getDailyReport(dogId: number, date: string): Promise<DailyReport | undefined>;
  createDailyReport(report: InsertDailyReport): Promise<DailyReport>;
  updateDailyReport(id: number, updates: Partial<DailyReport>): Promise<DailyReport | undefined>;

  // Invoices
  getAllInvoices(): Promise<Invoice[]>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoicesByClient(clientId: number): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, updates: Partial<Invoice>): Promise<Invoice | undefined>;

  // Time Entries
  getAllTimeEntries(): Promise<TimeEntry[]>;
  getTimeEntry(id: number): Promise<TimeEntry | undefined>;
  getTimeEntriesByStaff(staffId: number): Promise<TimeEntry[]>;
  getTimeEntriesByDate(date: string): Promise<TimeEntry[]>;
  createTimeEntry(timeEntry: InsertTimeEntry): Promise<TimeEntry>;
  updateTimeEntry(id: number, updates: Partial<TimeEntry>): Promise<TimeEntry | undefined>;

  // Kennel Logs
  getAllKennelLogs(): Promise<KennelLog[]>;
  getKennelLog(id: number): Promise<KennelLog | undefined>;
  getKennelLogsByKennel(kennelId: number): Promise<KennelLog[]>;
  getKennelLogsByDog(dogId: number): Promise<KennelLog[]>;
  getKennelLogsByStaff(staffId: number): Promise<KennelLog[]>;
  getKennelLogsByDate(date: string): Promise<KennelLog[]>;
  createKennelLog(kennelLog: InsertKennelLog): Promise<KennelLog>;
  updateKennelLog(id: number, updates: Partial<KennelLog>): Promise<KennelLog | undefined>;

  // Dev utilities
  resetDatabase?(): Promise<void>;
}

class DatabaseStorage implements IStorage {
  private initialized = false;

  constructor() {
    this.initializeEssentialData();
  }

  private async initializeEssentialData() {
    if (this.initialized) return;
    this.initialized = true;

    console.log("🚀 Initializing database with sample data...");

    try {
      // Check if admin user exists
      const existingAdmin = await db.select().from(users).where(eq(users.username, "admin")).limit(1);
      
      if (existingAdmin.length === 0) {
        // Create admin user
        await db.insert(users).values({
          username: "admin",
          password: "password123",
          role: "admin"
        });
      }

      // Check if staff exists
      const existingStaff = await db.select().from(staff).limit(1);
      
      if (existingStaff.length === 0) {
        // Create sample staff
        await db.insert(staff).values([
          {
            name: "Emma Thompson",
            role: "Head Trainer",
            pin: "1234",
            profilePhoto: "https://images.unsplash.com/photo-1494790108755-2616b612b1c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
            status: "clocked_out"
          },
          {
            name: "James Wilson",
            role: "Boarding Specialist",
            pin: "5678",
            profilePhoto: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
            status: "clocked_out"
          },
          {
            name: "Sarah Chen",
            role: "Dog Walker",
            pin: "9012",
            profilePhoto: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
            status: "clocked_out"
          }
        ]);
      }

      // Check if kennels exist
      const existingKennels = await db.select().from(kennels).limit(1);
      
      if (existingKennels.length === 0) {
        // Create 20 kennels
        const kennelData = Array.from({ length: 20 }, (_, i) => ({
          number: i + 1,
          status: "available" as const,
          dogIds: [] as number[]
        }));
        
        await db.insert(kennels).values(kennelData);
      }

      console.log("✅ Database initialized successfully");
    } catch (error) {
      console.error("❌ Error initializing database:", error);
    }
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Staff
  async getAllStaff(): Promise<Staff[]> {
    return await db.select().from(staff);
  }

  async getStaff(id: number): Promise<Staff | undefined> {
    const [staffMember] = await db.select().from(staff).where(eq(staff.id, id)).limit(1);
    return staffMember;
  }

  async getStaffByPin(pin: string): Promise<Staff | undefined> {
    const [staffMember] = await db.select().from(staff).where(eq(staff.pin, pin)).limit(1);
    return staffMember;
  }

  async createStaff(insertStaff: InsertStaff): Promise<Staff> {
    const [staffMember] = await db.insert(staff).values({
      ...insertStaff,
      status: "clocked_out",
    }).returning();
    return staffMember;
  }

  async updateStaff(id: number, updates: Partial<Staff>): Promise<Staff | undefined> {
    const [updated] = await db.update(staff)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(staff.id, id))
      .returning();
    return updated;
  }

  // Clients
  async getAllClients(): Promise<Client[]> {
    return await db.select().from(clients);
  }

  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id)).limit(1);
    return client;
  }

  async getClientByEmail(email: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.email, email)).limit(1);
    return client;
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db.insert(clients).values(insertClient).returning();
    return client;
  }

  async deleteClient(id: number): Promise<boolean> {
    const result = await db.delete(clients).where(eq(clients.id, id));
    return result.rowCount > 0;
  }

  // Dogs
  async getAllDogs(): Promise<Dog[]> {
    return await db.select().from(dogs);
  }

  async getDog(id: number): Promise<Dog | undefined> {
    const [dog] = await db.select().from(dogs).where(eq(dogs.id, id)).limit(1);
    return dog;
  }

  async getDogsByClient(clientId: number): Promise<Dog[]> {
    return await db.select().from(dogs).where(eq(dogs.clientId, clientId));
  }

  async createDog(insertDog: InsertDog): Promise<Dog> {
    const [dog] = await db.insert(dogs).values(insertDog).returning();
    return dog;
  }

  async updateDog(id: number, updates: Partial<Dog>): Promise<Dog | undefined> {
    const [updated] = await db.update(dogs)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(dogs.id, id))
      .returning();
    return updated;
  }

  async deleteDog(id: number): Promise<boolean> {
    const result = await db.delete(dogs).where(eq(dogs.id, id));
    return result.rowCount > 0;
  }

  // Kennels - Enhanced with multiple dogs support
  async getAllKennels(): Promise<Kennel[]> {
    return await db.select().from(kennels);
  }

  async getKennel(id: number): Promise<Kennel | undefined> {
    const [kennel] = await db.select().from(kennels).where(eq(kennels.id, id)).limit(1);
    return kennel;
  }

  async getKennelByNumber(number: number): Promise<Kennel | undefined> {
    const [kennel] = await db.select().from(kennels).where(eq(kennels.number, number)).limit(1);
    return kennel;
  }

  async createKennel(insertKennel: InsertKennel): Promise<Kennel> {
    const [kennel] = await db.insert(kennels).values({
      ...insertKennel,
      status: "available",
      dogIds: []
    }).returning();
    return kennel;
  }

  async updateKennel(id: number | string, updates: Partial<Kennel>): Promise<Kennel | undefined> {
    const kennelId = typeof id === "string" ? parseInt(id, 10) : id;
    console.log("Database: Updating kennel", kennelId, "with:", updates);

    const [updated] = await db.update(kennels)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(kennels.id, kennelId))
      .returning();

    console.log("Database: Kennel updated:", updated);
    return updated;
  }

  // Jobs
  async getAllJobs(): Promise<Job[]> {
    return await db.select().from(jobs);
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
    return job;
  }

  async getJobsByStaff(staffId: number): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.assignedStaffId, staffId));
  }

  async getJobsByDate(date: string): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.scheduledDate, new Date(date)));
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values({
      ...insertJob,
      status: "pending"
    }).returning();
    return job;
  }

  async updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined> {
    const [updated] = await db.update(jobs)
      .set(updates)
      .where(eq(jobs.id, id))
      .returning();
    return updated;
  }

  // Bookings
  async getAllBookings(): Promise<Booking[]> {
    return await db.select().from(bookings);
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
    return booking;
  }

  async getBookingsByClient(clientId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.clientId, clientId));
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [booking] = await db.insert(bookings).values(insertBooking).returning();
    return booking;
  }

  async updateBooking(id: number, updates: Partial<Booking>): Promise<Booking | undefined> {
    const [updated] = await db.update(bookings)
      .set(updates)
      .where(eq(bookings.id, id))
      .returning();
    return updated;
  }

  // Daily Reports
  async getDailyReport(dogId: number, date: string): Promise<DailyReport | undefined> {
    const [report] = await db.select().from(dailyReports)
      .where(and(eq(dailyReports.dogId, dogId), eq(dailyReports.date, new Date(date))))
      .limit(1);
    return report;
  }

  async createDailyReport(insertReport: InsertDailyReport): Promise<DailyReport> {
    const [report] = await db.insert(dailyReports).values(insertReport).returning();
    return report;
  }

  async updateDailyReport(id: number, updates: Partial<DailyReport>): Promise<DailyReport | undefined> {
    const [updated] = await db.update(dailyReports)
      .set(updates)
      .where(eq(dailyReports.id, id))
      .returning();
    return updated;
  }

  // Invoices
  async getAllInvoices(): Promise<Invoice[]> {
    return await db.select().from(invoices);
  }

  async getInvoice(id: number): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
    return invoice;
  }

  async getInvoicesByClient(clientId: number): Promise<Invoice[]> {
    return await db.select().from(invoices).where(eq(invoices.clientId, clientId));
  }

  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db.insert(invoices).values(insertInvoice).returning();
    return invoice;
  }

  async updateInvoice(id: number, updates: Partial<Invoice>): Promise<Invoice | undefined> {
    const [updated] = await db.update(invoices)
      .set(updates)
      .where(eq(invoices.id, id))
      .returning();
    return updated;
  }

  // Time Entries
  async getAllTimeEntries(): Promise<TimeEntry[]> {
    return await db.select().from(timeEntries);
  }

  async getTimeEntry(id: number): Promise<TimeEntry | undefined> {
    const [entry] = await db.select().from(timeEntries).where(eq(timeEntries.id, id)).limit(1);
    return entry;
  }

  async getTimeEntriesByStaff(staffId: number): Promise<TimeEntry[]> {
    return await db.select().from(timeEntries).where(eq(timeEntries.staffId, staffId));
  }

  async getTimeEntriesByDate(date: string): Promise<TimeEntry[]> {
    return await db.select().from(timeEntries).where(eq(timeEntries.timestamp, new Date(date)));
  }

  async createTimeEntry(insertTimeEntry: InsertTimeEntry): Promise<TimeEntry> {
    const [entry] = await db.insert(timeEntries).values(insertTimeEntry).returning();
    return entry;
  }

  async updateTimeEntry(id: number, updates: Partial<TimeEntry>): Promise<TimeEntry | undefined> {
    const [updated] = await db.update(timeEntries)
      .set(updates)
      .where(eq(timeEntries.id, id))
      .returning();
    return updated;
  }

  // Kennel Logs
  async getAllKennelLogs(): Promise<KennelLog[]> {
    return await db.select().from(kennelLogs);
  }

  async getKennelLog(id: number): Promise<KennelLog | undefined> {
    const [log] = await db.select().from(kennelLogs).where(eq(kennelLogs.id, id)).limit(1);
    return log;
  }

  async getKennelLogsByKennel(kennelId: number): Promise<KennelLog[]> {
    return await db.select().from(kennelLogs).where(eq(kennelLogs.kennelId, kennelId));
  }

  async getKennelLogsByDog(dogId: number): Promise<KennelLog[]> {
    return await db.select().from(kennelLogs).where(eq(kennelLogs.dogId, dogId));
  }

  async getKennelLogsByStaff(staffId: number): Promise<KennelLog[]> {
    return await db.select().from(kennelLogs).where(eq(kennelLogs.staffId, staffId));
  }

  async getKennelLogsByDate(date: string): Promise<KennelLog[]> {
    return await db.select().from(kennelLogs).where(eq(kennelLogs.timestamp, new Date(date)));
  }

  async createKennelLog(insertKennelLog: InsertKennelLog): Promise<KennelLog> {
    const [log] = await db.insert(kennelLogs).values(insertKennelLog).returning();
    return log;
  }

  async updateKennelLog(id: number, updates: Partial<KennelLog>): Promise<KennelLog | undefined> {
    const [updated] = await db.update(kennelLogs)
      .set(updates)
      .where(eq(kennelLogs.id, id))
      .returning();
    return updated;
  }

  // Dev utility to reset database
  async resetDatabase(): Promise<void> {
    console.log("🗑️ Resetting database...");
    
    // Delete all data except admin user
    await db.delete(kennelLogs);
    await db.delete(timeEntries);
    await db.delete(invoices);
    await db.delete(dailyReports);
    await db.delete(bookings);
    await db.delete(jobs);
    await db.delete(dogs);
    await db.delete(clients);
    
    // Reset kennels to available
    await db.update(kennels).set({
      status: "available",
      dogId: null,
      dogIds: [],
      checkInDate: null,
      checkOutDate: null
    });

    console.log("✅ Database reset complete");
  }
}

export const storage = new DatabaseStorage();